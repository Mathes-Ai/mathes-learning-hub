# **App Name**: Mathes Learning Hub

## Core Features:

- Multi-Role Dashboard System: Unified entry point with specialized views and permissions for Students, Teachers, and Admins, leveraging Firebase Authentication.
- Bilingual Interface Engine: Native language support for both Tamil and English, allowing users to toggle their preferred teaching and UI language dynamically.
- Course & Material Library: Centralized repository for organizing and accessing video classes and PDF study materials, categorized by subject and difficulty.
- Interactive Quiz Center: A module for conducting online tests with multiple-question formats and real-time score tracking.
- AI Concept Tutor Tool: A tool that uses reasoning to provide personalized explanations for difficult mathematical or science concepts in the user's preferred language.
- Automated Notification System: Contextual alerts for students about new materials, upcoming tests, or class schedules.
- Teacher Submission Portal: Interface for educators to upload materials, create quizzes, and monitor student performance metrics.

## Style Guidelines:

- Primary color: Scholarly Indigo (#2E4CAD), selected for its association with wisdom and focus, offering high contrast in a light scheme.
- Background color: Clear Canvas (#F9F9FB), a deeply desaturated indigo hue that creates a distraction-free environment.
- Accent color: Insight Blue (#0F5E8A), providing clear visual hierarchy for secondary actions and highlights.
- Font pairing: 'Space Grotesk' for structured, tech-forward headlines and 'Inter' for highly legible body text, ideal for academic reading.
- Precision-lined stroke icons that convey technical concepts (calculators, notebooks, videos) with geometric clarity.
- Clean, card-based modular layout focusing on ease of navigation between various dashboard widgets and learning assets.
- Subtle, non-distracting fade-ins for loading dashboard data and gentle transitions between Tamil/English views.