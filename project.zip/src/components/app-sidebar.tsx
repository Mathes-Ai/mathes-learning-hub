
"use client";

import { useLanguage } from "@/context/LanguageContext";
import { useUser } from "@/firebase";
import { 
  LayoutDashboard, 
  BookOpen, 
  Video, 
  ClipboardList, 
  Sparkles, 
  Bell, 
  Settings, 
  Users, 
  GraduationCap,
  Calendar,
  MessageCircle,
  MessageSquare,
  BarChart3,
  UserCheck,
  CreditCard,
  Award,
  User as UserIcon,
  Trophy,
  History,
  Globe,
  Quote,
  LayoutList,
  XCircle,
  RotateCcw,
  Newspaper
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMemo } from "react";
import { useDoc } from "@/firebase";
import { doc } from "firebase/firestore";
import { useFirestore } from "@/firebase";

export function AppSidebar() {
  const { t } = useLanguage();
  const { user } = useUser();
  const db = useFirestore();
  const pathname = usePathname();

  const profileRef = useMemo(() => user ? doc(db, 'users', user.uid) : null, [db, user]);
  const { data: profile } = useDoc(profileRef);

  const isCurrent = (path: string) => pathname === path;

  const role = profile?.role || 'student';

  const mainNav = [
    { title: t('dashboard'), icon: LayoutDashboard, url: `/dashboard/${role}` },
    { title: t('courses'), icon: BookOpen, url: "/dashboard/courses" },
    { title: "PYQ Library", icon: History, url: "/dashboard/pyq" },
    { title: "Current Affairs", icon: Newspaper, url: "/dashboard/current-affairs" },
    { title: t('quizzes'), icon: ClipboardList, url: "/dashboard/quizzes" },
    { title: "Rankings", icon: Trophy, url: "/dashboard/quizzes/rankings" },
    { title: "Revision Hub", icon: RotateCcw, url: "/dashboard/student/revision" },
    { title: t('aiTutor'), icon: Sparkles, url: "/dashboard/ai-tutor" },
  ];

  const studentNav = [
    { title: "Study Planner", icon: LayoutList, url: "/dashboard/student/planner" },
    { title: "Mistake Book", icon: XCircle, url: "/dashboard/student/mistakes" },
    { title: "Success Library", icon: Award, url: "/dashboard/student/bookmarks" },
    { title: "Doubt Solving", icon: MessageCircle, url: "/dashboard/student/doubts" },
    { title: "My Analytics", icon: BarChart3, url: "/dashboard/student/analytics" },
    { title: "My Profile", icon: UserIcon, url: "/dashboard/student/profile" },
  ];

  const teacherNav = [
    { title: "Hub Analytics", icon: BarChart3, url: "/dashboard/teacher/analytics" },
    { title: "Manage Courses", icon: BookOpen, url: "/dashboard/admin/courses" },
    { title: "Study Materials", icon: Video, url: "/dashboard/admin/materials" },
    { title: "AI Test Builder", icon: Sparkles, url: "/dashboard/admin/tests" },
    { title: "Mark Attendance", icon: UserCheck, url: "/dashboard/teacher/attendance" },
    { title: "Doubt Solving", icon: MessageSquare, url: "/dashboard/teacher/doubts" },
  ];

  const adminNav = [
    { title: "Hub Analytics", icon: BarChart3, url: "/dashboard/admin" },
    { title: "Enrollments", icon: GraduationCap, url: "/dashboard/admin/enrollments" },
    { title: "Manage Quotes", icon: Quote, url: "/dashboard/admin/quotes" },
    { title: "Manage News", icon: Newspaper, url: "/dashboard/admin/current-affairs" },
    { title: "PYQ Manager", icon: History, url: "/dashboard/admin/pyq" },
    { title: "Tests & Quizzes", icon: ClipboardList, url: "/dashboard/admin/tests" },
    { title: "Fee Tracking", icon: CreditCard, url: "/dashboard/admin/payments" },
    { title: t('notifications'), icon: Bell, url: "/dashboard/admin/announcements" },
    { title: t('settings'), icon: Settings, url: "/dashboard/settings" },
  ];

  return (
    <Sidebar variant="sidebar" collapsible="icon">
      <SidebarHeader className="p-4 border-b">
        <Link href="/" className="flex items-center gap-3">
          <div className="bg-primary p-2 rounded-lg shrink-0">
            < GraduationCap className="text-primary-foreground h-5 w-5" />
          </div>
          <span className="font-headline font-bold text-lg tracking-tight group-data-[collapsible=icon]:hidden whitespace-nowrap">
            Mathes Learning Hub
          </span>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Main Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNav.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={isCurrent(item.url)} tooltip={item.title}>
                    <Link href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {role === 'student' && (
          <SidebarGroup>
            <SidebarGroupLabel>Success Features</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {studentNav.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isCurrent(item.url)} tooltip={item.title}>
                      <Link href={item.url}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {role === 'teacher' && (
          <SidebarGroup>
            <SidebarGroupLabel>Teacher Portal</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {teacherNav.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isCurrent(item.url)} tooltip={item.title}>
                      <Link href={item.url}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {role === 'admin' && (
          <SidebarGroup>
            <SidebarGroupLabel>Platform Administration</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {adminNav.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isCurrent(item.url)} tooltip={item.title}>
                      <Link href={item.url}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>
    </Sidebar>
  );
}
