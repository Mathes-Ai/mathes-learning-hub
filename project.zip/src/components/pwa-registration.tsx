"use client";

import { useEffect } from "react";

export function PwaRegistration() {
  useEffect(() => {
    if ("serviceWorker" in navigator && window.location.hostname !== "localhost") {
      window.addEventListener("load", () => {
        navigator.serviceWorker
          .register("/sw.js")
          .then((registration) => {
            console.log("MLH Service Worker registered: ", registration);
          })
          .catch((error) => {
            console.error("MLH Service Worker registration failed: ", error);
          });
      });
    }
  }, []);

  return null;
}
