
"use client";

import { useState, useMemo, useEffect } from "react";
import { 
  Search, 
  BookOpen, 
  FileText, 
  ClipboardCheck, 
  BellRing, 
  Loader2, 
  ArrowRight,
  Command,
  X
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useFirestore, useCollection, useUser, useMemoFirebase } from "@/firebase";
import { collection, query, where } from "firebase/firestore";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { useRouter } from "next/navigation";

export function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const db = useFirestore();
  const router = useRouter();
  const { user } = useUser();

  const coursesQuery = useMemoFirebase(() => collection(db, "courses"), [db]);
  const materialsQuery = useMemoFirebase(() => collection(db, "materials"), [db]);
  const testsQuery = useMemoFirebase(() => collection(db, "tests"), [db]);
  const allAnnouncementsQuery = useMemoFirebase(() => collection(db, "announcements"), [db]);

  const { data: courses } = useCollection(coursesQuery);
  const { data: materials } = useCollection(materialsQuery);
  const { data: tests } = useCollection(testsQuery);
  const { data: announcements } = useCollection(allAnnouncementsQuery);
  
  const enrollmentsQuery = useMemoFirebase(() => 
    user ? query(collection(db, "enrollments"), where("studentId", "==", user.uid)) : null,
    [db, user]
  );
  const { data: enrollments } = useCollection(enrollmentsQuery);
  const enrolledCourseIds = useMemo(() => enrollments.map(e => e.courseId), [enrollments]);
  
  const filteredAnnouncements = useMemo(() => {
    return announcements.filter(a => a.courseId === 'global' || enrolledCourseIds.includes(a.courseId));
  }, [announcements, enrolledCourseIds]);

  const results = useMemo(() => {
    if (!searchTerm.trim()) return { courses: [], materials: [], tests: [], announcements: [] };

    const term = searchTerm.toLowerCase();

    return {
      courses: courses.filter(c => 
        c.title.toLowerCase().includes(term) || 
        c.category.toLowerCase().includes(term)
      ).slice(0, 5),
      materials: materials.filter(m => 
        m.title.toLowerCase().includes(term) || 
        m.type.toLowerCase().includes(term)
      ).slice(0, 5),
      tests: tests.filter(t => 
        t.title.toLowerCase().includes(term) || 
        t.topic.toLowerCase().includes(term)
      ).slice(0, 5),
      announcements: filteredAnnouncements.filter(a => 
        a.title.toLowerCase().includes(term) || 
        a.content.toLowerCase().includes(term)
      ).slice(0, 5),
    };
  }, [searchTerm, courses, materials, tests, filteredAnnouncements]);

  const hasResults = results.courses.length > 0 || results.materials.length > 0 || results.tests.length > 0 || results.announcements.length > 0;

  const navigateTo = (url: string) => {
    setOpen(false);
    setSearchTerm("");
    router.push(url);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <div className="hidden md:flex relative w-64 group cursor-pointer">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
          <div className="pl-9 bg-muted/50 border-none rounded-md h-9 w-full flex items-center text-sm text-muted-foreground group-hover:bg-muted transition-colors">
            Mathes Learning Hub search...
            <kbd className="ml-auto mr-2 pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100">
              <span className="text-xs">⌘</span>K
            </kbd>
          </div>
        </div>
      </DialogTrigger>
      <DialogContent className="max-w-2xl p-0 gap-0 overflow-hidden rounded-2xl">
        <DialogHeader className="sr-only">
          <DialogTitle>Search Mathes Learning Hub</DialogTitle>
        </DialogHeader>
        <div className="flex items-center border-b px-4">
          <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
          <Input
            placeholder="Search academic content..."
            className="flex h-14 w-full rounded-md bg-transparent py-3 text-sm outline-none border-none focus-visible:ring-0"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            autoFocus
          />
        </div>
        <ScrollArea className="max-h-[450px]">
          <div className="p-4 space-y-6">
            {!searchTerm && (
              <div className="py-20 text-center flex flex-col items-center gap-2">
                <Command className="h-10 w-10 text-muted-foreground/20" />
                <p className="text-sm text-muted-foreground">Type to find academic content in Mathes Learning Hub.</p>
              </div>
            )}

            {results.courses.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-muted-foreground uppercase px-2">Courses</h3>
                {results.courses.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => navigateTo(`/dashboard/courses/${c.id}`)}
                    className="w-full text-left p-3 rounded-lg hover:bg-primary/5 group flex items-center gap-3 transition-colors active:bg-primary/10"
                  >
                    <div className="h-8 w-8 bg-blue-100 text-blue-600 rounded flex items-center justify-center">
                      <BookOpen className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">{c.title}</p>
                      <p className="text-[10px] text-muted-foreground uppercase">{c.category}</p>
                    </div>
                    <ArrowRight className="h-4 w-4 text-muted-foreground transition-opacity" />
                  </button>
                ))}
              </div>
            )}

            {results.tests.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-muted-foreground uppercase px-2">Mock Tests</h3>
                {results.tests.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => navigateTo(`/dashboard/quizzes/${t.id}`)}
                    className="w-full text-left p-3 rounded-lg hover:bg-emerald-50 group flex items-center gap-3 transition-colors active:bg-emerald-100"
                  >
                    <div className="h-8 w-8 bg-emerald-100 text-emerald-600 rounded flex items-center justify-center">
                      <ClipboardCheck className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">{t.title}</p>
                      <p className="text-[10px] text-muted-foreground uppercase">{t.topic}</p>
                    </div>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
