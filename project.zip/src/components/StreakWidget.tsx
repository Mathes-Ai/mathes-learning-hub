
"use client";

import { useMemo, useEffect } from "react";
import { useFirestore, useUser, useDoc } from "@/firebase";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Zap, Award, Flame, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export function StreakWidget() {
  const { user } = useUser();
  const db = useFirestore();

  const statsRef = useMemo(() => (user ? doc(db, "users", user.uid, "stats", "activity") : null), [db, user]);
  const { data: stats } = useDoc(statsRef);

  useEffect(() => {
    if (!user || !statsRef) return;

    const today = new Date().toISOString().split('T')[0];
    const lastDate = stats?.lastActiveDate || "";

    if (lastDate === today) return;

    let newStreak = 1;
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    if (lastDate === yesterdayStr) {
      newStreak = (stats?.currentStreak || 0) + 1;
    }

    const badges = [...(stats?.badges || [])];
    if (newStreak === 7 && !badges.includes("7-day-streak")) badges.push("7-day-streak");
    if (newStreak === 30 && !badges.includes("30-day-streak")) badges.push("30-day-streak");
    if (newStreak === 100 && !badges.includes("100-day-streak")) badges.push("100-day-streak");

    setDoc(statsRef, {
      currentStreak: newStreak,
      lastActiveDate: today,
      totalActiveDays: (stats?.totalActiveDays || 0) + 1,
      badges
    }, { merge: true });

  }, [user, stats]);

  return (
    <Card className="border-none shadow-md overflow-hidden bg-white">
      <CardHeader className="p-4 bg-orange-50 flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <Flame className="h-4 w-4 text-orange-500" />
          <CardTitle className="text-sm">Activity Streak</CardTitle>
        </div>
        <div className="bg-orange-500 text-white px-2 py-0.5 rounded-full text-[10px] font-bold">
          {stats?.currentStreak || 0} DAYS
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="flex flex-col items-center gap-4">
          <div className="h-16 w-16 bg-orange-100 rounded-full flex items-center justify-center text-orange-600">
             <Flame className="h-8 w-8 fill-current" />
          </div>
          <div className="text-center space-y-1">
             <p className="font-bold text-lg">{stats?.currentStreak || 0} Day Streak!</p>
             <p className="text-xs text-muted-foreground">Keep learning every day to maintain your momentum.</p>
          </div>
          <div className="flex flex-wrap justify-center gap-2 pt-2">
             {stats?.badges?.map((badge: string) => (
               <Badge key={badge} className="bg-yellow-100 text-yellow-700 hover:bg-yellow-100 border-yellow-200 text-[8px] h-5 uppercase">
                 <Star className="h-2 w-2 mr-1 fill-current" /> {badge.replace(/-/g, ' ')}
               </Badge>
             ))}
             {(!stats?.badges || stats.badges.length === 0) && (
               <p className="text-[9px] font-bold text-muted-foreground uppercase opacity-50">No badges earned yet</p>
             )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
