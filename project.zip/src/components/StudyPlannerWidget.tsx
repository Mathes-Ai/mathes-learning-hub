
"use client";

import { useMemo } from "react";
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, where, orderBy, doc, updateDoc } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { LayoutList, CheckCircle2, Circle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import Link from "next/link";

export function StudyPlannerWidget() {
  const { user } = useUser();
  const db = useFirestore();

  const today = new Date().toISOString().split('T')[0];
  const tasksQuery = useMemoFirebase(() => 
    user ? query(collection(db, "users", user.uid, "tasks"), where("date", "==", today)) : null,
    [db, user, today]
  );
  const { data: tasks } = useCollection(tasksQuery);

  const completed = tasks.filter(t => t.completed).length;
  const progress = tasks.length > 0 ? Math.round((completed / tasks.length) * 100) : 0;

  const toggleTask = (taskId: string, current: boolean) => {
    if (!user) return;
    updateDoc(doc(db, "users", user.uid, "tasks", taskId), { completed: !current });
  };

  return (
    <Card className="border-none shadow-lg ring-1 ring-border rounded-[2rem] overflow-hidden bg-white">
      <CardHeader className="p-6 bg-slate-50/50 flex flex-row items-center justify-between border-b">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-2 rounded-xl">
            <LayoutList className="h-4 w-4 text-primary" />
          </div>
          <CardTitle className="text-sm font-bold uppercase tracking-widest text-slate-700">Today's Agenda</CardTitle>
        </div>
        <Button variant="ghost" size="sm" asChild className="h-8 text-[10px] font-bold uppercase tracking-widest text-primary hover:bg-primary/5">
          <Link href="/dashboard/student/planner" className="flex items-center gap-1">
            Edit Planner <ArrowRight className="h-3 w-3" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent className="p-8 space-y-6">
        <div className="space-y-4">
          {tasks.slice(0, 3).map((task) => (
            <div key={task.id} className="flex items-center justify-between group">
              <div className="flex items-center gap-4 min-w-0">
                <button 
                  onClick={() => toggleTask(task.id, task.completed)}
                  className={`h-5 w-5 rounded-full border-2 transition-all flex items-center justify-center shrink-0 ${task.completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-300 group-hover:border-primary'}`}
                >
                  {task.completed && <CheckCircle2 className="h-3 w-3" />}
                </button>
                <p className={`text-sm font-medium truncate max-w-[300px] ${task.completed ? 'text-muted-foreground line-through' : 'text-slate-700'}`}>
                  {task.title}
                </p>
              </div>
              <span className="text-[9px] font-bold text-muted-foreground uppercase opacity-40">{task.subject}</span>
            </div>
          ))}
          {tasks.length === 0 && (
            <div className="py-4 text-center">
              <p className="text-xs text-muted-foreground font-medium italic">No tasks scheduled for today.</p>
            </div>
          )}
          {tasks.length > 3 && (
            <p className="text-[10px] text-primary font-bold text-center pt-2">+{tasks.length - 3} MORE TASKS IN PLANNER</p>
          )}
        </div>

        <div className="pt-6 border-t space-y-3">
           <div className="flex justify-between items-end">
             <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Completion Depth</span>
             <span className="text-lg font-bold text-primary">{progress}%</span>
           </div>
           <Progress value={progress} className="h-2 rounded-full" />
        </div>
      </CardContent>
    </Card>
  );
}
