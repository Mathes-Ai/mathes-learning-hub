'use client';

import { useFirebaseStatus } from '@/firebase';
import { WifiOff, RefreshCw, Loader2, CheckCircle2 } from 'lucide-react';
import { useEffect, useState } from 'react';

export function FirebaseStatusBanner() {
  const status = useFirebaseStatus();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (status !== 'online') {
      setVisible(true);
    } else {
      const timer = setTimeout(() => setVisible(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [status]);

  if (!visible) return null;

  const config = {
    offline: {
      bg: 'bg-destructive',
      icon: <WifiOff className="h-3 w-3" />,
      text: 'Offline: Mathes Learning Hub is currently disconnected.',
    },
    reconnecting: {
      bg: 'bg-amber-500',
      icon: <Loader2 className="h-3 w-3 animate-spin" />,
      text: 'Reconnecting to Mathes Learning Hub backend...',
    },
    online: {
      bg: 'bg-emerald-500',
      icon: <CheckCircle2 className="h-3 w-3" />,
      text: 'Synchronized with Mathes Learning Hub database.',
    }
  };

  const current = config[status as keyof typeof config];

  return (
    <div className={`w-full py-1.5 px-6 flex items-center justify-center gap-3 text-[10px] font-bold uppercase tracking-widest text-white animate-in fade-in slide-in-from-top-2 duration-500 z-50 transition-colors ${current.bg}`}>
      {current.icon}
      <span>{current.text}</span>
    </div>
  );
}
