
"use client";

import { useMemo } from "react";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, orderBy, limit } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Newspaper, ArrowRight, ChevronRight, Zap } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function CurrentAffairsWidget() {
  const db = useFirestore();
  const newsQuery = useMemoFirebase(() => 
    query(collection(db, "current_affairs"), orderBy("date", "desc"), limit(3)),
    [db]
  );
  const { data: newsItems } = useCollection(newsQuery);

  return (
    <Card className="border-none shadow-lg ring-1 ring-border rounded-[2rem] overflow-hidden bg-white">
      <CardHeader className="p-6 bg-slate-50/50 flex flex-row items-center justify-between border-b">
        <div className="flex items-center gap-3">
          <div className="bg-accent/10 p-2 rounded-xl">
            <Newspaper className="h-4 w-4 text-accent" />
          </div>
          <CardTitle className="text-sm font-bold uppercase tracking-widest text-slate-700">Exam Briefing</CardTitle>
        </div>
        <Button variant="ghost" size="sm" asChild className="h-8 text-[10px] font-bold uppercase tracking-widest text-accent hover:bg-accent/5">
          <Link href="/dashboard/current-affairs" className="flex items-center gap-1">
            ALL NEWS <ArrowRight className="h-3 w-3" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent className="p-8">
        <div className="space-y-6">
          {newsItems.map((n) => (
            <Link key={n.id} href="/dashboard/current-affairs" className="block group">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-2 min-w-0">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[8px] h-4 py-0 font-bold border-accent/20 text-accent uppercase tracking-tighter">
                      {n.category}
                    </Badge>
                    <span className="text-[9px] font-bold text-muted-foreground">{new Date(n.date).toLocaleDateString()}</span>
                  </div>
                  <h4 className="font-bold text-sm leading-tight text-slate-800 group-hover:text-primary transition-colors line-clamp-2">
                    {n.title}
                  </h4>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-all group-hover:translate-x-1 shrink-0" />
              </div>
            </Link>
          ))}
          {newsItems.length === 0 && (
            <div className="py-4 text-center">
              <p className="text-xs text-muted-foreground font-medium italic">Synchronizing with today's headlines...</p>
            </div>
          )}
        </div>

        <div className="pt-8 border-t mt-8">
           <div className="bg-accent/5 p-4 rounded-2xl flex gap-3 items-center border border-accent/10">
              <Zap className="h-4 w-4 text-accent" />
              <p className="text-[10px] text-accent font-bold uppercase tracking-widest leading-none">Stay Ahead of the Curve</p>
           </div>
        </div>
      </CardContent>
    </Card>
  );
}
