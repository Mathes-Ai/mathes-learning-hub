
"use client";

import { useState, useEffect, useMemo } from "react";
import { useFirestore, useUser, useDoc } from "@/firebase";
import { doc, setDoc } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Timer, Calendar, Target, Edit2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const EXAMS = [
  { name: "UGC NET", date: "2025-06-15T09:00:00" },
  { name: "TNPSC Group 4", date: "2025-07-20T10:00:00" },
  { name: "SSC CGL", date: "2025-09-10T10:00:00" },
  { name: "Banking (IBPS PO)", date: "2025-10-05T09:00:00" },
  { name: "RRB NTPC", date: "2025-11-12T10:00:00" },
];

export function ExamCountdown() {
  const { user } = useUser();
  const db = useFirestore();
  const [isEditing, setIsEditing] = useState(false);

  const prefRef = useMemo(() => (user ? doc(db, "users", user.uid, "preferences", "settings") : null), [db, user]);
  const { data: preferences } = useDoc(prefRef);

  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; mins: number; secs: number } | null>(null);

  const currentExam = useMemo(() => {
    return EXAMS.find(e => e.name === preferences?.targetExam) || null;
  }, [preferences]);

  useEffect(() => {
    if (!currentExam) return;

    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const target = new Date(currentExam.date).getTime();
      const distance = target - now;

      if (distance <= 0) {
        return { days: 0, hours: 0, mins: 0, secs: 0 };
      }

      return {
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        mins: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        secs: Math.floor((distance % (1000 * 60)) / 1000),
      };
    };

    // Initial sync
    setTimeLeft(calculateTimeLeft());

    const timer = setInterval(() => {
      const updated = calculateTimeLeft();
      setTimeLeft(updated);
      
      if (updated.days === 0 && updated.hours === 0 && updated.mins === 0 && updated.secs === 0) {
        clearInterval(timer);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [currentExam]);

  const handleSelect = (examName: string) => {
    if (!prefRef) return;
    const exam = EXAMS.find(e => e.name === examName);
    setDoc(prefRef, { targetExam: examName, targetExamDate: exam?.date }, { merge: true });
    setIsEditing(false);
  };

  const isExamDay = timeLeft?.days === 0 && timeLeft?.hours === 0 && timeLeft?.mins === 0 && timeLeft?.secs === 0;

  return (
    <Card className="border-none shadow-lg overflow-hidden bg-white group">
      <CardHeader className="p-4 bg-accent/5 flex flex-row items-center justify-between border-b border-accent/10">
        <div className="flex items-center gap-2">
          <div className="bg-accent/10 p-1.5 rounded-lg">
            <Timer className="h-4 w-4 text-accent animate-pulse" />
          </div>
          <CardTitle className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Focus Clock</CardTitle>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-accent hover:bg-accent/5" onClick={() => setIsEditing(!isEditing)}>
          <Edit2 className="h-3.5 w-3.5" />
        </Button>
      </CardHeader>
      <CardContent className="p-6">
        {isEditing || !currentExam ? (
          <div className="space-y-4 py-2">
            <div className="flex items-center gap-2 mb-2">
               <Target className="h-4 w-4 text-primary" />
               <p className="text-xs font-bold text-slate-700">Set Your 2025/26 Goal</p>
            </div>
            <Select onValueChange={handleSelect} defaultValue={preferences?.targetExam}>
              <SelectTrigger className="h-11 rounded-xl border-slate-200 shadow-sm">
                <SelectValue placeholder="Select Target Exam" />
              </SelectTrigger>
              <SelectContent>
                {EXAMS.map(e => (
                  <SelectItem key={e.name} value={e.name} className="font-medium">{e.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Selecting a target exam enables Mathes Learning Hub to personalize your mock test schedule and study reminders.
            </p>
          </div>
        ) : (
          <div className="text-center space-y-5">
            <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-primary/5 border border-primary/10 mb-2">
              <Sparkles className="h-3 w-3 text-primary" />
              <span className="text-[10px] font-bold text-primary uppercase tracking-wider">{currentExam.name}</span>
            </div>

            {isExamDay ? (
              <div className="py-4 animate-bounce">
                 <h3 className="text-3xl font-headline font-bold text-emerald-600">EXAM DAY!</h3>
                 <p className="text-xs text-muted-foreground font-medium mt-1 uppercase tracking-widest">Go and Conquer.</p>
              </div>
            ) : (
              <div className="grid grid-cols-4 gap-2">
                <div className="bg-slate-50 border border-slate-100 p-3 rounded-2xl shadow-sm group-hover:bg-primary/5 group-hover:border-primary/20 transition-colors">
                  <p className="text-xl md:text-2xl font-bold text-primary leading-none">{timeLeft?.days || 0}</p>
                  <p className="text-[7px] md:text-[8px] uppercase font-bold text-muted-foreground mt-1 tracking-tighter">Days</p>
                </div>
                <div className="bg-slate-50 border border-slate-100 p-3 rounded-2xl shadow-sm group-hover:bg-primary/5 group-hover:border-primary/20 transition-colors">
                  <p className="text-xl md:text-2xl font-bold text-primary leading-none">{timeLeft?.hours || 0}</p>
                  <p className="text-[7px] md:text-[8px] uppercase font-bold text-muted-foreground mt-1 tracking-tighter">Hours</p>
                </div>
                <div className="bg-slate-50 border border-slate-100 p-3 rounded-2xl shadow-sm group-hover:bg-primary/5 group-hover:border-primary/20 transition-colors">
                  <p className="text-xl md:text-2xl font-bold text-primary leading-none">{timeLeft?.mins || 0}</p>
                  <p className="text-[7px] md:text-[8px] uppercase font-bold text-muted-foreground mt-1 tracking-tighter">Mins</p>
                </div>
                <div className="bg-primary p-3 rounded-2xl shadow-lg shadow-primary/20">
                  <p className="text-xl md:text-2xl font-bold text-white leading-none">{timeLeft?.secs || 0}</p>
                  <p className="text-[7px] md:text-[8px] uppercase font-bold text-white/80 mt-1 tracking-tighter">Secs</p>
                </div>
              </div>
            )}

            <div className="flex items-center justify-center gap-2 text-[10px] font-bold text-muted-foreground uppercase pt-2">
              <Calendar className="h-3.5 w-3.5" />
              Target: {new Date(currentExam.date).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

