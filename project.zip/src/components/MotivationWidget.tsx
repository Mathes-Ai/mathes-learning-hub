
"use client";

import { useState, useEffect, useMemo } from "react";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection } from "firebase/firestore";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, Quote as QuoteIcon } from "lucide-react";

const DEFAULT_QUOTES = [
  { tamil: "வெற்றி என்பது இறுதி அல்ல, தோல்வி என்பது முடிவல்ல; தொடரும் துணிவே முக்கியமானது.", english: "Success is not final, failure is not fatal: it is the courage to continue that counts." },
  { tamil: "கடின உழைப்பு எப்போதும் பலன் தரும்.", english: "Hard work always pays off." },
  { tamil: "முயற்சி திருவினையாக்கும்.", english: "Effort results in success." }
];

export function MotivationWidget() {
  const db = useFirestore();
  const quotesRef = useMemoFirebase(() => collection(db, "quotes"), [db]);
  const { data: dbQuotes } = useCollection(quotesRef);
  
  const [shuffledQueue, setShuffledQueue] = useState<number[]>([]);
  const [queuePos, setQueuePos] = useState(0);

  const displayQuotes = useMemo(() => {
    return dbQuotes.length > 0 ? dbQuotes : DEFAULT_QUOTES;
  }, [dbQuotes]);

  const shuffle = (array: number[]) => {
    const newArr = [...array];
    for (let i = newArr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newArr[i], newArr[j]] = [newArr[j], newArr[i]];
    }
    return newArr;
  };

  useEffect(() => {
    if (displayQuotes.length > 0) {
      const indices = Array.from({ length: displayQuotes.length }, (_, i) => i);
      setShuffledQueue(shuffle(indices));
      setQueuePos(0);
    }
  }, [displayQuotes.length]);

  useEffect(() => {
    if (shuffledQueue.length <= 1) return;
    
    const interval = setInterval(() => {
      setQueuePos((prevPos) => {
        const nextPos = prevPos + 1;
        if (nextPos >= shuffledQueue.length) {
          const indices = Array.from({ length: displayQuotes.length }, (_, i) => i);
          let newQueue = shuffle(indices);
          if (newQueue[0] === shuffledQueue[prevPos] && newQueue.length > 1) {
            [newQueue[0], newQueue[1]] = [newQueue[1], newQueue[0]];
          }
          setShuffledQueue(newQueue);
          return 0;
        }
        return nextPos;
      });
    }, 10000);

    return () => clearInterval(interval);
  }, [shuffledQueue, displayQuotes.length]);

  const currentIdx = shuffledQueue[queuePos] ?? 0;
  const current = displayQuotes[currentIdx] || DEFAULT_QUOTES[0];

  return (
    <Card className="border-none shadow-lg overflow-hidden bg-primary text-primary-foreground relative min-h-[130px] flex flex-col justify-center">
      <div className="absolute -right-8 -top-8 h-32 w-32 bg-white/10 rounded-full blur-2xl transition-all duration-700" />
      <div className="absolute -left-8 -bottom-8 h-24 w-24 bg-accent/20 rounded-full blur-xl opacity-50" />
      
      <CardContent className="p-5 md:p-8 space-y-3 relative z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-white/20 p-1.5 rounded-lg backdrop-blur-sm">
              <Sparkles className="h-3 w-3 text-yellow-300 animate-pulse" />
            </div>
            <span className="text-[8px] font-bold uppercase tracking-[0.2em] opacity-60">Mathes Intelligence • Daily Insight</span>
          </div>
          <span className="text-[7px] font-bold opacity-30 uppercase tracking-tighter">
            SYNC: {queuePos + 1} / {displayQuotes.length}
          </span>
        </div>
        
        <div 
          key={current.tamil}
          className="space-y-2 animate-in fade-in duration-1000"
        >
          <div className="relative">
            <QuoteIcon className="h-4 w-4 text-white/10 absolute -left-4 -top-2 rotate-180" />
            <p className="text-base md:text-xl font-headline font-bold leading-tight tracking-tight">
              {current.tamil}
            </p>
          </div>
          
          <p className="text-[10px] md:text-sm font-medium text-primary-foreground/70 italic leading-relaxed font-body">
            {current.english}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
