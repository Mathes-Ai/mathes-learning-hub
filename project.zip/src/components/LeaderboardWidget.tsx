"use client";

import { useMemo } from "react";
import { useFirestore, useCollection } from "@/firebase";
import { collection, query, orderBy, limit } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Trophy, Medal, Crown, Star } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export function LeaderboardWidget() {
  const db = useFirestore();
  const attemptsQuery = useMemo(() => 
    query(collection(db, "test_attempts"), orderBy("finalScore", "desc"), limit(20)),
    [db]
  );
  const { data: attempts } = useCollection(attemptsQuery);

  const topStudents = useMemo(() => {
    const aggregated: Record<string, { name: string, points: number }> = {};
    attempts.forEach(a => {
      if (!aggregated[a.studentId]) aggregated[a.studentId] = { name: a.studentName, points: 0 };
      aggregated[a.studentId].points += Math.max(0, a.finalScore);
    });
    return Object.entries(aggregated)
      .map(([id, data]) => ({ id, ...data }))
      .sort((a, b) => b.points - a.points)
      .slice(0, 5);
  }, [attempts]);

  return (
    <Card className="border-none shadow-md overflow-hidden bg-white">
      <CardHeader className="p-4 bg-primary/5 flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <Trophy className="h-4 w-4 text-primary" />
          <CardTitle className="text-sm">Mathes Learning Hub Standings</CardTitle>
        </div>
        <Button variant="ghost" size="sm" asChild className="h-7 text-[10px] font-bold">
          <Link href="/dashboard/quizzes/rankings">VIEW ALL</Link>
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y">
          {topStudents.map((s, i) => (
            <div key={s.id} className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-6 text-xs font-bold text-muted-foreground">
                  {i === 0 ? <Crown className="h-4 w-4 text-yellow-500" /> : `#${i + 1}`}
                </div>
                <div>
                  <p className="text-sm font-bold truncate max-w-[120px]">{s.name}</p>
                  <div className="flex items-center gap-1">
                    <Star className="h-2 w-2 text-yellow-500 fill-yellow-500" />
                    <span className="text-[10px] text-muted-foreground uppercase font-bold">Academic Points</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-sm font-bold text-primary">{Math.round(s.points)}</span>
              </div>
            </div>
          ))}
          {topStudents.length === 0 && (
            <div className="p-8 text-center text-[10px] text-muted-foreground italic">
              Competition at Mathes Learning Hub hasn't started yet!
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
