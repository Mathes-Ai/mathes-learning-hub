
'use client';

import { useEffect } from 'react';
import { errorEmitter } from '@/firebase/error-emitter';
import { useToast } from '@/hooks/use-toast';

export function FirebaseErrorListener() {
  const { toast } = useToast();

  useEffect(() => {
    const handlePermissionError = (error: any) => {
      // Surfacing to Next.js error overlay in development
      if (process.env.NODE_ENV === 'development') {
        throw error;
      }
      
      toast({
        variant: "destructive",
        title: "Permission Denied",
        description: "You don't have permission to perform this action.",
      });
    };

    errorEmitter.on('permission-error', handlePermissionError);
    return () => {
      errorEmitter.off('permission-error', handlePermissionError);
    };
  }, [toast]);

  return null;
}
