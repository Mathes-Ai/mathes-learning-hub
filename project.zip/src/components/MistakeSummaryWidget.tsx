
"use client";

import { useMemo } from "react";
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query } from "firebase/firestore";
import { Card } from "@/components/ui/card";
import { XCircle, ChevronRight, AlertTriangle } from "lucide-react";
import Link from "next/link";

export function MistakeSummaryWidget() {
  const { user } = useUser();
  const db = useFirestore();

  const mistakesQuery = useMemoFirebase(() => 
    user ? query(collection(db, "users", user.uid, "mistakes")) : null,
    [db, user]
  );
  const { data: mistakes } = useCollection(mistakesQuery);

  return (
    <Card className="border-none shadow-lg overflow-hidden bg-white hover:scale-[1.02] transition-transform" asChild>
      <Link href="/dashboard/student/mistakes" className="block p-6 hover:bg-muted/10 transition-colors">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-red-100 p-3 rounded-2xl">
              <XCircle className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <p className="text-sm font-bold">Mistake Book</p>
              <div className="flex items-center gap-2">
                 <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Failed Questions</p>
                 {mistakes.length > 5 && (
                   <span className="flex items-center gap-1 text-[10px] text-red-600 font-bold bg-red-50 px-1.5 rounded animate-pulse">
                     <AlertTriangle className="h-2.5 w-2.5" /> REVISE NOW
                   </span>
                 )}
              </div>
            </div>
          </div>
          <div className="text-right flex items-center gap-3">
             <span className="text-xl font-bold text-red-600">{mistakes.length}</span>
             <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </div>
        </div>
      </Link>
    </Card>
  );
}
