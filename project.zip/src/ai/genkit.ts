import {genkit} from 'genkit';
import {googleAI} from '@genkit-ai/google-genai';

/**
 * Genkit instance configured for Google AI (Gemini).
 * Uses the GOOGLE_GENAI_API_KEY or GEMINI_API_KEY environment variable.
 */
export const ai = genkit({
  plugins: [googleAI()],
  model: 'googleai/gemini-2.5-flash',
});
