import { config } from 'dotenv';
config();

import '@/ai/flows/explain-concept-flow.ts';
import '@/ai/flows/summarize-material-flow.ts';
import '@/ai/flows/generate-quiz-flow.ts';