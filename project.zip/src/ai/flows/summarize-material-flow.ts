'use server';
/**
 * @fileOverview This file implements a Genkit flow for summarizing study materials or explaining complex sections.
 *
 * - summarizeMaterial - A function that takes study material content and provides a summary or explanation.
 * - SummarizeMaterialInput - The input type for the summarizeMaterial function.
 * - SummarizeMaterialOutput - The return type for the summarizeMaterial function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeMaterialInputSchema = z.object({
  materialContent: z
    .string()
    .describe('The content of the study material (e.g., PDF text, course chapter text).'),
  language: z.enum(['English', 'Tamil']).describe('The preferred language for the summary or explanation.'),
  requestType: z
    .enum(['summary', 'explanation'])
    .describe(
      'The type of request: "summary" for a concise overview or "explanation" for simplifying a complex section.'
    ),
  complexSection:
    z.string().optional().describe('Optional: If requestType is "explanation", the specific complex section to explain in simpler terms.'),
});
export type SummarizeMaterialInput = z.infer<typeof SummarizeMaterialInputSchema>;

const SummarizeMaterialOutputSchema = z.object({
  generatedText: z.string().describe('The generated summary or explanation of the study material.'),
});
export type SummarizeMaterialOutput = z.infer<typeof SummarizeMaterialOutputSchema>;

export async function summarizeMaterial(
  input: SummarizeMaterialInput
): Promise<SummarizeMaterialOutput> {
  return summarizeMaterialFlow(input);
}

const summarizeMaterialPrompt = ai.definePrompt({
  name: 'summarizeMaterialPrompt',
  input: {schema: SummarizeMaterialInputSchema},
  output: {schema: SummarizeMaterialOutputSchema},
  prompt: `You are an expert tutor for mathematical and scientific concepts. Your goal is to help students understand their study materials.
The student has provided the following study material content:

Study Material:
{{{materialContent}}}

{{#if complexSection}}
The student wants you to explain the following complex section in simpler terms, using the provided study material as context.
Complex Section to Explain: "{{{complexSection}}}"
{{else}}
The student wants a concise summary of the key points from the provided study material.
{{/if}}

Please provide the output in {{language}}.`,
});

const summarizeMaterialFlow = ai.defineFlow(
  {
    name: 'summarizeMaterialFlow',
    inputSchema: SummarizeMaterialInputSchema,
    outputSchema: SummarizeMaterialOutputSchema,
  },
  async (input) => {
    const {output} = await summarizeMaterialPrompt(input);
    return output!;
  }
);
