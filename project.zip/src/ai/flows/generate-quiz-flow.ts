'use server';
/**
 * @fileOverview A Genkit flow for generating interactive quizzes based on a topic and difficulty.
 *
 * - generateQuiz - A function that handles the quiz generation process.
 * - GenerateQuizInput - The input type for the generateQuiz function.
 * - GenerateQuizOutput - The return type for the generateQuiz function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateQuizInputSchema = z.object({
  topic: z.string().describe('The subject or topic for which to generate the quiz.'),
  difficulty: z.enum(['easy', 'medium', 'hard']).describe('The desired difficulty level of the quiz.'),
});
export type GenerateQuizInput = z.infer<typeof GenerateQuizInputSchema>;

const QuestionSchema = z.object({
  id: z.string().describe('Unique ID for the question.'),
  type: z.enum(['multiple_choice', 'true_false', 'fill_in_the_blank']).describe('Type of the question.'),
  questionText: z.string().describe('The text of the question. For fill-in-the-blank, use ___ for the blank.'),
  options: z.array(z.string()).optional().describe('Options for multiple choice questions.'),
  correctAnswer: z.union([z.number(), z.boolean(), z.string()]).describe('The correct answer. Index for MC, boolean for T/F, string for Fill.'),
  explanation: z.string().optional().describe('A brief explanation of why the answer is correct.'),
});

const GenerateQuizOutputSchema = z.object({
  title: z.string().describe('The title of the quiz.'),
  questions: z.array(QuestionSchema).describe('An array of 5 generated quiz questions.'),
});
export type GenerateQuizOutput = z.infer<typeof GenerateQuizOutputSchema>;

export async function generateQuiz(input: GenerateQuizInput): Promise<GenerateQuizOutput> {
  return generateQuizFlow(input);
}

const quizPrompt = ai.definePrompt({
  name: 'generateQuizPrompt',
  input: { schema: GenerateQuizInputSchema },
  output: { schema: GenerateQuizOutputSchema },
  prompt: `You are an expert academic assessment creator for Mathes Learning Hub. 
  Create a comprehensive quiz about "{{{topic}}}" at a "{{{difficulty}}}" level.
  
  Generate exactly 5 questions of various types:
  1. Multiple Choice (provide 4 options)
  2. True/False
  3. Fill in the Blank (use "___" in the question text)

  Ensure the questions are challenging and educational. Provide clear explanations for each answer.`,
});

const generateQuizFlow = ai.defineFlow(
  {
    name: 'generateQuizFlow',
    inputSchema: GenerateQuizInputSchema,
    outputSchema: GenerateQuizOutputSchema,
  },
  async (input) => {
    const { output } = await quizPrompt(input);
    if (!output) throw new Error('Failed to generate quiz');
    return output;
  }
);
