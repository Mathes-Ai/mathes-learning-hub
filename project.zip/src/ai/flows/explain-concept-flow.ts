'use server';
/**
 * @fileOverview A Genkit flow that acts as an AI Concept Tutor, providing personalized,
 * step-by-step explanations for math or science concepts in the user's preferred language.
 *
 * - explainConcept - A function that handles the concept explanation process.
 * - ExplainConceptInput - The input type for the explainConcept function.
 * - ExplainConceptOutput - The return type for the explainConcept function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ExplainConceptInputSchema = z.object({
  question: z
    .string()
    .describe('The challenging math or science concept question.'),
  language: z
    .enum(['English', 'Tamil'])
    .describe('The preferred language for the explanation (English or Tamil).'),
});
export type ExplainConceptInput = z.infer<typeof ExplainConceptInputSchema>;

const ExplainConceptOutputSchema = z.object({
  explanation: z
    .string()
    .describe('A personalized, step-by-step explanation of the concept.'),
});
export type ExplainConceptOutput = z.infer<typeof ExplainConceptOutputSchema>;

export async function explainConcept(
  input: ExplainConceptInput
): Promise<ExplainConceptOutput> {
  return explainConceptFlow(input);
}

const explainConceptPrompt = ai.definePrompt({
  name: 'explainConceptPrompt',
  input: {schema: ExplainConceptInputSchema},
  output: {schema: ExplainConceptOutputSchema},
  prompt: `You are an expert AI Concept Tutor specializing in math and science. Your goal is to provide clear, personalized, and step-by-step explanations for challenging concepts to a student.

The student has asked the following question:
Question: {{{question}}}

Please provide a detailed, step-by-step explanation in the '{{{language}}}' language. Focus on breaking down the concept into easily understandable parts and guide the student through the solution or understanding.
`,
});

const explainConceptFlow = ai.defineFlow(
  {
    name: 'explainConceptFlow',
    inputSchema: ExplainConceptInputSchema,
    outputSchema: ExplainConceptOutputSchema,
  },
  async input => {
    const {output} = await explainConceptPrompt(input);
    if (!output) {
      throw new Error('Failed to generate explanation.');
    }
    return output;
  }
);
