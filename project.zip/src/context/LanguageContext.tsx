"use client";

import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'English' | 'Tamil';

type Dictionary = {
  [key: string]: {
    English: string;
    Tamil: string;
  };
};

const dictionary: Dictionary = {
  welcome: { English: 'Welcome', Tamil: 'வரவேற்கிறோம்' },
  dashboard: { English: 'Dashboard', Tamil: 'டாஷ்போர்டு' },
  courses: { English: 'Courses', Tamil: 'பாடங்கள்' },
  quizzes: { English: 'Quizzes', Tamil: 'வினாடி வினாக்கள்' },
  aiTutor: { English: 'AI Tutor', Tamil: 'AI பயிற்றுவிப்பாளர்' },
  notifications: { English: 'Notifications', Tamil: 'அறிவிப்புகள்' },
  profile: { English: 'Profile', Tamil: 'சுயவிவரம்' },
  logout: { English: 'Logout', Tamil: 'வெளியேறு' },
  search: { English: 'Search', Tamil: 'தேடு' },
  materials: { English: 'Study Materials', Tamil: 'படிப்பு பொருட்கள்' },
  videos: { English: 'Video Classes', Tamil: 'வீடியோ வகுப்புகள்' },
  settings: { English: 'Settings', Tamil: 'அமைப்புகள்' },
  admin: { English: 'Admin', Tamil: 'நிர்வாகி' },
  teacher: { English: 'Teacher', Tamil: 'ஆசிரியர்' },
  student: { English: 'Student', Tamil: 'மாணவர்' },
  askAi: { English: 'Ask AI', Tamil: 'AI-யிடம் கேளுங்கள்' },
  language: { English: 'Language', Tamil: 'மொழி' },
  aboutUs: { English: 'About Us', Tamil: 'எங்களைப் பற்றி' },
  whyChooseUs: { English: 'Why Choose Us', Tamil: 'ஏன் எங்களைத் தேர்ந்தெடுக்க வேண்டும்?' },
  testimonials: { English: 'Student Testimonials', Tamil: 'மாணவர் கருத்துக்கள்' },
  contactUs: { English: 'Contact Us', Tamil: 'தொடர்பு கொள்ள' },
  joinNow: { English: 'Join Now', Tamil: 'இப்பொழுதே இணையுங்கள்' },
  heroSubtitle: { English: 'World-class coaching for UPSC, TNPSC, Banking and more at Mathes Learning Hub.', Tamil: 'Mathes Learning Hub-இல் UPSC, TNPSC, வங்கித் தேர்வுகள் மற்றும் பலவற்றிற்கான உலகத்தரம் வாய்ந்த பயிற்சி.' },
  ourMission: { English: 'Our Mission', Tamil: 'எங்கள் நோக்கம்' },
  missionDesc: { 
    English: 'To provide accessible, affordable, and high-quality competitive exam coaching to every aspiring candidate through Mathes Learning Hub.',
    Tamil: 'Mathes Learning Hub மூலம் ஒவ்வொரு ஆர்வமுள்ள விண்ணப்பதாரருக்கும் அணுகக்கூடிய, மலிவு மற்றும் உயர்தர போட்டித் தேர்வு பயிற்சியை வழங்குவது.'
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('English');

  const t = (key: string) => {
    return dictionary[key]?.[language] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
