'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  BookOpen, 
  GraduationCap, 
  School, 
  ChevronRight, 
  Globe, 
  Loader2, 
  Sparkles, 
  Video, 
  MessageSquare, 
  ShieldCheck, 
  Target, 
  Users, 
  Star,
  ArrowRight,
  Phone,
  Mail,
  MapPin,
  Lock,
  UserCheck,
  ShieldAlert
} from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { useAuth, useFirestore, useUser } from '@/firebase';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { cn } from '@/lib/utils';

export default function LandingPage() {
  const router = useRouter();
  const { language, setLanguage, t } = useLanguage();
  const { toast } = useToast();
  const auth = useAuth();
  const db = useFirestore();
  const { user, loading: authLoading } = useUser();
  
  const [role, setRole] = useState<'student' | 'teacher' | 'admin'>('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [showChat, setShowChat] = useState(true);

  // Persistence logic: Automatically redirect if already logged in
  useEffect(() => {
    if (!authLoading && user) {
      const checkSession = async () => {
        try {
          const userDocRef = doc(db, 'users', user.uid);
          const userDoc = await getDoc(userDocRef);
          if (userDoc.exists()) {
            const userRole = userDoc.data().role;
            router.replace(`/dashboard/${userRole}`);
          } else {
            // Fallback for missing profile
            router.replace('/dashboard/student');
          }
        } catch (e) {
          console.error("Session restore failed:", e);
        }
      };
      checkSession();
    }
  }, [user, authLoading, db, router]);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      if (scrollY > 100) {
        setShowChat(false);
      } else {
        setShowChat(true);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (isRegistering) {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        const assignedRole = email.toLowerCase() === 'mathesviswa@gmail.com' ? 'admin' : role;
        const displayName = email.split('@')[0];
        
        await updateProfile(user, { displayName });

        const userRef = doc(db, 'users', user.uid);
        const userData = {
          uid: user.uid,
          email: user.email,
          role: assignedRole,
          displayName: displayName,
          createdAt: new Date().toISOString(),
        };

        await setDoc(userRef, userData, { merge: true });
        
        toast({ title: "Account Created", description: `Welcome to Mathes Learning Hub, ${displayName}!` });
        router.push(`/dashboard/${assignedRole}`);
      } else {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const userDocRef = doc(db, 'users', userCredential.user.uid);
        const userDoc = await getDoc(userDocRef);
        
        if (userDoc.exists()) {
          const userRole = userDoc.data().role;
          toast({ title: "Login Successful", description: `Redirecting to Mathes Learning Hub ${userRole} dashboard...` });
          router.push(`/dashboard/${userRole}`);
        } else {
          const fallbackRole = email.toLowerCase() === 'mathesviswa@gmail.com' ? 'admin' : 'student';
          router.push(`/dashboard/${fallbackRole}`);
        }
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Authentication Failed",
        description: error.message || "Please check your credentials.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleWhatsApp = () => {
    window.open(`https://wa.me/919876543210?text=Hi Mathes Learning Hub Support, I want to know more about your courses.`, "_blank");
  };

  if (authLoading || user) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center space-y-4">
        <div className="bg-primary p-4 rounded-3xl animate-bounce shadow-2xl">
          <GraduationCap className="text-white h-12 w-12" />
        </div>
        <div className="flex items-center gap-2 text-primary font-headline font-bold">
          <Loader2 className="h-4 w-4 animate-spin" />
          Restoring Mathes Learning Hub Session...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background selection:bg-primary selection:text-white pb-20">
      <nav className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="bg-primary p-2 rounded-xl">
              <GraduationCap className="text-white h-6 w-6" />
            </div>
            <span className="text-2xl font-headline font-bold text-primary tracking-tight">
              Mathes Learning Hub
            </span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#about" className="text-sm font-semibold hover:text-primary transition-colors">{t('aboutUs')}</a>
            <a href="#courses" className="text-sm font-semibold hover:text-primary transition-colors">{t('courses')}</a>
            <a href="#auth" className="text-sm font-semibold hover:text-primary transition-colors">{t('joinNow')}</a>
          </div>

          <div className="flex items-center gap-3">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setLanguage(language === 'English' ? 'Tamil' : 'English')}
              className="rounded-full gap-2 font-bold"
            >
              <Globe className="h-4 w-4" />
              {language === 'English' ? 'தமிழ்' : 'English'}
            </Button>
            <Button asChild size="sm" className="rounded-full px-6 shadow-lg shadow-primary/20">
              <a href="#auth">{t('student')} Login</a>
            </Button>
          </div>
        </div>
      </nav>

      <section id="hero" className="relative pt-20 pb-32 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 relative z-10">
            <Badge variant="secondary" className="px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest text-primary bg-primary/10">
              New: AI-Powered Mathes Learning Hub
            </Badge>
            <h1 className="text-6xl lg:text-7xl font-headline font-bold text-slate-900 leading-[1.1]">
              {language === 'English' 
                ? 'Empowering Minds Through Expert Coaching.' 
                : 'நிபுணத்துவ பயிற்சி மூலம் அறிவை மேம்படுத்துதல்.'}
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed max-w-xl">
              {t('heroSubtitle')}
            </p>
            <div className="flex flex-wrap gap-4">
              <Button asChild size="lg" className="h-14 px-8 rounded-full text-lg font-bold">
                <a href="#auth">Start Your Journey <ArrowRight className="ml-2 h-5 w-5" /></a>
              </Button>
              <Button variant="outline" size="lg" className="h-14 px-8 rounded-full text-lg font-bold" onClick={handleWhatsApp}>
                <MessageSquare className="mr-2 h-5 w-5" /> WhatsApp Support
              </Button>
            </div>
            
            <div className="flex items-center gap-6 pt-8 border-t">
              <div className="flex -space-x-4">
                {[1,2,3,4].map(i => (
                  <div key={i} className="h-12 w-12 rounded-full border-4 border-white bg-slate-200 flex items-center justify-center overflow-hidden">
                    <img src={`https://picsum.photos/seed/student${i}/100/100`} alt="Avatar" />
                  </div>
                ))}
              </div>
              <div>
                <div className="flex items-center gap-1 text-yellow-500">
                  {[1,2,3,4,5].map(i => <Star key={i} className="h-4 w-4 fill-current" />)}
                </div>
                <p className="text-sm font-bold">Trusted by 10,000+ Students</p>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-4 bg-primary/20 rounded-[2.5rem] blur-3xl opacity-20" />
            <Card className="relative overflow-hidden border-none shadow-2xl ring-1 ring-slate-200/50 rounded-[2rem]">
              <img 
                src="https://picsum.photos/seed/learning-hub/800/600" 
                alt="Mathes Learning Hub Coaching" 
                className="w-full h-full object-cover aspect-[4/3]"
              />
              <div className="absolute bottom-6 left-6 right-6">
                <div className="bg-white/90 backdrop-blur-md p-6 rounded-2xl shadow-xl flex items-center gap-4 border">
                  <div className="h-12 w-12 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600">
                    <ShieldCheck className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">Verified Quality</p>
                    <p className="text-xs text-muted-foreground">Certified instructors & official curriculum</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      <section id="about" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-3 gap-12">
            <div className="space-y-4">
              <h2 className="text-3xl font-headline font-bold text-primary">{t('aboutUs')}</h2>
              <p className="text-slate-600 leading-relaxed">
                Mathes Learning Hub was founded with a singular vision: to bridge the gap between rural aspirants and urban coaching quality. We combine traditional excellence with modern AI technology.
              </p>
            </div>
            <div className="space-y-4">
              <h2 className="text-3xl font-headline font-bold text-primary">{t('ourMission')}</h2>
              <p className="text-slate-600 leading-relaxed">
                {t('missionDesc')}
              </p>
            </div>
            <div className="bg-white p-8 rounded-3xl shadow-sm border space-y-6">
              <h3 className="font-bold text-xl">Platform Excellence</h3>
              <div className="space-y-4">
                {[
                  { icon: Sparkles, title: "AI Concept Tutor", desc: "Instant help for complex topics" },
                  { icon: Video, title: "Live Classrooms", desc: "Interactive sessions with experts" },
                  { icon: Target, title: "Mock Assessments", desc: "Real-time scoring and rank lists" },
                  { icon: ShieldCheck, title: "Verified Certificates", desc: "Course completion honors" },
                ].map((f, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="h-8 w-8 rounded-lg bg-primary/5 flex items-center justify-center text-primary shrink-0">
                      <f.icon className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-bold text-sm">{f.title}</p>
                      <p className="text-xs text-muted-foreground">{f.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="auth" className="py-24 bg-primary/5">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
          <div className="space-y-6">
            <h2 className="text-5xl font-headline font-bold">Begin Your Success Story.</h2>
            <p className="text-slate-600 leading-relaxed">
              Create an account at Mathes Learning Hub to access free trial materials, AI tutor sessions, and join our vibrant community of learners.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-6 bg-white rounded-3xl shadow-sm border border-slate-100">
                <Users className="h-8 w-8 text-primary mb-2" />
                <p className="font-bold text-2xl">10k+</p>
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">Active Students</p>
              </div>
              <div className="p-6 bg-white rounded-3xl shadow-sm border border-slate-100">
                <School className="h-8 w-8 text-accent mb-2" />
                <p className="font-bold text-2xl">20+</p>
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">Expert Faculty</p>
              </div>
            </div>
          </div>

          <Card className="shadow-2xl border-none ring-1 ring-slate-200 rounded-[2.5rem] overflow-hidden bg-white">
            <Tabs defaultValue="student" onValueChange={(v) => setRole(v as any)} className="w-full">
              <CardHeader className="bg-white p-8 pb-4">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <CardTitle className="text-3xl font-headline font-bold">
                      {isRegistering ? 'Create Account' : 'Welcome Back'}
                    </CardTitle>
                    <CardDescription className="text-base">
                      {isRegistering ? 'Join the Mathes Learning Hub community.' : 'Login to access your official dashboard.'}
                    </CardDescription>
                  </div>
                  <div className="bg-primary/10 p-3 rounded-2xl">
                    <Lock className="h-6 w-6 text-primary" />
                  </div>
                </div>

                <TabsList className="grid w-full grid-cols-3 h-14 p-1.5 bg-slate-100 rounded-2xl">
                  <TabsTrigger value="student" className="rounded-xl font-bold text-xs uppercase tracking-wider data-[state=active]:shadow-lg">
                    {t('student')}
                  </TabsTrigger>
                  <TabsTrigger value="teacher" className="rounded-xl font-bold text-xs uppercase tracking-wider data-[state=active]:shadow-lg">
                    {t('teacher')}
                  </TabsTrigger>
                  <TabsTrigger value="admin" className="rounded-xl font-bold text-xs uppercase tracking-wider data-[state=active]:shadow-lg">
                    {t('admin')}
                  </TabsTrigger>
                </TabsList>
              </CardHeader>

              <CardContent className="p-8 pt-4">
                <form onSubmit={handleAuth} className="space-y-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-sm font-bold text-slate-700">Email Address</Label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                        <Input 
                          id="email" 
                          type="email" 
                          placeholder="name@example.com" 
                          required 
                          className="h-14 pl-12 rounded-2xl border-slate-200 bg-slate-50/50 focus:bg-white transition-all text-lg"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-sm font-bold text-slate-700">Security Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                        <Input 
                          id="password" 
                          type="password" 
                          placeholder="••••••••"
                          required 
                          className="h-14 pl-12 rounded-2xl border-slate-200 bg-slate-50/50 focus:bg-white transition-all text-lg"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 py-2">
                    <Badge variant="outline" className="px-3 py-1 gap-1.5 bg-slate-50 text-slate-600 font-bold uppercase text-[10px]">
                      {role === 'admin' ? <ShieldAlert className="h-3 w-3 text-red-500" /> : <UserCheck className="h-3 w-3 text-emerald-500" />}
                      Mathes Learning Hub {role} Portal
                    </Badge>
                  </div>

                  <Button type="submit" className="w-full h-16 text-xl font-bold group rounded-2xl shadow-xl shadow-primary/20 bg-primary hover:bg-primary/90 transition-all" disabled={isLoading}>
                    {isLoading ? (
                      <Loader2 className="h-6 w-6 animate-spin" />
                    ) : (
                      <>
                        {isRegistering ? 'Start Learning' : 'Enter Dashboard'} 
                        <ChevronRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Tabs>
            
            <CardFooter className="flex flex-col gap-4 border-t p-8 bg-slate-50/50">
              <Button 
                variant="link" 
                className="text-base font-bold text-primary hover:no-underline" 
                onClick={() => setIsRegistering(!isRegistering)}
              >
                {isRegistering ? 'Already registered? Sign In' : 'New student? Create Account'}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </section>

      <footer className="bg-slate-900 text-white pt-16 pb-12">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-start gap-12 border-b border-slate-800 pb-12">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="bg-primary p-2 rounded-xl">
                <GraduationCap className="text-white h-6 w-6" />
              </div>
              <span className="text-2xl font-headline font-bold tracking-tight">Mathes Learning Hub</span>
            </div>
            <p className="text-slate-400 max-w-sm text-sm">
              Premium educational platform for Indian competitive exams. Focused on clarity, quality, and results.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-8 md:gap-16">
            <div className="space-y-4">
              <h4 className="font-bold text-xs uppercase tracking-widest text-primary">Legal</h4>
              <div className="flex flex-col gap-3 text-slate-400 text-sm">
                <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto px-6 pt-8">
          <p className="text-slate-500 text-xs tracking-tight">&copy; 2025 Mathes Learning Hub. All rights reserved.</p>
        </div>
      </footer>

      <Button
        onClick={handleWhatsApp}
        className={cn(
          "fixed bottom-6 right-6 h-16 w-16 rounded-full bg-emerald-500 hover:bg-emerald-600 shadow-2xl z-50 p-0 transition-all duration-300 group",
          showChat ? "translate-y-0 opacity-100 scale-100" : "translate-y-20 opacity-0 scale-50 pointer-events-none"
        )}
      >
        <MessageSquare className="h-8 w-8 text-white group-hover:animate-bounce" />
      </Button>
    </div>
  );
}
