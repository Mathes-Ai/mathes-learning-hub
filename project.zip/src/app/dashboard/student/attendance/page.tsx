
"use client";

import { useMemo } from "react";
import { useUser, useFirestore, useCollection } from "@/firebase";
import { collection, query, where, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { UserCheck, Calendar, TrendingUp, CheckCircle2, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";

export default function StudentAttendance() {
  const { user } = useUser();
  const db = useFirestore();

  const attendanceQuery = useMemo(() => 
    user ? query(collection(db, "attendance"), where("studentId", "==", user.uid), orderBy("date", "desc")) : null,
    [db, user]
  );
  const coursesQuery = useMemo(() => collection(db, "courses"), [db]);
  const enrollmentsQuery = useMemo(() => 
    user ? query(collection(db, "enrollments"), where("studentId", "==", user.uid)) : null,
    [db, user]
  );

  const { data: attendanceRecords } = useCollection(attendanceQuery);
  const { data: courses } = useCollection(coursesQuery);
  const { data: enrollments } = useCollection(enrollmentsQuery);

  const courseWiseStats = useMemo(() => {
    return enrollments.map(e => {
      const course = courses.find(c => c.id === e.courseId);
      const courseRecords = attendanceRecords.filter(r => r.courseId === e.courseId);
      const presentCount = courseRecords.filter(r => r.status === 'present').length;
      const totalCount = courseRecords.length;
      const percentage = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;

      return {
        id: e.courseId,
        title: course?.title || 'Unknown Course',
        present: presentCount,
        total: totalCount,
        percentage
      };
    });
  }, [enrollments, courses, attendanceRecords]);

  const overallAttendance = useMemo(() => {
    if (attendanceRecords.length === 0) return 0;
    const present = attendanceRecords.filter(r => r.status === 'present').length;
    return Math.round((present / attendanceRecords.length) * 100);
  }, [attendanceRecords]);

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-3 rounded-xl text-primary">
          <UserCheck className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-3xl font-headline font-bold">Attendance Analytics</h1>
          <p className="text-muted-foreground text-sm">Monitor your consistency and classroom engagement.</p>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="border-none shadow-md bg-primary text-primary-foreground">
          <CardHeader className="pb-2">
            <CardDescription className="text-primary-foreground/70 uppercase text-[10px] font-bold">Overall Presence</CardDescription>
            <CardTitle className="text-4xl">{overallAttendance}%</CardTitle>
          </CardHeader>
          <CardContent>
            <Progress value={overallAttendance} className="h-2 bg-white/20" />
          </CardContent>
        </Card>
        
        <Card className="border-none shadow-md">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-emerald-500" />
              <CardDescription className="uppercase text-[10px] font-bold">Consistency</CardDescription>
            </div>
            <CardTitle className="text-2xl">{overallAttendance >= 75 ? 'Excellent' : 'Needs Improvement'}</CardTitle>
          </CardHeader>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-primary" />
              <CardDescription className="uppercase text-[10px] font-bold">Total Sessions</CardDescription>
            </div>
            <CardTitle className="text-2xl">{attendanceRecords.length}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="shadow-lg border-none ring-1 ring-border">
          <CardHeader>
            <CardTitle>Course-wise Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {courseWiseStats.map((stat) => (
              <div key={stat.id} className="space-y-2">
                <div className="flex justify-between items-end">
                  <div>
                    <p className="font-bold text-sm">{stat.title}</p>
                    <p className="text-[10px] text-muted-foreground uppercase">{stat.present} / {stat.total} Sessions</p>
                  </div>
                  <Badge variant={stat.percentage >= 75 ? 'default' : 'destructive'} className="text-[10px]">
                    {stat.percentage}%
                  </Badge>
                </div>
                <Progress value={stat.percentage} className="h-1.5" />
              </div>
            ))}
            {courseWiseStats.length === 0 && (
              <div className="py-10 text-center text-muted-foreground text-sm italic">
                Enroll in courses to track attendance.
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-lg border-none ring-1 ring-border">
          <CardHeader>
            <CardTitle>Recent Logs</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead className="text-right">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attendanceRecords.slice(0, 10).map((record) => {
                  const course = courses.find(c => c.id === record.courseId);
                  return (
                    <TableRow key={record.id}>
                      <TableCell className="text-xs">{new Date(record.date).toLocaleDateString()}</TableCell>
                      <TableCell className="text-xs font-medium max-w-[150px] truncate">{course?.title}</TableCell>
                      <TableCell className="text-right">
                        {record.status === 'present' ? (
                          <Badge className="bg-emerald-50 text-emerald-700 hover:bg-emerald-50 border-emerald-100">
                            <CheckCircle2 className="h-3 w-3 mr-1" /> Present
                          </Badge>
                        ) : (
                          <Badge variant="destructive" className="bg-red-50 text-red-700 hover:bg-red-50 border-red-100">
                            <XCircle className="h-3 w-3 mr-1" /> Absent
                          </Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
                {attendanceRecords.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center py-10 text-muted-foreground text-xs">
                      No attendance records found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
