"use client";

import { useMemo, useState } from "react";
import { useUser, useFirestore, useCollection } from "@/firebase";
import { collection, query, where } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Award, Download, ExternalLink, ShieldCheck, Printer, Loader2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function MyCertificates() {
  const { user } = useUser();
  const db = useFirestore();
  const [printingId, setPrintingId] = useState<string | null>(null);

  const certsQuery = useMemo(() => 
    user ? query(collection(db, "certificates"), where("studentId", "==", user.uid)) : null,
    [db, user]
  );

  const { data: certs, loading } = useCollection(certsQuery);

  const handlePrint = (cert: any) => {
    setPrintingId(cert.id);
    setTimeout(() => {
      window.print();
      setPrintingId(null);
    }, 500);
  };

  return (
    <div className="space-y-8 print:p-0">
      <div className="flex items-center justify-between print:hidden">
        <div className="flex items-center gap-3">
          <div className="bg-amber-100 p-3 rounded-xl text-amber-600">
            <Award className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold">My Academic Honors</h1>
            <p className="text-muted-foreground text-sm">Download your verified Mathes Learning Hub credentials.</p>
          </div>
        </div>
        <Button variant="outline" className="gap-2" asChild>
          <a href="/verify" target="_blank">
            <ShieldCheck className="h-4 w-4" /> Verify Credentials
          </a>
        </Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 print:block">
        {certs.map((cert) => (
          <Card key={cert.id} className="group hover:shadow-2xl transition-all border-none ring-1 ring-border bg-card overflow-hidden print:shadow-none print:ring-0 print:border-none print:mb-8">
            <div className="aspect-[1.414/1] bg-primary/5 relative flex flex-col items-center justify-center p-8 text-center border-b print:bg-white print:border-4 print:border-primary/20">
               <Award className="h-32 w-32 text-primary opacity-5 absolute pointer-events-none" />
               <div className="z-10 space-y-4">
                 <div className="flex justify-center mb-2">
                   <div className="bg-primary p-2 rounded-full">
                     <ShieldCheck className="h-6 w-6 text-white" />
                   </div>
                 </div>
                 <div className="space-y-1">
                   <h3 className="font-headline font-bold text-lg text-primary">{cert.courseTitle}</h3>
                   <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Mathes Learning Hub</p>
                 </div>
                 <div className="h-px w-20 bg-primary/20 mx-auto" />
                 <p className="text-[10px] text-muted-foreground italic">
                   This is to certify that <span className="font-bold text-foreground not-italic">{cert.studentName}</span> has successfully completed the required modules.
                 </p>
                 <div className="flex items-center justify-center gap-4 text-[9px] font-bold text-muted-foreground uppercase">
                    <span>ID: {cert.certificateId}</span>
                    <span className="h-3 w-px bg-muted-foreground/30" />
                    <span>{new Date(cert.issuedAt).toLocaleDateString()}</span>
                 </div>
               </div>
            </div>
            <CardFooter className="p-4 gap-2 print:hidden">
              <Button 
                className="w-full h-10 gap-2 font-bold" 
                variant="secondary"
                onClick={() => handlePrint(cert)}
              >
                {printingId === cert.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Printer className="h-4 w-4" />}
                Print/PDF
              </Button>
              <Button variant="outline" size="icon" className="h-10 w-10 shrink-0" asChild title="Public Link">
                 <a href={`/verify/${cert.certificateId}`} target="_blank">
                   <ExternalLink className="h-4 w-4" />
                 </a>
              </Button>
            </CardFooter>
          </Card>
        ))}
        {certs.length === 0 && !loading && (
          <div className="col-span-full py-32 text-center text-muted-foreground border-4 border-dashed rounded-3xl space-y-4 bg-muted/20">
            <Award className="h-16 w-16 mx-auto opacity-20" />
            <div>
              <p className="text-xl font-bold">No Mathes Learning Hub certificates found</p>
              <p className="text-sm">Finish your course modules to 100% to qualify for issuance.</p>
            </div>
            <Button asChild variant="outline" className="rounded-full px-8">
              <a href="/dashboard/courses">Go to Courses</a>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
