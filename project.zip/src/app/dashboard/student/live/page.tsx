
"use client";

import { useMemo } from "react";
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, where, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Video, Calendar, Clock, ExternalLink, Play, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function StudentLiveClasses() {
  const { user } = useUser();
  const db = useFirestore();

  const enrollmentsQuery = useMemoFirebase(() => 
    user ? query(collection(db, "enrollments"), where("studentId", "==", user.uid)) : null,
    [db, user]
  );
  const { data: enrollments } = useCollection(enrollmentsQuery);
  const enrolledCourseIds = useMemo(() => enrollments.map(e => e.courseId), [enrollments]);

  const liveSessionsQuery = useMemoFirebase(() => 
    query(collection(db, "live_sessions"), orderBy("startTime", "asc")),
    [db]
  );
  const allCoursesQuery = useMemoFirebase(() => collection(db, "courses"), [db]);

  const { data: allSessions, loading } = useCollection(liveSessionsQuery);
  const { data: courses } = useCollection(allCoursesQuery);

  const filteredSessions = useMemo(() => {
    return allSessions.filter(s => enrolledCourseIds.includes(s.courseId));
  }, [allSessions, enrolledCourseIds]);

  const upcomingSessions = filteredSessions.filter(s => new Date(s.startTime) > new Date());
  const pastSessions = filteredSessions.filter(s => new Date(s.startTime) <= new Date());

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid md:grid-cols-2 gap-6">
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-red-100 p-3 rounded-xl text-red-600">
          <Video className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-3xl font-headline font-bold">Virtual Classrooms</h1>
          <p className="text-muted-foreground text-sm">Join live sessions with expert faculty.</p>
        </div>
      </div>

      <section className="space-y-4">
        <h2 className="text-xl font-headline font-bold flex items-center gap-2">
          <Clock className="h-5 w-5 text-red-500" />
          Upcoming Classes
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {upcomingSessions.map((session) => {
            const course = courses.find(c => c.id === session.courseId);
            const isSoon = new Date(session.startTime).getTime() - new Date().getTime() < 30 * 60 * 1000;
            
            return (
              <Card key={session.id} className={`border-none ring-1 ring-border shadow-md overflow-hidden ${isSoon ? 'ring-2 ring-red-500/50' : ''}`}>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <Badge variant="outline" className="text-[10px] uppercase font-bold tracking-tighter">
                      {course?.title || "Loading..."}
                    </Badge>
                    {isSoon && <Badge className="bg-red-500 animate-pulse text-[9px]">STARTING SOON</Badge>}
                  </div>
                  <CardTitle className="text-lg mt-2">{session.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 pb-4">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    {new Date(session.startTime).toLocaleDateString()}
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-primary">
                    <Clock className="h-3 w-3" />
                    {new Date(session.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </CardContent>
                <CardFooter className="bg-muted/30 border-t p-4">
                  <Button className="w-full gap-2 font-bold" asChild>
                    <a href={session.meetingLink} target="_blank" rel="noopener noreferrer">
                      <Play className="h-4 w-4 fill-current" /> Join Room
                    </a>
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
          {upcomingSessions.length === 0 && (
            <div className="col-span-full py-20 text-center border-2 border-dashed rounded-2xl bg-muted/20">
              <Calendar className="h-12 w-12 mx-auto text-muted-foreground opacity-20 mb-3" />
              <p className="text-muted-foreground font-medium">No live classes scheduled for your courses.</p>
            </div>
          )}
        </div>
      </section>

      {pastSessions.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-headline font-bold text-muted-foreground">Recently Ended</h2>
          <div className="grid md:grid-cols-3 gap-4 opacity-60 grayscale">
            {pastSessions.slice(0, 3).map((session) => (
              <Card key={session.id} className="border-none ring-1 ring-border bg-muted/30">
                <CardHeader className="p-4">
                  <CardTitle className="text-sm">{session.title}</CardTitle>
                  <p className="text-[10px] text-muted-foreground">{new Date(session.startTime).toLocaleString()}</p>
                </CardHeader>
              </Card>
            ))}
          </div>
        </section>
      )}

      <div className="bg-amber-50 border border-amber-200 p-6 rounded-2xl flex gap-4 items-start">
        <AlertCircle className="h-6 w-6 text-amber-600 shrink-0" />
        <div className="space-y-1">
          <h3 className="font-bold text-amber-900">Virtual Etiquette</h3>
          <p className="text-sm text-amber-800 leading-relaxed">
            Please ensure you are in a quiet environment and keep your microphone muted unless asked to speak. Join sessions at least 5 minutes early to test your audio and video connection.
          </p>
        </div>
      </div>
    </div>
  );
}
