
"use client";

import { useMemo, useState } from "react";
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, orderBy, deleteDoc, doc } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  XCircle, 
  Trash2, 
  BookOpen, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  BarChart3, 
  ArrowRight,
  Filter,
  Search,
  RotateCcw
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import Link from "next/link";
import { Input } from "@/components/ui/input";

export default function MistakeBook() {
  const { user } = useUser();
  const db = useFirestore();
  const [search, setSearch] = useState("");

  const mistakesQuery = useMemoFirebase(() => 
    user ? query(collection(db, "users", user.uid, "mistakes"), orderBy("timestamp", "desc")) : null,
    [db, user]
  );
  const { data: mistakes, loading } = useCollection(mistakesQuery);

  const filteredMistakes = useMemo(() => {
    return mistakes.filter(m => 
      m.questionText.toLowerCase().includes(search.toLowerCase()) || 
      m.category?.toLowerCase().includes(search.toLowerCase())
    );
  }, [mistakes, search]);

  const statsBySubject = useMemo(() => {
    const counts: Record<string, number> = {};
    mistakes.forEach(m => {
      counts[m.category] = (counts[m.category] || 0) + 1;
    });
    return Object.entries(counts).sort((a,b) => b[1] - a[1]);
  }, [mistakes]);

  const removeMistake = (id: string) => {
    if (!user) return;
    deleteDoc(doc(db, "users", user.uid, "mistakes", id));
  };

  return (
    <div className="space-y-8 pb-32">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="bg-red-100 p-4 rounded-3xl text-red-600">
            <XCircle className="h-8 w-8" />
          </div>
          <div>
            <h1 className="text-4xl font-headline font-bold text-primary">Mistake Book</h1>
            <p className="text-muted-foreground text-lg">Turn every error into an opportunity for growth.</p>
          </div>
        </div>
        <div className="flex gap-4">
           <Button asChild className="rounded-2xl h-14 px-8 font-bold gap-2 shadow-xl shadow-red-500/20 bg-red-600 hover:bg-red-700">
             <Link href="/dashboard/student/revision/mistakes">
               <RotateCcw className="h-5 w-5" /> REVISE ERRORS
             </Link>
           </Button>
        </div>
      </header>

      <div className="grid lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <Card className="border-none shadow-lg ring-1 ring-border rounded-[2rem] overflow-hidden bg-white">
            <CardHeader className="bg-red-50/50 p-6 border-b border-red-100">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-red-600" /> Subject Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              {statsBySubject.map(([subject, count]) => (
                <div key={subject} className="space-y-2">
                  <div className="flex justify-between items-end">
                    <span className="text-xs font-bold truncate max-w-[120px]">{subject}</span>
                    <Badge variant="outline" className="text-[10px] font-mono border-red-200 text-red-700">{count} ERR</Badge>
                  </div>
                  <Progress value={Math.min(100, (count / mistakes.length) * 100)} className="h-1 bg-red-50" />
                </div>
              ))}
              {mistakes.length === 0 && (
                <p className="text-[10px] text-center text-muted-foreground uppercase font-bold tracking-widest py-8">No errors recorded</p>
              )}
            </CardContent>
          </Card>

          <div className="bg-amber-50 p-6 rounded-[2rem] border border-amber-100 space-y-3">
             <div className="flex items-center gap-2 text-amber-800">
               <AlertTriangle className="h-4 w-4" />
               <p className="text-xs font-bold uppercase tracking-tighter">Strategic Insights</p>
             </div>
             <p className="text-[11px] text-amber-800 leading-relaxed font-medium">
               A mistake only becomes a loss if not reviewed. Re-attempting your wrong answers within 48 hours is the proven way to master difficult concepts.
             </p>
          </div>
        </div>

        <div className="lg:col-span-3 space-y-6">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1 w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search your mistakes by topic or text..." 
                className="pl-10 h-12 rounded-xl"
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>

          <div className="grid gap-6">
            {filteredMistakes.map((m) => (
              <Card key={m.id} className="border-none shadow-md ring-1 ring-border group rounded-[2rem] overflow-hidden bg-white">
                <CardHeader className="bg-slate-50 p-6 flex flex-row items-center justify-between border-b">
                   <div className="flex items-center gap-3">
                     <Badge className="bg-red-50 text-red-700 border-red-100 uppercase text-[9px] font-bold py-1 px-3">
                       {m.category || "Competitive Focus"}
                     </Badge>
                     <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">Added {new Date(m.timestamp).toLocaleDateString()}</p>
                   </div>
                   <Button variant="ghost" size="icon" className="text-destructive opacity-0 group-hover:opacity-100 transition-all" onClick={() => removeMistake(m.id)}>
                     <Trash2 className="h-4 w-4" />
                   </Button>
                </CardHeader>
                <CardContent className="p-8 md:p-10 space-y-8">
                  <p className="text-xl font-headline font-bold leading-snug text-slate-800">{m.questionText}</p>
                  
                  <div className="grid sm:grid-cols-2 gap-4">
                     <div className="p-5 rounded-2xl border-2 border-red-100 bg-red-50 text-red-900 flex items-center gap-4 relative overflow-hidden">
                        <XCircle className="h-5 w-5 shrink-0" />
                        <div>
                          <p className="text-[9px] font-bold uppercase opacity-50">Your Answer</p>
                          <p className="font-bold text-sm">{m.studentAnswer}</p>
                        </div>
                     </div>
                     <div className="p-5 rounded-2xl border-2 border-emerald-100 bg-emerald-50 text-emerald-900 flex items-center gap-4">
                        <CheckCircle2 className="h-5 w-5 shrink-0" />
                        <div>
                          <p className="text-[9px] font-bold uppercase opacity-50">Correct Answer</p>
                          <p className="font-bold text-sm">{m.correctAnswer}</p>
                        </div>
                     </div>
                  </div>

                  <div className="pt-8 border-t bg-primary/5 -mx-10 -mb-10 p-8 md:p-10">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="h-8 w-8 bg-primary rounded-xl flex items-center justify-center text-white">
                        <Info className="h-4 w-4" />
                      </div>
                      <span className="text-[11px] font-bold text-primary uppercase tracking-[0.2em]">Revision Context & Explanation</span>
                    </div>
                    <p className="text-sm md:text-base text-slate-700 leading-relaxed italic border-l-4 border-primary/20 pl-6 py-2">
                      {m.explanation}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}

            {mistakes.length === 0 && !loading && (
              <div className="py-40 text-center border-4 border-dashed rounded-[3rem] space-y-8 bg-muted/10">
                <div className="h-24 w-24 bg-white rounded-[2rem] mx-auto flex items-center justify-center shadow-sm">
                  <CheckCircle2 className="h-12 w-12 text-emerald-500 opacity-20" />
                </div>
                <div>
                  <p className="text-2xl font-bold">Zero Errors Recorded!</p>
                  <p className="text-muted-foreground max-w-sm mx-auto">Your Mistake Book is empty. Keep up the high accuracy in your proctored assessments.</p>
                </div>
                <Button asChild className="rounded-full px-12 h-14 text-lg font-bold shadow-xl shadow-primary/20">
                  <Link href="/dashboard/quizzes">Take Mock Test</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
