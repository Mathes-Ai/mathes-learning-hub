
"use client";

import { useMemo } from "react";
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  RotateCcw, 
  Bookmark, 
  XCircle, 
  Sparkles, 
  ArrowRight, 
  Trophy, 
  Zap, 
  BrainCircuit,
  ClipboardList
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

export default function RevisionHub() {
  const { user } = useUser();
  const db = useFirestore();

  const bookmarksQuery = useMemoFirebase(() => 
    user ? query(collection(db, "users", user.uid, "bookmarks")) : null,
    [db, user]
  );
  const mistakesQuery = useMemoFirebase(() => 
    user ? query(collection(db, "users", user.uid, "mistakes")) : null,
    [db, user]
  );

  const { data: bookmarks } = useCollection(bookmarksQuery);
  const { data: mistakes } = useCollection(mistakesQuery);

  const revisionModes = [
    {
      id: "bookmarks",
      title: "Success Library Revision",
      desc: "Practice questions you personally flagged for high-importance review.",
      count: bookmarks.length,
      icon: Bookmark,
      color: "bg-primary",
      link: "/dashboard/student/revision/bookmarks"
    },
    {
      id: "mistakes",
      title: "Mistake Book Mastery",
      desc: "Convert your errors into strengths by re-attempting failed questions.",
      count: mistakes.length,
      icon: XCircle,
      color: "bg-red-600",
      link: "/dashboard/student/revision/mistakes"
    },
    {
      id: "mastery",
      title: "Ultimate Mastery Challenge",
      desc: "A randomized shuffle of both bookmarks and mistakes for peak preparation.",
      count: bookmarks.length + mistakes.length,
      icon: Trophy,
      color: "bg-emerald-600",
      link: "/dashboard/student/revision/mastery"
    }
  ];

  return (
    <div className="space-y-10 pb-32">
      <header className="space-y-2">
        <h1 className="text-4xl font-headline font-bold text-primary">Revision Mode</h1>
        <p className="text-muted-foreground text-lg italic">The secret to excellence is consistent high-quality revision.</p>
      </header>

      <div className="grid md:grid-cols-3 gap-8">
        {revisionModes.map((mode) => (
          <Card key={mode.id} className="border-none shadow-xl ring-1 ring-border group overflow-hidden rounded-[2.5rem] bg-white hover:scale-[1.03] transition-transform">
            <CardHeader className="p-8 pb-4">
               <div className={`${mode.color} w-16 h-16 rounded-2xl flex items-center justify-center text-white mb-6 shadow-lg shadow-black/5`}>
                 <mode.icon className="h-8 w-8" />
               </div>
               <div className="flex justify-between items-start mb-2">
                 <CardTitle className="text-2xl font-headline font-bold leading-tight">{mode.title}</CardTitle>
               </div>
               <CardDescription className="text-base min-h-[4rem]">{mode.desc}</CardDescription>
            </CardHeader>
            <CardContent className="p-8 pt-0">
               <div className="flex items-center gap-3">
                 <Badge variant="secondary" className="font-mono text-lg px-4 py-1 rounded-xl bg-muted/50 text-slate-700">
                   {mode.count.toString().padStart(2, '0')}
                 </Badge>
                 <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Available Items</span>
               </div>
            </CardContent>
            <CardFooter className="p-8 pt-0 mt-auto">
               <Button asChild className={`w-full h-14 rounded-2xl font-bold text-lg group ${mode.color} hover:opacity-90`}>
                 <Link href={mode.link} className="flex items-center justify-center gap-2">
                   START SESSION <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
                 </Link>
               </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8 pt-10">
         <Card className="border-none shadow-lg ring-1 ring-border bg-primary/5 rounded-[2.5rem] overflow-hidden">
            <CardContent className="p-10 flex gap-8 items-center">
              <div className="h-20 w-20 bg-white rounded-3xl flex items-center justify-center shrink-0 shadow-sm">
                <BrainCircuit className="h-10 w-10 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold text-primary">Smart Adaptive Learning</h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Our system tracks your frequency of correct answers during revision. Once you answer a mistake correctly three times in a row, it's flagged as "Mastered".
                </p>
              </div>
            </CardContent>
         </Card>
         
         <Card className="border-none shadow-lg ring-1 ring-border bg-emerald-50/50 rounded-[2.5rem] overflow-hidden">
            <CardContent className="p-10 flex gap-8 items-center">
              <div className="h-20 w-20 bg-white rounded-3xl flex items-center justify-center shrink-0 shadow-sm">
                <Zap className="h-10 w-10 text-emerald-600" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold text-emerald-800">Exam Integrity</h3>
                <p className="text-sm text-emerald-900/70 leading-relaxed">
                  Revision Mode focuses on deep conceptual understanding rather than scoring. There is no proctoring penalty here—take your time to understand the "Why".
                </p>
              </div>
            </CardContent>
         </Card>
      </div>
    </div>
  );
}
