
"use client";

import { useState, useMemo } from "react";
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, addDoc, query, where, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, Send, Loader2, CheckCircle2, Clock, Image as ImageIcon, Search } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";

export default function StudentDoubts() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");

  const enrollmentsQuery = useMemoFirebase(() => 
    user ? query(collection(db, "enrollments"), where("studentId", "==", user.uid)) : null,
    [db, user]
  );
  const doubtsQuery = useMemoFirebase(() => 
    user ? query(collection(db, "doubts"), where("studentId", "==", user.uid), orderBy("createdAt", "desc")) : null,
    [db, user]
  );
  const allCoursesQuery = useMemoFirebase(() => collection(db, "courses"), [db]);

  const { data: enrollments } = useCollection(enrollmentsQuery);
  const { data: doubts } = useCollection(doubtsQuery);
  const { data: courses } = useCollection(allCoursesQuery);

  const [formData, setFormData] = useState({
    courseId: "",
    question: "",
    imageUrl: ""
  });

  const filteredDoubts = useMemo(() => {
    return doubts.filter(d => d.question.toLowerCase().includes(search.toLowerCase()));
  }, [doubts, search]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    const selectedCourse = courses.find(c => c.id === formData.courseId);
    
    const newDoubt = {
      studentId: user.uid,
      studentName: user.displayName || user.email?.split('@')[0],
      courseId: formData.courseId,
      teacherId: selectedCourse?.teacherId || "admin",
      question: formData.question,
      imageUrl: formData.imageUrl,
      status: "pending",
      answer: "",
      createdAt: new Date().toISOString()
    };

    addDoc(collection(db, "doubts"), newDoubt)
      .then(() => {
        setFormData({ courseId: "", question: "", imageUrl: "" });
        setLoading(false);
        toast({ title: "Doubt Posted", description: "Your teacher will be notified shortly." });
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: "doubts",
          operation: 'create',
          requestResourceData: newDoubt
        }));
      });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-3 rounded-xl text-primary">
          <MessageCircle className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-3xl font-headline font-bold text-primary">Doubt Solving Center</h1>
          <p className="text-muted-foreground text-sm">Post questions and get clarifications from your expert faculty.</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 shadow-md h-fit border-none ring-1 ring-border">
          <CardHeader>
            <CardTitle>Ask a New Doubt</CardTitle>
            <CardDescription>Select a course and describe your hurdle.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Course Context</Label>
                <Select value={formData.courseId} onValueChange={v => setFormData({...formData, courseId: v})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Which subject?" />
                  </SelectTrigger>
                  <SelectContent>
                    {enrollments.map(e => (
                      <SelectItem key={e.courseId} value={e.courseId}>{e.courseTitle}</SelectItem>
                    ))}
                    {enrollments.length === 0 && (
                      <SelectItem value="none" disabled>No courses enrolled</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Your Question</Label>
                <Textarea 
                  required
                  placeholder="Describe your doubt in detail..."
                  className="min-h-[120px]"
                  value={formData.question}
                  onChange={e => setFormData({...formData, question: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Reference Image URL (Optional)</Label>
                <div className="relative">
                  <ImageIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    className="pl-9"
                    placeholder="https://imgur.com/..."
                    value={formData.imageUrl}
                    onChange={e => setFormData({...formData, imageUrl: e.target.value})}
                  />
                </div>
              </div>
              <Button type="submit" className="w-full h-11" disabled={loading || !formData.courseId}>
                {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Send className="h-4 w-4 mr-2" />}
                Post Doubt
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-headline font-bold">My Recent Questions</h2>
            <div className="relative w-48">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search doubts..." 
                className="pl-9 h-8 text-xs" 
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>
          
          <div className="grid gap-4">
            {filteredDoubts.map((doubt) => (
              <Card key={doubt.id} className="border-none ring-1 ring-border shadow-sm">
                <CardHeader className="pb-3 flex flex-row items-center justify-between">
                  <div>
                    <Badge variant="outline" className="text-[10px] uppercase font-bold">
                      {courses.find(c => c.id === doubt.courseId)?.title || "Subject Context"}
                    </Badge>
                    <p className="text-[10px] text-muted-foreground mt-1">{new Date(doubt.createdAt).toLocaleString()}</p>
                  </div>
                  <Badge variant={doubt.status === 'resolved' ? 'default' : 'secondary'} className="capitalize">
                    {doubt.status}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="font-medium text-sm leading-relaxed">{doubt.question}</p>
                  {doubt.imageUrl && (
                    <div className="mt-2 rounded-lg overflow-hidden border">
                      <img src={doubt.imageUrl} alt="Reference" className="max-h-48 w-full object-cover" />
                    </div>
                  )}
                  
                  {doubt.status === 'resolved' && (
                    <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl space-y-2 animate-in slide-in-from-top-2">
                      <p className="text-[10px] font-bold text-emerald-600 uppercase flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3" /> Teacher's Resolution
                      </p>
                      <p className="text-sm text-emerald-900 leading-relaxed whitespace-pre-wrap">{doubt.answer}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
            {filteredDoubts.length === 0 && (
              <div className="py-20 text-center text-muted-foreground border-2 border-dashed rounded-2xl bg-muted/20">
                <MessageCircle className="h-12 w-12 mx-auto opacity-20 mb-3" />
                <p className="font-medium">No doubt requests recorded yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
