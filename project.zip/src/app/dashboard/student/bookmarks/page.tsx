
"use client";

import { useMemo, useState } from "react";
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, deleteDoc, doc, where } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Bookmark, Trash2, CheckCircle2, Info, ArrowLeft, HelpCircle, Filter, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";

const EXAM_CATEGORIES = ["All", "UPSC", "TNPSC", "SSC", "Banking", "RRB", "UGC NET"];

export default function MyBookmarks() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");

  const bookmarksQuery = useMemoFirebase(() => 
    user ? query(collection(db, "users", user.uid, "bookmarks")) : null,
    [db, user]
  );

  const { data: bookmarks, loading } = useCollection(bookmarksQuery);

  const filteredBookmarks = useMemo(() => {
    return bookmarks.filter(b => {
      const matchesSearch = b.questionText.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           b.testTitle?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = categoryFilter === "All" || b.testTitle?.includes(categoryFilter);
      return matchesSearch && matchesCategory;
    });
  }, [bookmarks, searchTerm, categoryFilter]);

  const removeBookmark = (id: string) => {
    if (!user) return;
    deleteDoc(doc(db, "users", user.uid, "bookmarks", id)).then(() => {
      toast({ title: "Removed from Success Library" });
    });
  };

  return (
    <div className="space-y-8 pb-32">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild className="rounded-full">
            <Link href="/dashboard/student"><ArrowLeft className="h-5 w-5" /></Link>
          </Button>
          <div>
            <h1 className="text-3xl font-headline font-bold text-primary">Success Library</h1>
            <p className="text-muted-foreground text-sm">Review your personally bookmarked questions for revision.</p>
          </div>
        </div>
        <div className="bg-primary/5 px-4 py-2 rounded-2xl border border-primary/10 flex items-center gap-3">
           <Bookmark className="h-5 w-5 text-primary fill-primary/20" />
           <p className="text-lg font-bold text-primary">{bookmarks.length} <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">SAVED</span></p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-[2rem] shadow-sm ring-1 ring-border flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search questions or exams..." 
            className="pl-10 h-12 rounded-xl" 
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="w-full md:w-48">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="h-12 rounded-xl">
              <div className="flex items-center gap-2">
                <Filter className="h-3.5 w-3.5 opacity-50" />
                <SelectValue placeholder="Category" />
              </div>
            </SelectTrigger>
            <SelectContent>
              {EXAM_CATEGORIES.map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid gap-8">
        {filteredBookmarks.map((b) => (
          <Card key={b.id} className="border-none shadow-lg ring-1 ring-border group overflow-hidden rounded-[2rem] bg-white">
            <CardHeader className="bg-slate-50/50 p-6 px-8 flex flex-row items-center justify-between border-b">
              <div className="flex flex-wrap items-center gap-3">
                <Badge variant="secondary" className="text-[10px] uppercase font-bold bg-primary/10 text-primary border-none py-1 px-3">
                  {b.testTitle || "General Assessment"}
                </Badge>
                <div className="h-1 w-1 bg-muted-foreground/30 rounded-full" />
                <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">Saved {new Date(b.savedAt).toLocaleDateString()}</p>
              </div>
              <Button variant="ghost" size="icon" className="text-destructive opacity-0 group-hover:opacity-100 transition-all hover:bg-destructive/5" onClick={() => removeBookmark(b.id)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="p-8 md:p-10 space-y-8">
              <p className="text-xl md:text-2xl font-headline font-bold leading-snug text-slate-900">{b.questionText}</p>
              
              <div className="grid sm:grid-cols-2 gap-4">
                {b.options?.map((opt: string) => (
                  <div 
                    key={opt} 
                    className={`p-5 rounded-2xl text-base font-medium border-2 flex items-center gap-4 transition-all ${
                      opt === b.correctAnswer 
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-sm' 
                        : 'bg-muted/5 border-transparent text-muted-foreground opacity-70'
                    }`}
                  >
                    {opt === b.correctAnswer ? (
                      <div className="h-6 w-6 rounded-full bg-emerald-500 flex items-center justify-center text-white shrink-0">
                        <CheckCircle2 className="h-4 w-4" />
                      </div>
                    ) : <div className="h-6 w-6" />}
                    {opt}
                  </div>
                ))}
              </div>

              <div className="pt-8 border-t bg-primary/5 -mx-10 -mb-10 p-8 md:p-10">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-8 w-8 bg-primary rounded-xl flex items-center justify-center text-white">
                    <Info className="h-4 w-4" />
                  </div>
                  <span className="text-[11px] font-bold text-primary uppercase tracking-[0.2em]">Academic Context & Explanation</span>
                </div>
                <p className="text-sm md:text-base text-slate-700 leading-relaxed italic border-l-4 border-primary/20 pl-6 py-2">
                  {b.explanation || "No expert explanation provided for this question."}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredBookmarks.length === 0 && !loading && (
          <div className="py-40 text-center border-4 border-dashed rounded-[3rem] space-y-8 bg-muted/10">
            <div className="h-24 w-24 bg-white rounded-[2rem] shadow-sm mx-auto flex items-center justify-center">
              <Bookmark className="h-12 w-12 opacity-10" />
            </div>
            <div className="space-y-3">
              <p className="text-2xl font-bold">Your Success Library is Empty</p>
              <p className="text-muted-foreground max-w-sm mx-auto text-base">Bookmark challenging questions during your proctored tests to save them here for focused deep revision.</p>
            </div>
            <Button asChild className="rounded-full px-12 h-14 text-lg font-bold shadow-xl shadow-primary/20">
              <Link href="/dashboard/quizzes">Start Mock Test</Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
