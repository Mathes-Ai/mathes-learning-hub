
"use client";

import { useMemo } from "react";
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, where, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { 
  BarChart3, 
  TrendingUp, 
  Trophy, 
  Target, 
  Clock, 
  Calendar, 
  Zap, 
  AlertTriangle,
  ChevronRight,
  BrainCircuit,
  Loader2,
  BookOpen
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  Cell,
  PieChart,
  Pie
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function PerformanceAnalytics() {
  const { user } = useUser();
  const db = useFirestore();

  // Data fetching
  const attemptsQuery = useMemoFirebase(() => 
    user ? query(collection(db, "test_attempts"), where("studentId", "==", user.uid), orderBy("completedAt", "asc")) : null,
    [db, user]
  );
  const testsQuery = useMemoFirebase(() => collection(db, "tests"), [db]);
  const coursesQuery = useMemoFirebase(() => collection(db, "courses"), [db]);
  const enrollmentsQuery = useMemoFirebase(() => 
    user ? query(collection(db, "enrollments"), where("studentId", "==", user.uid)) : null,
    [db, user]
  );

  const { data: attempts, loading: loadingAttempts } = useCollection(attemptsQuery);
  const { data: tests } = useCollection(testsQuery);
  const { data: courses } = useCollection(coursesQuery);
  const { data: enrollments } = useCollection(enrollmentsQuery);

  // Advanced calculations
  const analyticsData = useMemo(() => {
    if (!attempts.length) return null;

    const total = attempts.length;
    const avgScore = attempts.reduce((acc, curr) => acc + (curr.finalScore / (curr.totalQuestions || 1)), 0) / total;
    const highestScore = Math.max(...attempts.map(a => a.finalScore / (a.totalQuestions || 1)));
    
    // Subject Proficiency
    const subjectStats: Record<string, { total: number, score: number, count: number }> = {};
    
    attempts.forEach(a => {
      const test = tests.find(t => t.id === a.testId);
      const course = test ? courses.find(c => c.id === test.courseId) : null;
      const category = course?.category || "General";

      if (!subjectStats[category]) {
        subjectStats[category] = { total: 0, score: 0, count: 0 };
      }
      subjectStats[category].total += a.totalQuestions;
      subjectStats[category].score += Math.max(0, a.finalScore);
      subjectStats[category].count += 1;
    });

    const proficiency = Object.entries(subjectStats).map(([name, stats]) => ({
      name,
      percentage: Math.round((stats.score / (stats.total || 1)) * 100),
      attempts: stats.count
    })).sort((a, b) => b.percentage - a.percentage);

    const strengths = proficiency.filter(p => p.percentage >= 70);
    const weaknesses = proficiency.filter(p => p.percentage < 50);

    return {
      avg: Math.round(avgScore * 100),
      high: Math.round(highestScore * 100),
      total,
      proficiency,
      strengths,
      weaknesses
    };
  }, [attempts, tests, courses]);

  const chartData = useMemo(() => {
    return attempts.map(a => ({
      name: a.testTitle.substring(0, 10),
      score: Math.round((a.finalScore / (a.totalQuestions || 1)) * 100),
      date: new Date(a.completedAt).toLocaleDateString()
    }));
  }, [attempts]);

  const COLORS = ['#2E4CAD', '#0F5E8A', '#10b981', '#f59e0b', '#ef4444'];

  const overallProgress = enrollments.length > 0 
    ? Math.round(enrollments.reduce((a, b) => a + (b.progress || 0), 0) / enrollments.length)
    : 0;

  if (loadingAttempts) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center space-y-4">
        <Loader2 className="h-10 w-10 text-primary animate-spin" />
        <p className="text-muted-foreground font-bold uppercase tracking-widest text-[10px]">Loading Hub Analytics...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-3 rounded-2xl text-primary">
            <BarChart3 className="h-7 w-7" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold text-primary">Mathes Learning Hub Analytics</h1>
            <p className="text-muted-foreground text-sm">Deep dive into your academic performance and growth.</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-card p-1 rounded-full border shadow-sm px-3">
          <span className="text-[10px] font-bold text-muted-foreground uppercase">Data sync:</span>
          <Badge variant="outline" className="text-[10px] font-bold text-emerald-600 bg-emerald-50 border-emerald-100">Live</Badge>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Avg. Accuracy', val: `${analyticsData?.avg || 0}%`, icon: Target, bg: 'bg-blue-100', text: 'text-blue-600' },
          { label: 'Highest Percentile', val: `${analyticsData?.high || 0}%`, icon: Trophy, bg: 'bg-emerald-100', text: 'text-emerald-600' },
          { label: 'Total Assessments', val: analyticsData?.total || 0, icon: TrendingUp, bg: 'bg-indigo-100', text: 'text-indigo-600' },
          { label: 'Course Progress', val: `${overallProgress}%`, icon: BrainCircuit, bg: 'bg-orange-100', text: 'text-orange-600' },
        ].map((stat, i) => (
          <Card key={i} className="border-none shadow-md ring-1 ring-border group hover:shadow-lg transition-all">
            <CardContent className="p-6 flex items-center gap-4">
              <div className={`${stat.bg} ${stat.text} p-3 rounded-xl group-hover:scale-110 transition-transform`}>
                <stat.icon className="h-6 w-6" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">{stat.label}</p>
                <h3 className="text-2xl font-bold">{stat.val}</h3>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {!analyticsData ? (
        <Card className="border-2 border-dashed bg-muted/20 py-24">
          <CardContent className="flex flex-col items-center gap-4 text-center">
            <Target className="h-16 w-16 text-muted-foreground/30" />
            <div className="space-y-1">
              <h2 className="text-xl font-bold">No Performance Data Found</h2>
              <p className="text-muted-foreground text-sm max-w-md">Take your first verified mock assessment to generate personalized proficiency maps and strength reports.</p>
            </div>
            <Button asChild className="rounded-full px-8 gap-2">
              <Link href="/dashboard/quizzes">Go to Quiz Hub <ArrowRight className="h-4 w-4" /></Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid lg:grid-cols-3 gap-8">
            <Card className="lg:col-span-2 shadow-xl border-none ring-1 ring-border overflow-hidden">
              <CardHeader className="bg-muted/30 border-b">
                <CardTitle className="text-lg">Performance Timeline</CardTitle>
                <CardDescription>Visualizing your score progression across attempts.</CardDescription>
              </CardHeader>
              <CardContent className="h-[350px] p-6">
                {chartData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                      <XAxis dataKey="date" fontSize={10} axisLine={false} tickLine={false} />
                      <YAxis domain={[0, 100]} fontSize={10} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="score" 
                        stroke="#2E4CAD" 
                        strokeWidth={4} 
                        dot={{ r: 4, fill: '#2E4CAD', strokeWidth: 2, stroke: '#fff' }} 
                        activeDot={{ r: 8, strokeWidth: 0 }} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-muted-foreground text-sm opacity-30">
                    <TrendingUp className="h-12 w-12 mb-2" />
                    <p>Start taking tests to see your progress chart.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="shadow-xl border-none ring-1 ring-border">
              <CardHeader>
                <CardTitle className="text-lg">Subject Mastery</CardTitle>
                <CardDescription>Proficiency across exam categories.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {analyticsData?.proficiency.slice(0, 5).map((p, i) => (
                  <div key={p.name} className="space-y-2">
                    <div className="flex justify-between items-end">
                      <span className="text-xs font-bold truncate max-w-[150px]">{p.name}</span>
                      <span className="text-[10px] font-mono text-primary font-bold">{p.percentage}%</span>
                    </div>
                    <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary transition-all duration-1000" 
                        style={{ width: `${p.percentage}%`, backgroundColor: COLORS[i % COLORS.length] }} 
                      />
                    </div>
                  </div>
                ))}
                {analyticsData.proficiency.length === 0 && (
                  <div className="py-20 text-center text-xs text-muted-foreground italic">
                    Insufficient data to map proficiency.
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            <Card className="border-none shadow-md bg-emerald-50/30 ring-1 ring-emerald-100">
              <CardHeader>
                <CardTitle className="text-emerald-700 flex items-center gap-2">
                  <Zap className="h-5 w-5 text-emerald-500 fill-emerald-500" />
                  Core Strengths
                </CardTitle>
                <CardDescription>Topics where you are performing exceptionally well.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-3">
                {analyticsData?.strengths.map(s => (
                  <div key={s.name} className="bg-white p-4 rounded-xl border border-emerald-100 flex items-center justify-between shadow-sm">
                    <div>
                      <p className="font-bold text-sm text-emerald-900">{s.name}</p>
                      <p className="text-[10px] text-emerald-600 uppercase font-bold">Elite Scholar Grade</p>
                    </div>
                    <Badge className="bg-emerald-500 hover:bg-emerald-500 border-none text-white">{s.percentage}%</Badge>
                  </div>
                ))}
                {analyticsData?.strengths.length === 0 && (
                  <p className="text-center py-8 text-sm text-muted-foreground italic">Keep pushing! Your strengths will appear here.</p>
                )}
              </CardContent>
            </Card>

            <Card className="border-none shadow-md bg-amber-50/30 ring-1 ring-amber-100">
              <CardHeader>
                <CardTitle className="text-amber-700 flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500 fill-amber-500" />
                  Areas for Improvement
                </CardTitle>
                <CardDescription>Topics requiring more focus and practice.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-3">
                {analyticsData?.weaknesses.map(w => (
                  <div key={w.name} className="bg-white p-4 rounded-xl border border-amber-100 flex items-center justify-between shadow-sm">
                    <div>
                      <p className="font-bold text-sm text-amber-900">{w.name}</p>
                      <p className="text-[10px] text-amber-600 uppercase font-bold">Recommended Focus</p>
                    </div>
                    <Badge variant="outline" className="text-amber-600 border-amber-200">{w.percentage}%</Badge>
                  </div>
                ))}
                {analyticsData?.weaknesses.length === 0 && (
                  <p className="text-center py-8 text-sm text-muted-foreground italic">Excellent! No critical weaknesses found.</p>
                )}
              </CardContent>
            </Card>
          </div>

          <Card className="border-none shadow-lg overflow-hidden">
            <CardHeader className="bg-card">
              <CardTitle>Detailed Test History</CardTitle>
              <CardDescription>A complete log of your assessment performance.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {attempts.slice().reverse().map((a) => (
                  <div key={a.id} className="p-6 flex items-center justify-between hover:bg-muted/30 transition-colors">
                    <div className="flex items-center gap-4">
                       <div className="h-10 w-10 bg-primary/5 rounded-full flex items-center justify-center text-primary shrink-0">
                         <Calendar className="h-5 w-5" />
                       </div>
                       <div className="min-w-0">
                         <h4 className="font-bold truncate max-w-[200px] md:max-w-md">{a.testTitle}</h4>
                         <p className="text-[10px] text-muted-foreground uppercase font-bold">{new Date(a.completedAt).toLocaleString()}</p>
                       </div>
                    </div>
                    <div className="text-right flex items-center gap-6">
                      <div className="hidden sm:block">
                        <p className="text-[10px] text-muted-foreground font-bold uppercase mb-1">Score Breakdown</p>
                        <div className="flex gap-2">
                           <Badge variant="outline" className="text-[9px] h-4 border-emerald-200 text-emerald-700">+{a.correctCount} OK</Badge>
                           <Badge variant="outline" className="text-[9px] h-4 border-red-200 text-red-700">-{a.wrongCount} ERR</Badge>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-lg font-bold text-primary">{Math.round((a.finalScore / (a.totalQuestions || 1)) * 100)}%</div>
                        <p className="text-[10px] font-bold text-muted-foreground">{a.finalScore.toFixed(2)} / {a.totalQuestions}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

function ArrowRight(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 12h14" />
      <path d="m12 5 7 7-7 7" />
    </svg>
  )
}
