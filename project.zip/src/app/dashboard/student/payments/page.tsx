
"use client";

import { useMemo } from "react";
import { useUser, useFirestore, useCollection } from "@/firebase";
import { collection, query, where, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { CreditCard, CheckCircle2, Clock, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function MyPayments() {
  const { user } = useUser();
  const db = useFirestore();

  const paymentsQuery = useMemo(() => 
    user ? query(collection(db, "payments"), where("studentId", "==", user.uid), orderBy("createdAt", "desc")) : null,
    [db, user]
  );
  
  const coursesQuery = useMemo(() => collection(db, "courses"), [db]);

  const { data: payments } = useCollection(paymentsQuery);
  const { data: courses } = useCollection(coursesQuery);

  const totalPaid = payments.filter(p => p.status === 'paid').reduce((acc, curr) => acc + curr.amount, 0);
  const pendingAmount = payments.filter(p => p.status !== 'paid').reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-3 rounded-xl">
          <CreditCard className="h-6 w-6 text-primary" />
        </div>
        <h1 className="text-3xl font-headline font-bold text-primary">Fee Statement</h1>
      </div>

      <div className="grid sm:grid-cols-2 gap-6">
        <Card className="bg-emerald-50 border-emerald-200">
          <CardHeader className="pb-2">
            <CardDescription className="text-emerald-700 font-bold uppercase text-[10px]">Total Fees Paid</CardDescription>
            <CardTitle className="text-3xl text-emerald-800">₹{totalPaid}</CardTitle>
          </CardHeader>
        </Card>
        <Card className="bg-amber-50 border-amber-200">
          <CardHeader className="pb-2">
            <CardDescription className="text-amber-700 font-bold uppercase text-[10px]">Pending Balance</CardDescription>
            <CardTitle className="text-3xl text-amber-800">₹{pendingAmount}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-headline font-bold">Transaction History</h2>
        <div className="grid gap-4">
          {payments.map((p) => {
            const course = courses.find(c => c.id === p.courseId);
            return (
              <Card key={p.id} className="border-none ring-1 ring-border shadow-sm">
                <CardContent className="p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-full ${p.status === 'paid' ? 'bg-emerald-100' : 'bg-amber-100'}`}>
                      {p.status === 'paid' ? <CheckCircle2 className="h-5 w-5 text-emerald-600" /> : <Clock className="h-5 w-5 text-amber-600" />}
                    </div>
                    <div>
                      <h4 className="font-bold">{course?.title || "Unknown Course"}</h4>
                      <p className="text-xs text-muted-foreground">{new Date(p.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-lg">₹{p.amount}</div>
                    <Badge variant={p.status === 'paid' ? 'default' : 'secondary'}>{p.status.toUpperCase()}</Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })}
          {payments.length === 0 && (
            <div className="py-20 text-center text-muted-foreground border-2 border-dashed rounded-xl">
              No fee records found for your account.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
