
"use client";

import { useState, useMemo } from "react";
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, addDoc, deleteDoc, doc, updateDoc, query, orderBy, where } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Calendar, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle, 
  LayoutList, 
  Clock, 
  Target, 
  BookOpen,
  ArrowRight,
  TrendingUp,
  Loader2
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const SUBJECTS = ["UPSC GS", "Mathematics", "Tamil Language", "General Science", "Reasoning", "Current Affairs", "English"];

export default function StudyPlanner() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [newTask, setNewTask] = useState("");
  const [selectedSubject, setSelectedSubject] = useState(SUBJECTS[0]);

  const tasksQuery = useMemoFirebase(() => 
    user ? query(collection(db, "users", user.uid, "tasks"), orderBy("date", "desc")) : null,
    [db, user]
  );
  const { data: allTasks } = useCollection(tasksQuery);

  const today = new Date().toISOString().split('T')[0];
  const todayTasks = allTasks.filter(t => t.date === today);
  const completedToday = todayTasks.filter(t => t.completed).length;
  const progress = todayTasks.length > 0 ? Math.round((completedToday / todayTasks.length) * 100) : 0;

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newTask.trim()) return;
    setLoading(true);

    const taskData = {
      title: newTask,
      date: today,
      completed: false,
      subject: selectedSubject,
      createdAt: new Date().toISOString()
    };

    addDoc(collection(db, "users", user.uid, "tasks"), taskData)
      .then(() => {
        setNewTask("");
        setLoading(false);
        toast({ title: "Task Added", description: "Stay focused and consistent." });
      })
      .catch(() => setLoading(false));
  };

  const toggleTask = (taskId: string, current: boolean) => {
    if (!user) return;
    updateDoc(doc(db, "users", user.uid, "tasks", taskId), { completed: !current });
  };

  const deleteTask = (taskId: string) => {
    if (!user) return;
    deleteDoc(doc(db, "users", user.uid, "tasks", taskId));
  };

  return (
    <div className="space-y-8 pb-32">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="bg-primary/10 p-4 rounded-3xl text-primary">
            <LayoutList className="h-8 w-8" />
          </div>
          <div>
            <h1 className="text-4xl font-headline font-bold text-primary">Study Planner</h1>
            <p className="text-muted-foreground text-lg italic">Plan your work, then work your plan.</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-[2rem] shadow-sm ring-1 ring-border min-w-[240px]">
           <div className="flex justify-between items-end mb-2">
             <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Today's Progress</span>
             <span className="text-xl font-bold text-primary">{progress}%</span>
           </div>
           <Progress value={progress} className="h-2 rounded-full" />
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 border-none shadow-xl ring-1 ring-border rounded-[2.5rem] bg-white h-fit sticky top-8">
          <CardHeader className="p-8 pb-4">
            <CardTitle>Create Study Agenda</CardTitle>
            <CardDescription>Break your goals into actionable tasks.</CardDescription>
          </CardHeader>
          <CardContent className="p-8 pt-4 space-y-6">
            <form onSubmit={handleAddTask} className="space-y-4">
              <div className="space-y-2">
                <Label className="text-xs uppercase font-bold text-muted-foreground">Focus Topic</Label>
                <Input 
                  required
                  placeholder="e.g. Revise Ch-4 Integration"
                  className="h-12 rounded-xl"
                  value={newTask}
                  onChange={e => setNewTask(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs uppercase font-bold text-muted-foreground">Subject Area</Label>
                <div className="flex flex-wrap gap-2">
                  {SUBJECTS.map(s => (
                    <Badge 
                      key={s} 
                      variant={selectedSubject === s ? 'default' : 'outline'}
                      className="cursor-pointer py-1.5 px-3 rounded-lg font-bold text-[10px] uppercase transition-all"
                      onClick={() => setSelectedSubject(s)}
                    >
                      {s}
                    </Badge>
                  ))}
                </div>
              </div>
              <Button type="submit" className="w-full h-12 rounded-xl font-bold gap-2 shadow-lg shadow-primary/20" disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                Add to Agenda
              </Button>
            </form>

            <div className="pt-6 border-t">
               <div className="bg-primary/5 p-4 rounded-2xl flex gap-3 items-start border border-primary/10">
                 <Target className="h-4 w-4 text-primary shrink-0" />
                 <p className="text-[11px] text-primary/80 leading-relaxed font-medium">
                   Expert Tip: Keep your daily tasks limited to 3-5 focus areas to ensure depth of learning over quantity.
                 </p>
               </div>
            </div>
          </CardContent>
        </Card>

        <div className="lg:col-span-2">
           <Tabs defaultValue="today" className="w-full">
             <TabsList className="grid w-full grid-cols-2 h-14 bg-muted/50 p-1.5 rounded-2xl mb-8">
               <TabsTrigger value="today" className="rounded-xl font-bold uppercase tracking-widest text-xs">Today's List</TabsTrigger>
               <TabsTrigger value="all" className="rounded-xl font-bold uppercase tracking-widest text-xs">Full History</TabsTrigger>
             </TabsList>

             <TabsContent value="today" className="mt-0">
               <div className="space-y-4">
                 {todayTasks.length > 0 ? todayTasks.map((task) => (
                   <Card key={task.id} className="border-none shadow-md ring-1 ring-border rounded-2xl overflow-hidden group hover:ring-primary/30 transition-all">
                     <CardContent className="p-0 flex items-stretch">
                       <div className={`w-2 shrink-0 ${task.completed ? 'bg-emerald-500' : 'bg-primary'}`} />
                       <div className="p-6 flex-1 flex items-center justify-between gap-6">
                         <div className="flex items-center gap-4 min-w-0">
                           <button 
                            onClick={() => toggleTask(task.id, task.completed)}
                            className={`h-6 w-6 rounded-full border-2 flex items-center justify-center transition-colors shrink-0 ${task.completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-300 hover:border-primary'}`}
                           >
                             {task.completed && <CheckCircle2 className="h-4 w-4" />}
                           </button>
                           <div className="min-w-0">
                             <h4 className={`font-bold text-base truncate ${task.completed ? 'text-muted-foreground line-through opacity-60' : 'text-slate-800'}`}>{task.title}</h4>
                             <div className="flex items-center gap-2 mt-1">
                               <Badge variant="secondary" className="text-[9px] uppercase font-bold py-0 h-4 bg-primary/5 text-primary border-none">
                                 {task.subject}
                               </Badge>
                             </div>
                           </div>
                         </div>
                         <Button variant="ghost" size="icon" className="text-destructive opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => deleteTask(task.id)}>
                           <Trash2 className="h-4 w-4" />
                         </Button>
                       </div>
                     </CardContent>
                   </Card>
                 )) : (
                   <div className="py-24 text-center border-4 border-dashed rounded-[3rem] space-y-6 bg-muted/10">
                     <div className="h-20 w-20 bg-white rounded-3xl shadow-sm mx-auto flex items-center justify-center">
                       <Calendar className="h-10 w-10 opacity-10" />
                     </div>
                     <div>
                       <p className="text-xl font-bold">Your agenda is clear.</p>
                       <p className="text-sm text-muted-foreground max-w-xs mx-auto">Add your first task for today to stay on track for your competitive goals.</p>
                     </div>
                   </div>
                 )}
               </div>
             </TabsContent>

             <TabsContent value="all" className="mt-0">
                <div className="space-y-4">
                  {allTasks.map((task) => (
                    <div key={task.id} className="flex items-center justify-between p-4 bg-white rounded-xl border border-dashed hover:border-primary/40 transition-colors">
                      <div className="flex items-center gap-3">
                        {task.completed ? <CheckCircle2 className="h-4 w-4 text-emerald-500" /> : <Clock className="h-4 w-4 text-muted-foreground" />}
                        <div>
                          <p className="text-sm font-bold">{task.title}</p>
                          <p className="text-[10px] text-muted-foreground font-medium uppercase">{new Date(task.date).toLocaleDateString()} • {task.subject}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-[9px]">{task.completed ? 'DONE' : 'PENDING'}</Badge>
                    </div>
                  ))}
                </div>
             </TabsContent>
           </Tabs>
        </div>
      </div>
    </div>
  );
}
