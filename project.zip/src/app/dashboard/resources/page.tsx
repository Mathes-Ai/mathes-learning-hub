
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Library, ExternalLink, Search, Globe, Info, Filter, ShieldCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";

const RESOURCE_CATEGORIES = ["All", "UPSC", "TNPSC", "SSC", "Banking", "RRB", "UGC NET", "TET"];

export default function PublicResourcesLibrary() {
  const db = useFirestore();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const resourcesRef = useMemoFirebase(() => collection(db, "public_resources"), [db]);
  const resourcesQuery = useMemoFirebase(() => query(resourcesRef, orderBy("category", "asc")), [resourcesRef]);
  
  const { data: resources, loading } = useCollection(resourcesQuery);

  const filteredResources = useMemo(() => {
    return resources.filter(res => {
      const matchesSearch = 
        res.title.toLowerCase().includes(search.toLowerCase()) ||
        res.description?.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = activeCategory === "All" || res.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [resources, search, activeCategory]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-4xl font-headline font-bold text-primary flex items-center gap-3">
            <Library className="h-10 w-10 text-accent" />
            Official Resource Hub
          </h1>
          <p className="text-muted-foreground text-lg">Official syllabi, notifications, and public government documents.</p>
        </div>
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input 
            placeholder="Search syllabi or official docs..." 
            className="pl-10 h-12 shadow-sm rounded-full" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-card p-2 rounded-2xl border shadow-sm flex items-center gap-3">
        <div className="bg-muted p-2 rounded-xl shrink-0 hidden sm:block">
          <Filter className="h-4 w-4 text-muted-foreground" />
        </div>
        <ScrollArea className="w-full">
          <div className="flex gap-2 p-1">
            {RESOURCE_CATEGORIES.map((cat) => (
              <Button 
                key={cat} 
                variant={cat === activeCategory ? 'default' : 'ghost'}
                size="sm"
                className="rounded-full whitespace-nowrap px-6 font-bold"
                onClick={() => setActiveCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>

      <div className="bg-primary/5 border border-primary/20 p-6 rounded-2xl flex gap-4 items-start shadow-sm animate-in fade-in duration-700">
        <Info className="h-6 w-6 text-primary shrink-0" />
        <div className="space-y-1">
          <h3 className="font-bold text-primary">Academic Integrity Disclaimer</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Resources are sourced from official public websites (UPSC, TNPSC, etc.). This hub serves as a curated directory for official documentation to assist aspirants in their preparation.
          </p>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredResources.map((res) => (
          <Card key={res.id} className="group hover:shadow-2xl transition-all duration-300 border-none ring-1 ring-border bg-card flex flex-col overflow-hidden">
            <CardHeader className="p-6 pb-2">
              <div className="flex items-center justify-between mb-4">
                <Badge variant="secondary" className="text-[10px] uppercase font-bold px-2 py-0.5 bg-primary/10 text-primary border-none">
                  {res.category}
                </Badge>
                <Badge variant="outline" className="text-[9px] uppercase font-bold tracking-tighter">
                  {res.type}
                </Badge>
              </div>
              <CardTitle className="text-xl font-headline group-hover:text-primary transition-colors leading-tight line-clamp-2 min-h-[3.5rem]">
                {res.title}
              </CardTitle>
            </CardHeader>
            
            <CardContent className="p-6 pt-2 flex-1">
              <p className="text-sm text-muted-foreground line-clamp-4 leading-relaxed italic">
                {res.description || `Official ${res.type.toLowerCase()} documentation for the ${res.category} competitive examination.`}
              </p>
            </CardContent>

            <CardFooter className="p-6 pt-0 mt-auto border-t bg-muted/5 flex items-center justify-between">
              <div className="flex items-center gap-1 text-[9px] font-bold text-emerald-600 uppercase">
                <ShieldCheck className="h-3 w-3" /> Official Source
              </div>
              <Button asChild size="sm" className="rounded-full gap-2 font-bold shadow-lg shadow-primary/20">
                <a href={res.url} target="_blank" rel="noopener noreferrer">
                  Open Resource <ExternalLink className="h-3 w-3" />
                </a>
              </Button>
            </CardFooter>
          </Card>
        ))}
        
        {!loading && filteredResources.length === 0 && (
          <div className="col-span-full py-32 text-center flex flex-col items-center gap-4 border-2 border-dashed rounded-3xl bg-muted/20">
            <Library className="h-16 w-16 text-muted-foreground/30" />
            <div>
              <p className="text-xl font-bold">No resources found for "{search}"</p>
              <p className="text-muted-foreground">Try selecting a different category or refining your search.</p>
              <Button variant="outline" className="mt-4 rounded-full" onClick={() => { setSearch(""); setActiveCategory("All"); }}>
                View All Resources
              </Button>
            </div>
          </div>
        )}

        {loading && Array.from({length: 4}).map((_, i) => (
          <Card key={i} className="animate-pulse h-64 bg-muted/50 rounded-2xl" />
        ))}
      </div>
    </div>
  );
}
