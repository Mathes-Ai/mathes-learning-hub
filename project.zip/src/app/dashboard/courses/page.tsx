"use client";

import { useState, useMemo, useEffect } from "react";
import { useLanguage } from "@/context/LanguageContext";
import { useFirestore, useCollection, useUser } from "@/firebase";
import { collection, addDoc, doc, writeBatch } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, PlayCircle, BookOpen, Star, Clock, Trophy, DatabaseZap, Loader2, AlertCircle, Info, CheckCircle2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import Link from "next/link";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";

const CATEGORIES = [
  "All", "UPSC (Prelims & Mains)", "TNPSC (Group 1, 2, 2A, 4)", "SSC (CGL, CHSL, MTS, GD, CPO)",
  "Banking (IBPS, SBI, RRB)", "Railways (NTPC, Group D, ALP)", "UGC NET", "TET, TRB",
  "Police Exams", "Defence (NDA, CDS, AFCAT)", "Insurance (LIC, NIACL)", "State PSC Exams",
  "CUET", "NEET Foundation", "JEE Foundation", "General Aptitude", "Current Affairs",
  "Reasoning", "Quantitative Aptitude", "English", "Tamil"
];

export default function CourseLibrary() {
  const { t } = useLanguage();
  const db = useFirestore();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [isSeeding, setIsSeeding] = useState(false);

  const coursesRef = useMemo(() => collection(db, "courses"), [db]);
  const { data: courses, loading, error } = useCollection(coursesRef);

  useEffect(() => {
    console.log(`[Exam Hub Debug] Courses loaded: ${courses.length}`);
  }, [courses]);

  const filteredCourses = useMemo(() => {
    return courses.filter(course => {
      const matchesSearch = 
        course.title.toLowerCase().includes(search.toLowerCase()) ||
        course.category.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = activeCategory === "All" || course.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [courses, search, activeCategory]);

  const handleSeed = async () => {
    setIsSeeding(true);
    const batch = writeBatch(db);
    
    const sampleCategories = CATEGORIES.slice(1, 11);
    
    const sampleCourses = sampleCategories.map((cat, index) => ({
      title: `${cat} - Mastery Module ${new Date().getFullYear()}`,
      category: cat,
      level: index % 2 === 0 ? "Beginner" : "Intermediate",
      description: `Premium comprehensive preparation for ${cat}. Includes official syllabus coverage, PDF notes, and mock assessments. Now completely free for all students.`,
      imageUrl: `https://picsum.photos/seed/${cat.replace(/\s/g, '')}/600/400`,
      duration: index % 2 === 0 ? "6 Months" : "1 Year",
      fee: 0,
      teacherId: "admin",
      createdAt: new Date().toISOString(),
    }));

    try {
      for (const course of sampleCourses) {
        const newDocRef = doc(collection(db, "courses"));
        batch.set(newDocRef, course);
      }
      await batch.commit();
      toast({ title: "Hub Seeded", description: "Free catalog populated successfully." });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Seeding Failed", description: err.message });
    } finally {
      setIsSeeding(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Diagnostic Bar */}
      <div className="bg-primary/5 border border-primary/20 rounded-xl p-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs font-bold text-primary">
            <div className={`h-2 w-2 rounded-full ${loading ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`} />
            STATUS: {loading ? 'FETCHING' : 'ONLINE'}
          </div>
          <Badge variant="outline" className="text-[10px] font-bold">LOADED: {courses.length}</Badge>
          <Badge variant="outline" className="text-[10px] font-bold">MODALITY: FREE ACCESS</Badge>
        </div>
        {!loading && courses.length === 0 && (
          <Button size="sm" variant="outline" className="h-7 text-[10px] gap-2 font-bold" onClick={handleSeed} disabled={isSeeding}>
            {isSeeding ? <Loader2 className="h-3 w-3 animate-spin" /> : <DatabaseZap className="h-3 w-3" />}
            POPULATE FREE HUB
          </Button>
        )}
      </div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-headline font-bold text-primary flex items-center gap-3">
            <Trophy className="h-10 w-10 text-accent" />
            Competitive Exam Hub
          </h1>
          <p className="text-muted-foreground text-lg mt-2">Access premium study materials for all major Indian competitive exams. Now 100% Free.</p>
        </div>
        <div className="flex gap-2">
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input 
              placeholder="Search by exam name..." 
              className="pl-10 h-12 text-lg shadow-sm" 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="bg-card p-2 rounded-xl border shadow-sm">
        <ScrollArea className="w-full">
          <div className="flex gap-2 p-1">
            {CATEGORIES.map((cat) => (
              <Button 
                key={cat} 
                variant={cat === activeCategory ? 'default' : 'ghost'}
                size="sm"
                className="rounded-full whitespace-nowrap px-6"
                onClick={() => setActiveCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>

      {error && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="p-8 text-center space-y-4">
            <AlertCircle className="h-12 w-12 text-destructive mx-auto" />
            <div className="space-y-1">
              <p className="text-lg font-bold text-destructive">Database Connection Unavailable</p>
              <p className="text-sm text-muted-foreground">Please check your connection and retry.</p>
            </div>
            <Button onClick={() => window.location.reload()} variant="outline">Retry Connection</Button>
          </CardContent>
        </Card>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {filteredCourses.map((course) => (
          <Link key={course.id} href={`/dashboard/courses/${course.id}`} className="block group no-underline">
            <Card className="h-full group overflow-hidden flex flex-col hover:shadow-2xl transition-all duration-300 border-none ring-1 ring-border bg-card">
              <div className="aspect-video relative overflow-hidden bg-muted">
                {course.imageUrl ? (
                  <img 
                    src={course.imageUrl} 
                    alt={course.title}
                    className="object-cover w-full h-full md:group-hover:scale-110 transition-transform duration-700"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                     <BookOpen className="h-12 w-12 opacity-10" />
                  </div>
                )}
                <div className="absolute top-3 left-3 flex gap-2">
                  <Badge className="bg-emerald-500 border-none text-[10px] uppercase font-bold px-2 py-0.5 text-white">
                    FREE
                  </Badge>
                </div>
                
                {/* Desktop-only hover overlay to prevent mobile double-tap */}
                <div className="absolute inset-0 bg-black/40 hidden md:flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                  <div className="bg-white/20 backdrop-blur-md p-3 rounded-full border border-white/30">
                    <PlayCircle className="text-white h-10 w-10" />
                  </div>
                </div>
              </div>
              
              <CardHeader className="p-5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-accent uppercase tracking-widest bg-accent/10 px-2 py-1 rounded">
                    {course.category}
                  </span>
                </div>
                <CardTitle className="text-xl font-headline group-hover:text-primary transition-colors line-clamp-2">
                  {course.title}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="px-5 pb-5 flex-1">
                <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed">
                  {course.description || `Preparation for ${course.category}.`}
                </p>
              </CardContent>

              <CardFooter className="p-5 pt-0 mt-auto flex items-center justify-between border-t bg-muted/5">
                <div className="flex items-center gap-1 text-emerald-600 font-bold text-sm">
                  <CheckCircle2 className="h-4 w-4" />
                  CLAIM ACCESS
                </div>
                {/* Styled div instead of button to avoid nested interactive elements */}
                <div className="h-9 px-6 flex items-center justify-center bg-primary text-white text-sm font-medium rounded-full shadow-lg shadow-primary/20 transition-colors md:group-hover:bg-primary/90">
                   Enter Hub
                </div>
              </CardFooter>
            </Card>
          </Link>
        ))}
        
        {!loading && filteredCourses.length === 0 && !error && (
          <div className="col-span-full py-32 text-center flex flex-col items-center gap-4 border-2 border-dashed rounded-3xl bg-muted/20">
            {courses.length === 0 ? (
              <>
                <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center text-primary mb-2">
                  <DatabaseZap className="h-8 w-8" />
                </div>
                <div>
                  <p className="text-xl font-bold">The Hub is Empty</p>
                  <Button className="mt-6 rounded-full px-8 gap-2" onClick={handleSeed} disabled={isSeeding}>
                    {isSeeding ? <Loader2 className="h-4 w-4 animate-spin" /> : <DatabaseZap className="h-4 w-4" />}
                    Seed Free Exam Catalog
                  </Button>
                </div>
              </>
            ) : (
              <div>
                <p className="text-xl font-bold">No results for "{search}"</p>
                <Button variant="outline" className="mt-4 rounded-full" onClick={() => { setSearch(""); setActiveCategory("All"); }}>
                  Reset Filters
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
