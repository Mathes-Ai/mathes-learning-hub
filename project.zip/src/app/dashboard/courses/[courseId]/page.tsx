
"use client";

import { useMemo, useState, useEffect } from "react";
import { useParams } from "next/navigation";
import { useFirestore, useDoc, useCollection, useUser, useMemoFirebase } from "@/firebase";
import { doc, collection, query, where, addDoc, updateDoc, increment, writeBatch } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, PlayCircle, ArrowLeft, Download, ExternalLink, BookOpen, CheckCircle2, Loader2, Video, Search, ShieldCheck, AlertCircle, HelpCircle, Globe, Info, DatabaseZap } from "lucide-react";
import Link from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { Input } from "@/components/ui/input";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function CourseDetails() {
  const params = useParams();
  const courseId = params.courseId as string;
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const [enrolling, setEnrolling] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [search, setSearch] = useState("");

  const courseRef = useMemo(() => doc(db, "courses", courseId), [db, courseId]);
  
  const materialsQuery = useMemoFirebase(() => 
    query(collection(db, "materials"), where("courseId", "==", courseId)), 
    [db, courseId]
  );
  
  const enrollmentQuery = useMemoFirebase(() => 
    user ? query(collection(db, "enrollments"), where("courseId", "==", courseId), where("studentId", "==", user.uid)) : null,
    [db, courseId, user]
  );

  const { data: course, loading: courseLoading } = useDoc(courseRef);
  const { data: materials, loading: materialsLoading, error: materialsError } = useCollection(materialsQuery);
  const { data: enrollments } = useCollection(enrollmentQuery);

  const isEnrolled = enrollments.length > 0;

  const filteredMaterials = useMemo(() => {
    return materials.filter(m => m.title?.toLowerCase().includes(search.toLowerCase()));
  }, [materials, search]);

  // DIAGNOSTIC LOGGING
  useEffect(() => {
    if (!materialsLoading) {
      console.log(`[Diagnostic] Collection: materials | Path: /materials | Course ID: ${courseId}`);
      console.log(`[Diagnostic] Resources Found in Firestore: ${materials.length}`);
    }
    if (materialsError) {
      console.error("[Diagnostic] Firestore Error:", materialsError);
    }
  }, [materials, materialsLoading, courseId, materialsError]);

  const handleEnroll = () => {
    if (!user) return;
    setEnrolling(true);

    const enrollmentData = {
      studentId: user.uid,
      courseId: courseId,
      courseTitle: course?.title,
      enrolledAt: new Date().toISOString(),
      status: 'active',
      progress: 0
    };

    addDoc(collection(db, "enrollments"), enrollmentData)
      .then(() => {
        setEnrolling(false);
        toast({ title: "Access Granted!", description: `You now have full free access to ${course?.title}.` });
      })
      .catch(async (err) => {
        setEnrolling(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: 'enrollments',
          operation: 'create',
          requestResourceData: enrollmentData
        }));
      });
  };

  const handleAutoSeed = async () => {
    if (seeding) return;
    setSeeding(true);
    const batch = writeBatch(db);
    const materialsRef = collection(db, "materials");
    
    const samples = [
      { title: "Official Syllabus Guide", type: "PDF", desc: "Detailed breakdown of the current curriculum provided by official sources." },
      { title: "Exam Pattern Analysis", type: "PDF", desc: "Official structure of the paper, including tier details and marking rules." },
      { title: "Foundation Concept Notes", type: "PDF", desc: "Expert-curated notes covering foundational topics of the course." },
      { title: "PYQ Trend Analysis (Last 5 Years)", type: "PDF", desc: "Statistical breakdown of question frequencies over the last 5 cycles." },
      { title: "Official Registration Portal Link", type: "Link", desc: "Direct portal link for examination registration and eligibility criteria." }
    ];

    try {
      for (const sample of samples) {
        const newDocRef = doc(materialsRef);
        batch.set(newDocRef, {
          title: sample.title,
          courseId: courseId,
          type: sample.type,
          url: "#", 
          description: sample.desc,
          downloadCount: 0,
          createdAt: new Date().toISOString(),
          isPlaceholder: true,
          isOfficial: true
        });
      }
      await batch.commit();
      toast({ title: "Library Seeded", description: "Academic resources have been populated for this course." });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Seeding Failed", description: err.message });
    } finally {
      setSeeding(false);
    }
  };

  const trackDownload = (materialId: string, url: string) => {
    if (url === "#" || !url) {
      toast({ 
        title: "Digitization Pending", 
        description: "Our faculty is currently validating this official document scan.",
      });
      return;
    }
    const matRef = doc(db, "materials", materialId);
    updateDoc(matRef, { downloadCount: increment(1) });
    window.open(url, '_blank');
  };

  if (courseLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-1/3" />
        <div className="grid md:grid-cols-2 gap-6">
          <Skeleton className="h-64" />
          <Skeleton className="h-64" />
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold">Course not found</h2>
        <Button asChild variant="link" className="mt-4">
          <a href="/dashboard/courses">Back to Library</a>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <a href="/dashboard/courses"><ArrowLeft className="h-5 w-5" /></a>
          </Button>
          <div>
            <h1 className="text-3xl font-headline font-bold text-primary">{course.title}</h1>
            <div className="flex gap-2 mt-1">
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">FREE ENROLLMENT</Badge>
              <Badge variant="outline">{course.level}</Badge>
            </div>
          </div>
        </div>
        
        {isEnrolled ? (
          <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 px-4 py-2 rounded-full border border-emerald-100">
            <ShieldCheck className="h-5 w-5" />
            <span className="font-bold text-sm">Full Access Enabled</span>
          </div>
        ) : (
          <Button 
            className="rounded-full px-8 h-12 shadow-lg shadow-primary/20 bg-emerald-600 hover:bg-emerald-700" 
            onClick={handleEnroll}
            disabled={enrolling}
          >
            {enrolling ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Claim Free Access"}
          </Button>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <Card className="overflow-hidden border-none shadow-lg">
            <div className="aspect-video bg-muted relative">
              {course.imageUrl ? (
                <img src={course.imageUrl} className="w-full h-full object-cover" alt="Course" />
              ) : (
                <div className="flex items-center justify-center w-full h-full opacity-20">
                  <BookOpen className="h-20 w-20" />
                </div>
              )}
            </div>
            <CardContent className="p-8 space-y-4">
              <h2 className="text-xl font-bold">About this Module</h2>
              <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                {course.description || "No description provided for this course."}
              </p>
              <div className="pt-4 border-t mt-6">
                <h3 className="font-bold text-sm uppercase text-muted-foreground mb-3 tracking-widest">Included for free:</h3>
                <ul className="grid grid-cols-2 gap-3">
                  {['Official Public Syllabi', 'Exam Pattern Analysis', 'Mock Assessments', 'Doubt Solving Sessions'].map(item => (
                    <li key={item} className="flex items-center gap-2 text-xs font-medium">
                      <CheckCircle2 className="h-3 w-3 text-emerald-500" /> {item}
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-headline font-bold">Academic Library</h2>
            <div className="relative w-32">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
              <Input 
                placeholder="Search..." 
                className="pl-7 h-7 text-[10px]" 
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>

          {/* DEBUG UI */}
          {!materialsLoading && (
            <div className="flex flex-wrap gap-2">
               <Badge variant="outline" className="text-[9px] font-bold">RESOURCES: {materials.length}</Badge>
               <Badge variant="outline" className="text-[9px] font-bold">COLLECTION: materials</Badge>
            </div>
          )}

          <div className="bg-primary/5 border border-primary/20 p-4 rounded-xl shadow-sm">
             <div className="flex items-center gap-2 mb-2">
               <ShieldCheck className="h-4 w-4 text-primary" />
               <p className="text-[10px] font-bold uppercase text-primary">Academic Integrity</p>
             </div>
             <p className="text-[10px] text-muted-foreground leading-relaxed">
               All resources are sourced from official public domains (UPSC, TNPSC, etc.) and provided strictly for educational guidance.
             </p>
          </div>
          
          {!isEnrolled && (
            <div className="bg-amber-50 border border-amber-100 p-4 rounded-xl text-xs text-amber-800 flex gap-2 animate-in fade-in slide-in-from-top-1">
              <Info className="h-4 w-4 shrink-0" />
              <p>Enroll (Always Free) to view and download the official documentation for this exam.</p>
            </div>
          )}
          
          <div className="space-y-3">
            {filteredMaterials.map((m) => (
              <TooltipProvider key={m.id}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Card 
                      className={`group border-none ring-1 ring-border transition-all ${isEnrolled ? 'hover:shadow-md cursor-pointer bg-card' : 'opacity-60 grayscale bg-muted/30'}`}
                      onClick={() => isEnrolled && trackDownload(m.id, m.url)}
                    >
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${m.isOfficial ? 'bg-emerald-100 text-emerald-700' : m.type === 'Video' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-700'}`}>
                            {m.isOfficial ? <Globe className="h-5 w-5" /> : m.type === 'Video' ? <Video className="h-5 w-5" /> : <FileText className="h-5 w-5" />}
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-bold truncate leading-tight">{m.title}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className="text-[8px] h-3.5 px-1 border-primary/20 text-primary uppercase font-bold">{m.type}</Badge>
                              {m.isOfficial && (
                                <Badge variant="secondary" className="text-[8px] h-3.5 px-1 bg-emerald-50 text-emerald-700 border-emerald-100 uppercase font-bold">OFFICIAL</Badge>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <p className="text-[11px] text-muted-foreground line-clamp-2 leading-relaxed">
                          {m.description || "Official examination resource for competitive aspirants."}
                        </p>

                        {isEnrolled && (
                          <div className="pt-2 flex justify-end">
                            <Button size="sm" variant="outline" className="h-7 text-[10px] gap-1.5 font-bold uppercase rounded-full group-hover:bg-primary group-hover:text-white transition-colors">
                              {m.isPlaceholder ? <HelpCircle className="h-3 w-3" /> : <Download className="h-3 w-3" />}
                              {m.isPlaceholder ? 'Digitization Status' : 'Open Resource'}
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TooltipTrigger>
                  {m.isPlaceholder && (
                    <TooltipContent>
                      <p className="text-xs">Document being verified from official government source</p>
                    </TooltipContent>
                  )}
                </Tooltip>
              </TooltipProvider>
            ))}
            
            {!materialsLoading && materials.length === 0 && (
              <div className="py-12 text-center border-2 border-dashed rounded-2xl bg-muted/10 space-y-4">
                <div className="space-y-1">
                   <FileText className="h-8 w-8 mx-auto text-muted-foreground/30" />
                   <p className="text-xs text-muted-foreground font-medium">No resources found for this course.</p>
                </div>
                <Button variant="outline" size="sm" className="h-8 text-[10px] gap-2" onClick={handleAutoSeed} disabled={seeding}>
                  {seeding ? <Loader2 className="h-3 w-3 animate-spin" /> : <DatabaseZap className="h-3 w-3" />}
                  Auto-Seed Library
                </Button>
              </div>
            )}

            {!materialsLoading && materials.length > 0 && filteredMaterials.length === 0 && (
               <div className="py-8 text-center text-xs text-muted-foreground">
                 No matches for "{search}"
               </div>
            )}
            
            {materialsLoading && Array.from({length: 3}).map((_, i) => (
              <Skeleton key={i} className="h-32 w-full rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
