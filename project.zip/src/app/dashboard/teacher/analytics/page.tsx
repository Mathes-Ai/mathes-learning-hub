
"use client";

import { useMemo, useState } from "react";
import { useUser, useFirestore, useCollection } from "@/firebase";
import { collection, query, where, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { 
  BarChart3, 
  Users, 
  CheckCircle2, 
  Clock, 
  Download, 
  TrendingUp, 
  MessageSquare, 
  FileText,
  Printer,
  ChevronRight,
  Target,
  UserCheck
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function TeacherAnalytics() {
  const { user } = useUser();
  const db = useFirestore();
  const [selectedCourseId, setSelectedCourseId] = useState("all");

  // Multi-collection data fetching
  const myCoursesQuery = useMemo(() => 
    user ? query(collection(db, "courses"), where("teacherId", "==", user.uid)) : null, 
    [db, user]
  );
  const { data: courses } = useCollection(myCoursesQuery);
  const myCourseIds = useMemo(() => courses.map(c => c.id), [courses]);

  const enrollmentsQuery = useMemo(() => 
    myCourseIds.length > 0 ? query(collection(db, "enrollments"), where("courseId", "in", myCourseIds)) : null,
    [db, myCourseIds]
  );
  const attendanceQuery = useMemo(() => 
    myCourseIds.length > 0 ? query(collection(db, "attendance"), where("courseId", "in", myCourseIds)) : null,
    [db, myCourseIds]
  );
  const doubtsQuery = useMemo(() => 
    user ? query(collection(db, "doubts"), where("teacherId", "==", user.uid)) : null,
    [db, user]
  );
  const testsQuery = useMemo(() => 
    myCourseIds.length > 0 ? query(collection(db, "tests"), where("courseId", "in", myCourseIds)) : null,
    [db, myCourseIds]
  );
  const attemptsQuery = useMemo(() => 
    collection(db, "test_attempts"), [db]
  );

  const { data: enrollments } = useCollection(enrollmentsQuery);
  const { data: attendance } = useCollection(attendanceQuery);
  const { data: doubts } = useCollection(doubtsQuery);
  const { data: tests } = useCollection(testsQuery);
  const { data: allAttempts } = useCollection(attemptsQuery);

  // Filtered relevant attempts (only for tests in teacher's courses)
  const relevantAttempts = useMemo(() => {
    const teacherTestIds = tests.map(t => t.id);
    return allAttempts.filter(a => teacherTestIds.includes(a.testId));
  }, [allAttempts, tests]);

  // Aggregated Insights
  const teacherStats = useMemo(() => {
    const totalStudents = new Set(enrollments.map(e => e.studentId)).size;
    const resolvedDoubts = doubts.filter(d => d.status === 'resolved').length;
    const doubtResolutionRate = doubts.length > 0 ? Math.round((resolvedDoubts / doubts.length) * 100) : 0;
    
    const avgAttendance = attendance.length > 0 
      ? Math.round((attendance.filter(r => r.status === 'present').length / attendance.length) * 100) 
      : 0;

    const avgPerformance = relevantAttempts.length > 0
      ? Math.round((relevantAttempts.reduce((acc, curr) => acc + (curr.finalScore / curr.totalQuestions), 0) / relevantAttempts.length) * 100)
      : 0;

    return { totalStudents, doubtResolutionRate, avgAttendance, avgPerformance };
  }, [enrollments, doubts, attendance, relevantAttempts]);

  // Chart Data: Attendance Trends
  const attendanceTrend = useMemo(() => {
    const dates: Record<string, { present: number, total: number }> = {};
    attendance.forEach(r => {
      if (!dates[r.date]) dates[r.date] = { present: 0, total: 0 };
      dates[r.date].total++;
      if (r.status === 'present') dates[r.date].present++;
    });
    return Object.entries(dates).map(([date, stats]) => ({
      date: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      rate: Math.round((stats.present / stats.total) * 100)
    })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).slice(-10);
  }, [attendance]);

  // Doubt Stats for Pie Chart
  const doubtChartData = [
    { name: 'Resolved', value: doubts.filter(d => d.status === 'resolved').length },
    { name: 'Pending', value: doubts.filter(d => d.status === 'pending').length },
  ];
  const COLORS = ['#2E4CAD', '#f59e0b'];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 pb-20 print:p-0">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-3 rounded-2xl text-primary">
            <BarChart3 className="h-7 w-7" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold text-primary">Faculty Insights</h1>
            <p className="text-muted-foreground text-sm">Comprehensive performance metrics for your courses.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Select value={selectedCourseId} onValueChange={setSelectedCourseId}>
            <SelectTrigger className="w-48 bg-card">
              <SelectValue placeholder="All Courses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Global Overview</SelectItem>
              {courses.map(c => <SelectItem key={c.id} value={c.id}>{c.title}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant="outline" className="gap-2" onClick={handlePrint}>
            <Printer className="h-4 w-4" /> Export Report
          </Button>
        </div>
      </header>

      {/* Key Metrics Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Active Roster', val: teacherStats.totalStudents, icon: Users, color: 'text-blue-600', bg: 'bg-blue-100' },
          { label: 'Avg. Attendance', val: `${teacherStats.avgAttendance}%`, icon: UserCheck, color: 'text-emerald-600', bg: 'bg-emerald-100' },
          { label: 'Test Success', val: `${teacherStats.avgPerformance}%`, icon: Target, color: 'text-indigo-600', bg: 'bg-indigo-100' },
          { label: 'Doubt Resolution', val: `${teacherStats.doubtResolutionRate}%`, icon: MessageSquare, color: 'text-orange-600', bg: 'bg-orange-100' },
        ].map((stat, i) => (
          <Card key={i} className="border-none shadow-md ring-1 ring-border group hover:shadow-lg transition-all">
            <CardContent className="p-6 flex items-center gap-4">
              <div className={`${stat.bg} ${stat.color} p-3 rounded-xl group-hover:scale-110 transition-transform`}>
                <stat.icon className="h-6 w-6" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">{stat.label}</p>
                <h3 className="text-2xl font-bold">{stat.val}</h3>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Attendance Trend Chart */}
        <Card className="lg:col-span-2 shadow-xl border-none ring-1 ring-border overflow-hidden">
          <CardHeader className="bg-muted/30 border-b">
            <CardTitle className="text-lg">Classroom Engagement Trend</CardTitle>
            <CardDescription>Visualizing student attendance percentage over the last 10 sessions.</CardDescription>
          </CardHeader>
          <CardContent className="h-[350px] p-6">
            {attendanceTrend.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={attendanceTrend}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                  <XAxis dataKey="date" fontSize={10} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 100]} fontSize={10} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="rate" 
                    stroke="#2E4CAD" 
                    strokeWidth={4} 
                    dot={{ r: 4, fill: '#2E4CAD', strokeWidth: 2, stroke: '#fff' }} 
                    activeDot={{ r: 8, strokeWidth: 0 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-30 italic">
                <UserCheck className="h-12 w-12 mb-2" />
                <p>No attendance records found to map trends.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Doubt Resolution Stats */}
        <Card className="shadow-xl border-none ring-1 ring-border flex flex-col">
          <CardHeader>
            <CardTitle className="text-lg">Communication Efficiency</CardTitle>
            <CardDescription>Resolved vs. Pending student queries.</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col items-center justify-center">
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={doubtChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {doubtChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex gap-4 mt-4">
               {doubtChartData.map((d, i) => (
                 <div key={d.name} className="flex items-center gap-2">
                   <div className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                   <span className="text-xs font-bold text-muted-foreground">{d.name}: {d.value}</span>
                 </div>
               ))}
            </div>
          </CardContent>
          <CardFooter className="bg-muted/10 p-4 border-t">
             <Button variant="ghost" size="sm" className="w-full text-primary font-bold" asChild>
               <a href="/dashboard/teacher/doubts">Resolve Pending Queries <ChevronRight className="h-4 w-4 ml-1" /></a>
             </Button>
          </CardFooter>
        </Card>
      </div>

      {/* Detailed Performance Table */}
      <Card className="border-none shadow-xl ring-1 ring-border">
        <CardHeader>
          <CardTitle>Course-wise Performance Report</CardTitle>
          <CardDescription>Metrics aggregated per course module.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Course Module</TableHead>
                <TableHead>Students</TableHead>
                <TableHead>Avg. Progress</TableHead>
                <TableHead>Test Median</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {courses.map((course) => {
                const courseEnrollments = enrollments.filter(e => e.courseId === course.id);
                const avgProgress = courseEnrollments.length > 0 
                  ? Math.round(courseEnrollments.reduce((acc, curr) => acc + (curr.progress || 0), 0) / courseEnrollments.length)
                  : 0;
                
                const courseTests = tests.filter(t => t.courseId === course.id);
                const courseTestIds = courseTests.map(t => t.id);
                const courseAttempts = relevantAttempts.filter(a => courseTestIds.includes(a.testId));
                const medianScore = courseAttempts.length > 0
                  ? Math.round((courseAttempts.reduce((acc, curr) => acc + (curr.finalScore / curr.totalQuestions), 0) / courseAttempts.length) * 100)
                  : 0;

                return (
                  <TableRow key={course.id}>
                    <TableCell>
                      <div className="font-bold text-sm">{course.title}</div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest">{course.category}</div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Users className="h-3 w-3 text-muted-foreground" />
                        <span className="text-sm font-medium">{courseEnrollments.length}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 w-24">
                        <Progress value={avgProgress} className="h-1.5" />
                        <span className="text-[10px] font-bold">{avgProgress}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={medianScore >= 70 ? 'default' : 'secondary'} className="text-[10px]">
                        {medianScore}% Accuracy
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" asChild>
                        <a href={`/dashboard/admin/courses`}>Edit Module</a>
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
              {courses.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="py-20 text-center text-muted-foreground italic">
                    No active courses found for reporting.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
