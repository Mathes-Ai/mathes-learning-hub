
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useUser } from "@/firebase";
import { collection, query, where, updateDoc, doc, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, CheckCircle, Send, Loader2, Sparkles, User } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";

export default function DoubtSolvingPortal() {
  const db = useFirestore();
  const { user } = useUser();
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [answer, setAnswer] = useState("");

  const doubtsQuery = useMemo(() => 
    user ? query(collection(db, "doubts"), where("teacherId", "==", user.uid), orderBy("createdAt", "desc")) : null,
    [db, user]
  );

  const { data: doubts } = useCollection(doubtsQuery);

  const handleResolve = (doubtId: string) => {
    if (!answer.trim()) return;
    setResolvingId(doubtId);

    const doubtRef = doc(db, "doubts", doubtId);
    updateDoc(doubtRef, {
      answer: answer,
      status: 'resolved',
      resolvedAt: new Date().toISOString()
    })
    .then(() => {
      setResolvingId(null);
      setAnswer("");
    })
    .catch(async (err) => {
      setResolvingId(null);
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: doubtRef.path,
        operation: 'update',
        requestResourceData: { answer, status: 'resolved' }
      }));
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-orange-100 p-3 rounded-xl text-orange-600">
          <MessageCircle className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-3xl font-headline font-bold">Doubt Solving Center</h1>
          <p className="text-muted-foreground">Help students overcome their academic hurdles.</p>
        </div>
      </div>

      <div className="grid gap-6">
        {doubts.map((doubt) => (
          <Card key={doubt.id} className={`shadow-md border-none ${doubt.status === 'resolved' ? 'opacity-70' : 'ring-2 ring-primary/10'}`}>
            <CardHeader className="flex flex-row items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 bg-muted rounded-full flex items-center justify-center">
                  <User className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <CardTitle className="text-lg">{doubt.studentName || 'Anonymous Student'}</CardTitle>
                  <CardDescription>Asked on {new Date(doubt.createdAt).toLocaleString()}</CardDescription>
                </div>
              </div>
              <Badge variant={doubt.status === 'resolved' ? 'default' : 'secondary'}>
                {doubt.status.toUpperCase()}
              </Badge>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted/50 p-4 rounded-xl border-l-4 border-l-primary">
                <p className="font-medium text-foreground italic">"{doubt.question}"</p>
              </div>
              
              {doubt.status === 'pending' ? (
                <div className="space-y-3">
                  <label className="text-xs font-bold uppercase text-muted-foreground">Your Explanation</label>
                  <Textarea 
                    placeholder="Provide a detailed step-by-step resolution..."
                    className="min-h-[120px]"
                    value={doubt.id === resolvingId ? answer : ''}
                    onChange={e => {
                      setResolvingId(doubt.id);
                      setAnswer(e.target.value);
                    }}
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase text-emerald-600 flex items-center gap-1">
                    <CheckCircle className="h-3 w-3" /> Resolved Explanation
                  </label>
                  <p className="text-sm text-muted-foreground bg-emerald-50/30 p-4 rounded-xl">
                    {doubt.answer}
                  </p>
                </div>
              )}
            </CardContent>
            {doubt.status === 'pending' && (
              <CardFooter className="bg-muted/10 border-t pt-4">
                <Button 
                  className="ml-auto" 
                  disabled={resolvingId === doubt.id && !answer}
                  onClick={() => handleResolve(doubt.id)}
                >
                  {resolvingId === doubt.id ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Send className="h-4 w-4 mr-2" />}
                  Post Resolution
                </Button>
              </CardFooter>
            )}
          </Card>
        ))}
        {doubts.length === 0 && (
          <div className="py-20 text-center text-muted-foreground border-2 border-dashed rounded-xl">
            <Sparkles className="h-10 w-10 mx-auto mb-4 opacity-20" />
            <p>No doubt requests found. Students are on the right track!</p>
          </div>
        )}
      </div>
    </div>
  );
}
