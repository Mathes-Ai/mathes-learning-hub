
"use client";

import { useLanguage } from "@/context/LanguageContext";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  GraduationCap, 
  Upload, 
  Plus, 
  FileText, 
  Video, 
  Users, 
  BarChart3, 
  ChevronRight,
  Calendar,
  MessageCircle,
  Clock,
  BookOpen,
  TrendingUp,
  ArrowRight
} from "lucide-react";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useCollection, useFirestore, useUser, useMemoFirebase } from "@/firebase";
import { collection, query, where, orderBy, limit } from "firebase/firestore";
import { useMemo } from "react";
import Link from "next/link";

export default function TeacherPortal() {
  const { t, language } = useLanguage();
  const { user } = useUser();
  const db = useFirestore();

  // Stable Queries
  const myCoursesQuery = useMemoFirebase(() => 
    user ? query(collection(db, "courses"), where("teacherId", "==", user.uid)) : null, 
    [db, user]
  );
  
  const myLiveSessionsQuery = useMemoFirebase(() => 
    user ? query(collection(db, "live_sessions"), where("teacherId", "==", user.uid), orderBy("startTime", "asc"), limit(3)) : null, 
    [db, user]
  );

  const pendingDoubtsQuery = useMemoFirebase(() => 
    user ? query(collection(db, "doubts"), where("teacherId", "==", user.uid), where("status", "==", "pending"), limit(5)) : null, 
    [db, user]
  );

  const allStudentsQuery = useMemoFirebase(() => 
    query(collection(db, "users"), where("role", "==", "student")),
    [db]
  );

  const { data: courses } = useCollection(myCoursesQuery);
  const { data: liveSessions } = useCollection(myLiveSessionsQuery);
  const { data: doubts } = useCollection(pendingDoubtsQuery);
  const { data: allStudents } = useCollection(allStudentsQuery);

  const stats = [
    { label: "Your Courses", value: courses.length.toString(), icon: BookOpen, color: "text-blue-600", bg: "bg-blue-100" },
    { label: "Total Students", value: allStudents.length.toString(), icon: Users, color: "text-indigo-600", bg: "bg-indigo-100" },
    { label: "Pending Doubts", value: doubts.length.toString(), icon: MessageCircle, color: "text-orange-600", bg: "bg-orange-100" },
  ];

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-headline font-bold text-primary">Teacher Control Center</h1>
          <p className="text-muted-foreground text-lg">Excellence in guiding future engineers and scientists.</p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline" className="gap-2">
            <Link href="/dashboard/teacher/analytics"><BarChart3 className="h-4 w-4" /> Full Reports</Link>
          </Button>
          <Button asChild className="gap-2 shadow-lg shadow-primary/20">
            <Link href="/dashboard/teacher/live"><Plus className="h-4 w-4" /> Schedule Class</Link>
          </Button>
        </div>
      </header>

      <div className="grid md:grid-cols-3 gap-6">
        {stats.map((stat) => (
          <Card key={stat.label} className="border-none shadow-md">
            <CardContent className="p-6 flex items-center gap-4">
              <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${stat.bg}`}>
                <stat.icon className={`h-6 w-6 ${stat.color}`} />
              </div>
              <div>
                <h3 className="text-2xl font-bold">{stat.value}</h3>
                <p className="text-xs text-muted-foreground font-semibold uppercase">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="shadow-lg border-none">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Upcoming Live Sessions</CardTitle>
              <CardDescription>Scheduled virtual classrooms</CardDescription>
            </div>
            <Button asChild variant="ghost" size="sm"><Link href="/dashboard/teacher/live">View All</Link></Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {liveSessions.map((session) => (
              <div key={session.id} className="p-4 border rounded-xl hover:bg-muted/30 transition-colors flex items-center justify-between">
                <div className="flex gap-4">
                  <div className="bg-primary/10 text-primary p-2 rounded flex flex-col items-center justify-center min-w-[60px]">
                    <Clock className="h-4 w-4 mb-1" />
                    <span className="text-[10px] font-bold uppercase">LIVE</span>
                  </div>
                  <div>
                    <h4 className="font-bold">{session.title}</h4>
                    <p className="text-xs text-muted-foreground">
                      {new Date(session.startTime).toLocaleString()}
                    </p>
                  </div>
                </div>
                <Button size="sm" asChild variant="secondary">
                  <a href={session.meetingLink} target="_blank" rel="noopener noreferrer">Join</a>
                </Button>
              </div>
            ))}
            {liveSessions.length === 0 && (
              <div className="p-12 text-center text-muted-foreground border-2 border-dashed rounded-xl text-sm">
                No sessions scheduled.
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-lg border-none">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Doubt Requests</CardTitle>
              <CardDescription>Students waiting for clarification</CardDescription>
            </div>
            <Button asChild variant="ghost" size="sm"><Link href="/dashboard/teacher/doubts">Solve</Link></Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {doubts.map((doubt) => (
                <div key={doubt.id} className="p-4 bg-muted/30 rounded-lg space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-primary">{doubt.studentName || 'Student'}</span>
                    <Badge variant="outline" className="text-[10px]">PENDING</Badge>
                  </div>
                  <p className="text-sm line-clamp-2">{doubt.question}</p>
                </div>
              ))}
              {doubts.length === 0 && (
                <div className="p-12 text-center text-muted-foreground border-2 border-dashed rounded-xl text-sm">
                  Great job! No pending doubts.
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-headline font-bold">Quick Performance Check</h2>
          <Button asChild variant="link" className="gap-2 p-0 text-primary">
            <Link href="/dashboard/teacher/analytics">View Deep Analytics <ArrowRight className="h-4 w-4" /></Link>
          </Button>
        </div>
        <Card className="border-none shadow-md overflow-hidden">
          <CardContent className="p-0">
             <div className="grid md:grid-cols-2 divide-x divide-y md:divide-y-0">
                <div className="p-8 space-y-4">
                  <h4 className="font-bold text-sm uppercase text-muted-foreground">Engagement Rate</h4>
                  <div className="flex items-end gap-2">
                    <span className="text-5xl font-bold">92%</span>
                    <span className="text-emerald-500 font-bold text-sm pb-2">+4.5%</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Average student attendance across all your courses.</p>
                </div>
                <div className="p-8 space-y-4">
                  <h4 className="font-bold text-sm uppercase text-muted-foreground">Test Success Avg.</h4>
                  <div className="flex items-end gap-2">
                    <span className="text-5xl font-bold">78%</span>
                    <span className="text-amber-500 font-bold text-sm pb-2">-1.2%</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Median score across all your course mock tests.</p>
                </div>
             </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
