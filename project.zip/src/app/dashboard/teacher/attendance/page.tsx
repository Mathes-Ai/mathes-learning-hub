
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useUser } from "@/firebase";
import { collection, addDoc, query, where, serverTimestamp } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { UserCheck, Loader2, Save, Calendar as CalendarIcon } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { useToast } from "@/hooks/use-toast";

export default function AttendanceManager() {
  const db = useFirestore();
  const { user } = useUser();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState("");
  const [attendanceDate, setAttendanceDate] = useState(new Date().toISOString().split('T')[0]);
  const [presentStudents, setPresentStudents] = useState<string[]>([]);

  const studentsQuery = useMemo(() => query(collection(db, "users"), where("role", "==", "student")), [db]);
  const coursesQuery = useMemo(() => user ? query(collection(db, "courses"), where("teacherId", "==", user.uid)) : null, [db, user]);

  const { data: students } = useCollection(studentsQuery);
  const { data: courses } = useCollection(coursesQuery);

  const handleToggle = (studentId: string) => {
    setPresentStudents(prev => 
      prev.includes(studentId) ? prev.filter(id => id !== studentId) : [...prev, studentId]
    );
  };

  const handleSave = () => {
    if (!selectedCourse) {
      toast({ title: "Error", description: "Select a course first", variant: "destructive" });
      return;
    }

    setLoading(true);
    const batch = students.map(s => ({
      studentId: s.id,
      courseId: selectedCourse,
      date: attendanceDate,
      status: presentStudents.includes(s.id) ? 'present' : 'absent',
      createdAt: new Date().toISOString()
    }));

    const attendanceRef = collection(db, "attendance");
    
    Promise.all(batch.map(data => addDoc(attendanceRef, data)))
      .then(() => {
        toast({ title: "Success", description: "Attendance recorded successfully" });
        setLoading(false);
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: attendanceRef.path,
          operation: 'create',
        }));
      });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-emerald-100 p-3 rounded-xl text-emerald-600">
          <UserCheck className="h-6 w-6" />
        </div>
        <h1 className="text-3xl font-headline font-bold">Attendance Tracker</h1>
      </div>

      <div className="grid lg:grid-cols-4 gap-8">
        <Card className="lg:col-span-1 shadow-md h-fit">
          <CardHeader>
            <CardTitle>Session Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-bold">Course</label>
              <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                <SelectTrigger>
                  <SelectValue placeholder="Select course" />
                </SelectTrigger>
                <SelectContent>
                  {courses.map(c => <SelectItem key={c.id} value={c.id}>{c.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold">Date</label>
              <input 
                type="date" 
                className="w-full bg-background border rounded-md p-2"
                value={attendanceDate}
                onChange={e => setAttendanceDate(e.target.value)}
              />
            </div>
            <Button className="w-full mt-4" onClick={handleSave} disabled={loading || !selectedCourse}>
              {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Save className="h-4 w-4 mr-2" />}
              Save Attendance
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-3 shadow-md">
          <CardHeader>
            <CardTitle>Student Roster</CardTitle>
            <CardDescription>Mark students present for this session.</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">Present</TableHead>
                  <TableHead>Student Name</TableHead>
                  <TableHead>Email</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell>
                      <Checkbox 
                        checked={presentStudents.includes(s.id)} 
                        onCheckedChange={() => handleToggle(s.id)}
                      />
                    </TableCell>
                    <TableCell className="font-medium">{s.displayName || 'Unnamed Student'}</TableCell>
                    <TableCell className="text-muted-foreground">{s.email}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
