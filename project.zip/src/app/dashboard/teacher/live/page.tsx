
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useUser } from "@/firebase";
import { collection, addDoc, query, where, deleteDoc, doc, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Plus, Trash2, Loader2, Video, Link as LinkIcon } from "lucide-react";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

export default function ManageLiveClasses() {
  const db = useFirestore();
  const { user } = useUser();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const coursesQuery = useMemo(() => user ? query(collection(db, "courses"), where("teacherId", "==", user.uid)) : null, [db, user]);
  const liveSessionsQuery = useMemo(() => user ? query(collection(db, "live_sessions"), where("teacherId", "==", user.uid), orderBy("startTime", "desc")) : null, [db, user]);

  const { data: courses } = useCollection(coursesQuery);
  const { data: sessions } = useCollection(liveSessionsQuery);

  const [formData, setFormData] = useState({
    courseId: "",
    title: "",
    startTime: "",
    meetingLink: ""
  });

  const handleSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    const newSession = {
      ...formData,
      teacherId: user.uid,
      createdAt: new Date().toISOString(),
    };

    addDoc(collection(db, "live_sessions"), newSession)
      .then(() => {
        setFormData({ courseId: "", title: "", startTime: "", meetingLink: "" });
        setLoading(false);
        toast({ title: "Success", description: "Class scheduled successfully" });
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: "live_sessions",
          operation: 'create',
          requestResourceData: newSession,
        }));
      });
  };

  const handleDelete = (id: string) => {
    const docRef = doc(db, "live_sessions", id);
    deleteDoc(docRef).catch(async (err) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: docRef.path,
        operation: 'delete',
      }));
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-red-100 p-3 rounded-xl text-red-600">
          <Video className="h-6 w-6" />
        </div>
        <h1 className="text-3xl font-headline font-bold">Live Class Scheduler</h1>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 shadow-md h-fit">
          <CardHeader>
            <CardTitle>Schedule New Session</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSchedule} className="space-y-4">
              <div className="space-y-2">
                <Label>Class Title</Label>
                <Input 
                  required 
                  value={formData.title} 
                  onChange={e => setFormData({...formData, title: e.target.value})}
                  placeholder="e.g. Calculus Intensive Review"
                />
              </div>
              <div className="space-y-2">
                <Label>Select Course</Label>
                <Select value={formData.courseId} onValueChange={v => setFormData({...formData, courseId: v})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Course context" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map(c => <SelectItem key={c.id} value={c.id}>{c.title}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Start Time</Label>
                <Input 
                  required 
                  type="datetime-local"
                  value={formData.startTime} 
                  onChange={e => setFormData({...formData, startTime: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Meeting Link (Zoom/Google Meet)</Label>
                <div className="relative">
                  <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    required 
                    className="pl-9"
                    value={formData.meetingLink} 
                    onChange={e => setFormData({...formData, meetingLink: e.target.value})}
                    placeholder="https://zoom.us/j/..."
                  />
                </div>
              </div>
              <Button type="submit" className="w-full" disabled={loading || !formData.courseId}>
                {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                Schedule Session
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-headline font-bold">Upcoming Sessions</h2>
          <div className="grid gap-4">
            {sessions.map((s) => (
              <Card key={s.id} className="border-l-4 border-l-primary shadow-sm">
                <CardContent className="p-6 flex items-center justify-between">
                  <div className="flex gap-4">
                    <div className="h-12 w-12 rounded-xl bg-muted flex flex-col items-center justify-center">
                      <Calendar className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-bold">{s.title}</h3>
                      <p className="text-xs text-muted-foreground">
                        {new Date(s.startTime).toLocaleString()}
                      </p>
                      <Badge variant="outline" className="mt-2 text-[10px]">
                        {courses.find(c => c.id === s.courseId)?.title}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" asChild>
                      <a href={s.meetingLink} target="_blank" rel="noopener noreferrer">Test Link</a>
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(s.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            {sessions.length === 0 && (
              <div className="py-20 text-center text-muted-foreground border-2 border-dashed rounded-xl">
                No classes scheduled yet.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
