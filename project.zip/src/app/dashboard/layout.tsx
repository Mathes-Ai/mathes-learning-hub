"use client";

import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { useLanguage } from "@/context/LanguageContext";
import { Bell, Search, Globe, User, MessageSquare, LogOut, Settings, Loader2, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { signOut } from "firebase/auth";
import { useAuth, useUser, useFirestore, useCollection } from "@/firebase";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useMemo, useEffect, useState } from "react";
import { collection, query, orderBy, limit } from "firebase/firestore";
import { GlobalSearch } from "@/components/global-search";
import { FirebaseStatusBanner } from "@/components/FirebaseStatusBanner";
import { cn } from "@/lib/utils";
import { PwaInstallPrompt } from "@/components/pwa-install-prompt";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { t, language, setLanguage } = useLanguage();
  const auth = useAuth();
  const { user, loading: authLoading } = useUser();
  const db = useFirestore();
  const router = useRouter();

  const [showChat, setShowChat] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  // Authentication Guard
  useEffect(() => {
    if (!authLoading && !user) {
      router.replace('/');
    }
  }, [user, authLoading, router]);

  const notificationsQuery = useMemo(() => 
    query(collection(db, "announcements"), orderBy("createdAt", "desc"), limit(5)), 
    [db]
  );
  const { data: notifications } = useCollection(notificationsQuery);

  const unreadCount = notifications.length;

  const handleWhatsAppSupport = () => {
    const phoneNumber = "919876543210";
    const message = "Hi Mathes Learning Hub Support, I need assistance with my learning journey.";
    window.open(`https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`, "_blank");
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      router.push("/");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        const searchTrigger = document.querySelector('[data-state="closed"]')?.parentElement?.querySelector('div[role="button"]');
        if (searchTrigger instanceof HTMLElement) searchTrigger.click();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  if (authLoading) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center space-y-4 bg-background">
        <div className="bg-primary p-4 rounded-3xl animate-bounce shadow-2xl">
          <GraduationCap className="text-white h-12 w-12" />
        </div>
        <div className="flex items-center gap-2 text-primary font-headline font-bold">
          <Loader2 className="h-4 w-4 animate-spin" />
          Verifying Credentials...
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <SidebarProvider>
      <div className="flex h-screen w-full overflow-hidden bg-background">
        <AppSidebar />
        <main className="flex-1 flex flex-col min-w-0">
          <FirebaseStatusBanner />
          <header className="h-16 border-b bg-card flex items-center justify-between px-6 shrink-0 z-40">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <GlobalSearch />
            </div>
            
            <div className="flex items-center gap-3">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-muted-foreground"
                onClick={() => setLanguage(language === 'English' ? 'Tamil' : 'English')}
                title={language === 'English' ? 'Switch to Tamil' : 'ஆங்கிலத்திற்கு மாறவும்'}
              >
                <Globe className="h-5 w-5" />
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative text-muted-foreground">
                    <Bell className="h-5 w-5" />
                    {unreadCount > 0 && (
                      <span className="absolute top-2 right-2 h-4 w-4 bg-destructive text-[10px] text-white flex items-center justify-center rounded-full font-bold">
                        {unreadCount}
                      </span>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80">
                  <DropdownMenuLabel>Mathes Learning Hub Updates</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <div className="max-h-[300px] overflow-y-auto">
                    {notifications.map((n) => (
                      <DropdownMenuItem key={n.id} className="p-4 cursor-pointer" onClick={() => router.push('/dashboard/student')}>
                        <div className="space-y-1">
                          <p className="font-bold text-sm">{n.title}</p>
                          <p className="text-xs text-muted-foreground line-clamp-2">{n.content}</p>
                          <p className="text-[10px] font-bold text-primary uppercase">{new Date(n.createdAt).toLocaleDateString()}</p>
                        </div>
                      </DropdownMenuItem>
                    ))}
                    {notifications.length === 0 && (
                      <div className="p-8 text-center text-xs text-muted-foreground">
                        No recent hub notifications
                      </div>
                    )}
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild className="text-center justify-center cursor-pointer font-bold text-primary">
                    <Link href="/dashboard/student">View All Announcements</Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2 pl-2">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="h-4 w-4 text-primary" />
                    </div>
                    <div className="hidden sm:block text-left">
                      <div className="text-sm font-medium">{user?.displayName || 'Mathes Learning Hub User'}</div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Account</div>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>{t('profile')}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild className="cursor-pointer">
                    <Link href="/dashboard/settings" className="flex items-center gap-2 w-full">
                      <Settings className="h-4 w-4" />
                      {t('settings')}
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="text-destructive font-medium cursor-pointer flex items-center gap-2"
                    onClick={handleLogout}
                  >
                    <LogOut className="h-4 w-4" />
                    {t('logout')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </header>
          
          <div 
            className="flex-1 overflow-y-auto p-6 md:p-8 relative scroll-smooth"
            onScroll={(e) => {
              const currentScrollY = e.currentTarget.scrollTop;
              if (currentScrollY > lastScrollY && currentScrollY > 100) {
                setShowChat(false);
              } else {
                setShowChat(true);
              }
              setLastScrollY(currentScrollY);
            }}
          >
            <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 pb-32">
              {children}
            </div>

            <PwaInstallPrompt />

            <Button
              onClick={handleWhatsAppSupport}
              className={cn(
                "fixed bottom-6 right-6 h-14 w-14 rounded-full bg-emerald-500 hover:bg-emerald-600 shadow-2xl z-50 p-0 transition-all duration-300",
                showChat ? "translate-y-0 opacity-100 scale-100" : "translate-y-20 opacity-0 scale-50 pointer-events-none"
              )}
              title="WhatsApp Support"
            >
              <MessageSquare className="h-7 w-7 text-white" />
            </Button>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
