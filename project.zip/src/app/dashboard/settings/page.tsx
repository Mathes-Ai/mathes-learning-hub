"use client";

import { useLanguage } from "@/context/LanguageContext";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Globe, Bell, Shield, Palette, User, ChevronRight } from "lucide-react";
import { useUser, useFirestore, useDoc } from "@/firebase";
import { useMemo } from "react";
import { doc } from "firebase/firestore";
import Link from "next/link";

export default function SettingsPage() {
  const { t, language, setLanguage } = useLanguage();
  const { user } = useUser();
  const db = useFirestore();

  const profileRef = useMemo(() => user ? doc(db, "users", user.uid) : null, [db, user]);
  const { data: profile } = useDoc(profileRef);

  const settingSections = [
    {
      title: "Preferences",
      icon: Palette,
      items: [
        {
          id: "language",
          label: t('language'),
          desc: language === 'English' ? 'Current: English' : 'தற்போதைய: தமிழ்',
          action: (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setLanguage(language === 'English' ? 'Tamil' : 'English')}
            >
              <Globe className="h-4 w-4 mr-2" />
              {language === 'English' ? 'Switch to Tamil' : 'ஆங்கிலத்திற்கு மாறவும்'}
            </Button>
          )
        },
        {
          id: "notifications",
          label: "Push Notifications",
          desc: "Receive hub updates in browser",
          action: <Switch defaultChecked />
        }
      ]
    },
    {
      title: "Account",
      icon: User,
      items: [
        {
          id: "profile-edit",
          label: "Edit Profile",
          desc: "Update your name, phone and address",
          action: (
            <Button variant="ghost" size="icon" asChild>
              <Link href="/dashboard/student/profile">
                <ChevronRight className="h-5 w-5" />
              </Link>
            </Button>
          )
        },
        {
          id: "security",
          label: "Password & Security",
          desc: "Manage your login credentials",
          action: (
            <Button variant="ghost" size="icon">
              <ChevronRight className="h-5 w-5" />
            </Button>
          )
        }
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-headline font-bold text-primary">{t('settings')}</h1>
        <p className="text-muted-foreground">Manage your preferences and account settings.</p>
      </div>

      <div className="grid gap-6">
        <Card className="border-none shadow-md overflow-hidden bg-primary text-primary-foreground">
          <CardContent className="p-8 flex items-center gap-6">
            <div className="h-20 w-20 rounded-2xl bg-white/20 flex items-center justify-center">
              <User className="h-10 w-10" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">{profile?.displayName || user?.email?.split('@')[0] || 'User'}</h2>
              <p className="text-primary-foreground/80">{profile?.role?.toUpperCase() || 'STUDENT'} • {user?.email}</p>
            </div>
          </CardContent>
        </Card>

        {settingSections.map((section) => (
          <Card key={section.title} className="border-none shadow-sm ring-1 ring-border">
            <CardHeader className="border-b bg-muted/30">
              <div className="flex items-center gap-2">
                <section.icon className="h-5 w-5 text-primary" />
                <CardTitle className="text-lg">{section.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {section.items.map((item) => (
                  <div key={item.id} className="p-6 flex items-center justify-between">
                    <div className="space-y-1">
                      <Label className="text-base font-bold">{item.label}</Label>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                    <div>{item.action}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}

        <Card className="border-none shadow-sm ring-1 ring-border bg-destructive/5">
          <CardContent className="p-6 flex items-center justify-between">
            <div className="space-y-1">
              <Label className="text-base font-bold text-destructive">Privacy & Data</Label>
              <p className="text-sm text-muted-foreground">Export or delete your learning data</p>
            </div>
            <Button variant="destructive" size="sm">Request Data</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
