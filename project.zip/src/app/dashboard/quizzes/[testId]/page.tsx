
"use client";

import { useState, useMemo, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { useFirestore, useDoc, useUser, useMemoFirebase } from "@/firebase";
import { doc, addDoc, collection, query, where, getDocs, setDoc, deleteDoc } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Timer, Trophy, AlertTriangle, ChevronRight, ChevronLeft, Loader2, ShieldAlert, CheckCircle2, XCircle, Bookmark, BookmarkCheck } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const shuffleArray = <T,>(array: T[]): T[] => {
  const newArr = [...array];
  for (let i = newArr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArr[i], newArr[j]] = [newArr[j], newArr[i]];
  }
  return newArr;
};

export default function TakeTest() {
  const params = useParams();
  const testId = params.testId as string;
  const router = useRouter();
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();

  const testRef = useMemoFirebase(() => doc(db, "tests", testId), [db, testId]);
  const { data: test, loading } = useDoc(testRef);

  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [startTime] = useState(() => Date.now());
  const [isFinished, setIsFinished] = useState(false);
  const [saving, setSaving] = useState(false);
  const [results, setResults] = useState<{
    correct: number;
    wrong: number;
    negativeMarks: number;
    finalScore: number;
    rank: number;
    totalParticipants: number;
  } | null>(null);

  const [shuffledQuestions, setShuffledQuestions] = useState<any[]>([]);
  const [bookmarks, setBookmarks] = useState<string[]>([]);

  useEffect(() => {
    if (test && test.questions?.length >= 10) {
      const randomized = test.questions.map((q: any) => ({
        ...q,
        options: shuffleArray(q.options || [])
      }));
      setShuffledQuestions(shuffleArray(randomized));
      
      if (test.duration && timeLeft === null) {
        setTimeLeft(test.duration * 60);
      }
    }
  }, [test]);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, "users", user.uid, "bookmarks"), where("testId", "==", testId));
    getDocs(q).then(snap => {
      setBookmarks(snap.docs.map(d => d.data().questionId));
    });
  }, [user, testId, db]);

  useEffect(() => {
    if (timeLeft === null || isFinished) return;
    if (timeLeft <= 0) {
      handleSubmit();
      return;
    }
    const timer = setInterval(() => {
      setTimeLeft(prev => (prev !== null ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft, isFinished]);

  const toggleBookmark = (q: any) => {
    if (!user) return;
    const isBookmarked = bookmarks.includes(q.id);
    const bRef = doc(db, "users", user.uid, "bookmarks", q.id);

    if (isBookmarked) {
      deleteDoc(bRef).then(() => {
        setBookmarks(prev => prev.filter(id => id !== q.id));
        toast({ title: "Bookmark Removed" });
      });
    } else {
      const bookmarkData = {
        questionId: q.id,
        testId: testId,
        testTitle: test?.title,
        questionText: q.questionText,
        options: q.options,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation,
        savedAt: new Date().toISOString()
      };
      setDoc(bRef, bookmarkData).then(() => {
        setBookmarks(prev => [...prev, q.id]);
        toast({ title: "Question Bookmarked", description: "Saved for revision." });
      });
    }
  };

  const handleSubmit = async () => {
    if (!test || !user || isFinished || saving) return;
    setSaving(true);
    setIsFinished(true);

    let correct = 0;
    let wrong = 0;
    const failedQuestions: any[] = [];

    shuffledQuestions.forEach((q: any) => {
      const studentAnswer = answers[q.id];
      if (studentAnswer !== undefined) {
        if (studentAnswer === q.correctAnswer) {
          correct++;
        } else {
          wrong++;
          failedQuestions.push({
            ...q,
            studentAnswer,
            testTitle: test.title,
            timestamp: new Date().toISOString(),
            category: test.topic || "General"
          });
        }
      }
    });

    failedQuestions.forEach((m) => {
      const mRef = doc(db, "users", user.uid, "mistakes", m.id);
      setDoc(mRef, m, { merge: true });
    });

    const negativeMarkValue = test.negativeMarking ? (test.negativeMarkValue || 0.25) : 0;
    const negativeMarks = wrong * negativeMarkValue;
    const finalScore = correct - negativeMarks;

    try {
      const q = query(collection(db, "test_attempts"), where("testId", "==", testId));
      const snap = await getDocs(q);
      const allScores = snap.docs.map(d => d.data().finalScore);
      allScores.push(finalScore);
      const rank = allScores.sort((a, b) => b - a).indexOf(finalScore) + 1;

      setResults({ correct, wrong, negativeMarks, finalScore, rank, totalParticipants: allScores.length });

      const attempt = {
        studentId: user.uid,
        studentName: user.displayName || user.email?.split('@')[0],
        testId,
        testTitle: test.title,
        courseId: test.courseId,
        correctCount: correct,
        wrongCount: wrong,
        negativeMarks,
        finalScore,
        totalQuestions: shuffledQuestions.length,
        answers,
        timeTaken: Math.floor((Date.now() - startTime) / 1000),
        completedAt: new Date().toISOString()
      };

      addDoc(collection(db, "test_attempts"), attempt);
    } catch (e) {
      toast({ variant: "destructive", title: "Sync Error", description: "Score logged locally but sync failed." });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center space-y-4">
        <Loader2 className="animate-spin h-10 w-10 text-primary" />
        <p className="text-muted-foreground font-bold uppercase text-[10px]">Loading Exam Portal...</p>
      </div>
    );
  }

  if (!test || !test.questions || test.questions.length < 10) {
    return (
      <Card className="max-w-lg mx-auto mt-20 border-amber-200 bg-amber-50 rounded-2xl p-8 text-center shadow-xl">
        <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
        <CardTitle className="text-amber-900">Verification Needed</CardTitle>
        <p className="text-amber-800 text-sm mt-2">This assessment requires verified academic content before starting.</p>
        <Button onClick={() => router.push('/dashboard/quizzes')} variant="outline" className="mt-6 w-full rounded-xl font-bold">Return to Hub</Button>
      </Card>
    );
  }

  if (isFinished && results) {
    return (
      <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-700 pb-20">
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="md:col-span-1 border-none shadow-2xl bg-primary text-primary-foreground overflow-hidden rounded-[2rem]">
            <CardHeader className="text-center py-10">
              <Trophy className="h-12 w-12 text-white mx-auto mb-4" />
              <CardTitle className="text-2xl font-headline font-bold">Final Score</CardTitle>
              <div className="text-6xl font-bold tracking-tighter my-4">{results.finalScore.toFixed(2)}</div>
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-70">Global Rank: #{results.rank} / {results.totalParticipants}</p>
            </CardHeader>
            <CardFooter className="bg-black/10 p-6 flex flex-col gap-2">
               <Button className="w-full bg-white text-primary hover:bg-white/90 font-bold rounded-xl h-11" onClick={() => router.push('/dashboard/student/analytics')}>Full Analytics</Button>
               <Button variant="ghost" className="w-full text-white font-bold h-11" onClick={() => router.push('/dashboard/quizzes')}>Exit Hub</Button>
            </CardFooter>
          </Card>

          <Card className="md:col-span-2 border-none shadow-xl ring-1 ring-border rounded-[2rem] p-8 space-y-6">
              <h3 className="font-headline font-bold text-xl border-b pb-4">Performance Insights</h3>
              <div className="grid grid-cols-3 gap-3">
                <div className="p-4 bg-emerald-50 rounded-xl text-center border border-emerald-100">
                   <p className="text-[9px] font-bold text-emerald-600 uppercase mb-1">Correct</p>
                   <p className="text-2xl font-bold text-emerald-700">{results.correct}</p>
                </div>
                <div className="p-4 bg-red-50 rounded-xl text-center border border-red-100">
                   <p className="text-[9px] font-bold text-red-600 uppercase mb-1">Incorrect</p>
                   <p className="text-2xl font-bold text-red-700">{results.wrong}</p>
                </div>
                <div className="p-4 bg-amber-50 rounded-xl text-center border border-amber-100">
                   <p className="text-[9px] font-bold text-amber-600 uppercase mb-1">Penalty</p>
                   <p className="text-2xl font-bold text-amber-700">-{results.negativeMarks.toFixed(2)}</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-end">
                   <span className="text-[10px] font-bold uppercase text-muted-foreground tracking-widest">Accuracy Status</span>
                   <span className="text-lg font-bold text-primary">{Math.round((results.correct / (results.correct + results.wrong || 1)) * 100)}%</span>
                </div>
                <Progress value={(results.correct / (results.correct + results.wrong || 1)) * 100} className="h-2 rounded-full" />
              </div>
              <div className="bg-orange-50 p-4 rounded-xl flex gap-3 border border-orange-100">
                 <XCircle className="h-5 w-5 text-orange-600 shrink-0 mt-0.5" />
                 <p className="text-[11px] text-orange-800 leading-relaxed">
                   Incorrect answers are now in your **Mistake Book**. Revise them in **Revision Mode** to ensure these concepts are mastered before the next trial.
                 </p>
              </div>
          </Card>
        </div>

        <section className="space-y-6 pt-6">
          <h2 className="text-2xl font-headline font-bold flex items-center gap-3">
            <CheckCircle2 className="h-7 w-7 text-primary" />
            Review Session
          </h2>
          <div className="grid gap-4">
            {shuffledQuestions.map((q, i) => {
              const studentAns = answers[q.id];
              const isCorrect = studentAns === q.correctAnswer;
              return (
                <Card key={q.id} className="border-none shadow-sm ring-1 ring-border rounded-2xl overflow-hidden bg-white">
                  <CardHeader className={`p-5 border-b ${isCorrect ? 'bg-emerald-50/30' : studentAns ? 'bg-red-50/30' : 'bg-muted/10'}`}>
                    <div className="flex justify-between items-start gap-4">
                      <div className="flex items-start gap-3">
                        <span className="text-[10px] font-bold h-6 w-6 rounded bg-white flex items-center justify-center border shadow-sm shrink-0">{i + 1}</span>
                        <p className="font-bold text-base text-slate-800 leading-snug">{q.questionText}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <div className="grid sm:grid-cols-2 gap-3">
                       {q.options.map((opt: string) => (
                         <div 
                          key={opt} 
                          className={`p-3.5 rounded-xl text-xs font-medium border-2 flex items-center gap-2 ${
                            opt === q.correctAnswer 
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                              : opt === studentAns 
                                ? 'bg-red-50 border-red-200 text-red-800' 
                                : 'bg-muted/5 border-transparent text-muted-foreground'
                          }`}
                         >
                           {opt === q.correctAnswer ? <CheckCircle2 className="h-3.5 w-3.5 shrink-0" /> : opt === studentAns ? <XCircle className="h-3.5 w-3.5 shrink-0" /> : <div className="h-3.5 w-3.5" />}
                           {opt}
                         </div>
                       ))}
                    </div>
                    <div className="pt-4 border-t bg-primary/5 -mx-6 -mb-6 p-6">
                       <p className="text-[9px] font-bold text-primary uppercase tracking-widest mb-1.5">Expert Explanation</p>
                       <p className="text-xs text-slate-700 leading-relaxed italic border-l-2 border-primary/20 pl-3">{q.explanation}</p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>
      </div>
    );
  }

  const currentQ = shuffledQuestions[currentIdx];
  if (!currentQ) return null;

  return (
    <div className="max-w-4xl mx-auto pb-32">
      <header className="sticky top-0 -mx-6 md:-mx-8 mb-6 z-50 bg-white/95 backdrop-blur-md border-b shadow-md px-4 py-3">
        <div className="flex items-center justify-between max-w-4xl mx-auto gap-4">
          <div className="flex items-center gap-3 min-w-0">
             <div className="bg-primary h-9 w-9 rounded-lg flex items-center justify-center text-white shrink-0 shadow-lg shadow-primary/20">
               <Trophy className="h-4.5 w-4.5" />
             </div>
             <div className="min-w-0">
               <h1 className="font-bold text-xs md:text-sm truncate">{test.title}</h1>
               <div className="flex items-center gap-2 mt-0.5">
                 <span className="text-[9px] text-muted-foreground font-bold flex items-center gap-1.5">
                   <Timer className="h-3 w-3" />
                   {timeLeft !== null ? `${Math.floor(timeLeft / 60)}:${(timeLeft % 60).toString().padStart(2, '0')}` : "--:--"}
                 </span>
               </div>
             </div>
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm" className="h-8 px-4 text-[10px] font-bold rounded-lg shadow-md transition-transform active:scale-95">END EXAM</Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="rounded-2xl max-w-sm">
              <AlertDialogHeader>
                <AlertDialogTitle>End Proctored Session?</AlertDialogTitle>
                <AlertDialogDescription className="text-xs">Your current progress will be scored. Mistakes are automatically logged to your library.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter className="gap-2">
                <AlertDialogCancel className="rounded-xl font-bold h-10 text-[10px]">CONTINUE</AlertDialogCancel>
                <AlertDialogAction onClick={handleSubmit} className="bg-destructive hover:bg-destructive/90 rounded-xl font-bold h-10 text-[10px]">SUBMIT & EXIT</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
        <Progress value={((currentIdx + 1) / shuffledQuestions.length) * 100} className="h-1 absolute bottom-0 left-0 right-0 rounded-none bg-transparent [&>div]:bg-primary" />
      </header>

      <div className="grid lg:grid-cols-4 gap-6 px-1">
        <div className="lg:col-span-3">
          <Card className="border-none shadow-2xl ring-1 ring-border flex flex-col overflow-hidden rounded-[1.5rem] md:rounded-[2rem] bg-white">
            <CardHeader className="bg-muted/5 border-b p-6 md:p-10">
              <div className="flex justify-between items-center mb-6 md:mb-8">
                <Badge variant="secondary" className="text-[8px] font-bold uppercase bg-primary/10 text-primary tracking-widest border-none">
                  QUESTION {currentIdx + 1} OF {shuffledQuestions.length}
                </Badge>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className={`h-8 w-8 rounded-full ${bookmarks.includes(currentQ.id) ? "text-accent bg-accent/5" : "text-muted-foreground"}`} 
                  onClick={() => toggleBookmark(currentQ)}
                >
                  {bookmarks.includes(currentQ.id) ? <BookmarkCheck className="h-4.5 w-4.5" /> : <Bookmark className="h-4.5 w-4.5" />}
                </Button>
              </div>
              <CardTitle className="text-xl md:text-2xl leading-snug font-headline font-bold text-slate-900">{currentQ.questionText}</CardTitle>
            </CardHeader>
            
            <CardContent className="flex-1 p-6 md:p-10">
              <RadioGroup 
                value={answers[currentQ.id]} 
                onValueChange={(v) => setAnswers({...answers, [currentQ.id]: v})}
                className="space-y-3"
              >
                {currentQ.options?.map((opt: string, i: number) => (
                  <div 
                    key={i} 
                    className={`flex items-center space-x-3 p-4 md:p-5 rounded-xl md:rounded-2xl border-2 transition-all cursor-pointer group active:scale-[0.99] ${answers[currentQ.id] === opt ? 'bg-primary/5 border-primary shadow-lg ring-1 ring-primary/10' : 'hover:bg-slate-50 border-slate-100 bg-slate-50/30'}`}
                    onClick={() => setAnswers({...answers, [currentQ.id]: opt})}
                  >
                    <RadioGroupItem value={opt} id={`q-${i}`} className="shrink-0 scale-110 md:scale-125" />
                    <Label htmlFor={`q-${i}`} className="text-sm md:text-base font-medium cursor-pointer flex-1 leading-tight text-slate-800">{opt}</Label>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>

            <CardFooter className="flex justify-between border-t bg-slate-50/50 p-6 md:p-8">
              <Button variant="ghost" className="rounded-full px-6 h-11 md:h-12 font-bold text-slate-600" onClick={() => setCurrentIdx(prev => Math.max(0, prev - 1))} disabled={currentIdx === 0}>
                <ChevronLeft className="mr-1.5 h-4 w-4" /> PREV
              </Button>
              
              {currentIdx === shuffledQuestions.length - 1 ? (
                <Button onClick={handleSubmit} className="px-8 h-11 md:h-12 bg-emerald-600 hover:bg-emerald-700 rounded-full font-bold shadow-lg text-white" disabled={saving}>
                  {saving ? <Loader2 className="animate-spin h-4 w-4" /> : 'SUBMIT EXAM'}
                </Button>
              ) : (
                <Button onClick={() => setCurrentIdx(prev => prev + 1)} className="rounded-full px-8 h-11 md:h-12 font-bold shadow-lg bg-primary text-white hover:bg-primary/90">
                  NEXT <ChevronRight className="ml-1.5 h-4 w-4" />
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>

        <div className="hidden lg:block space-y-6">
          <Card className="border-none shadow-xl ring-1 ring-border rounded-2xl overflow-hidden bg-white">
            <CardHeader className="bg-slate-50 border-b p-5">
              <CardTitle className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Assessment Matrix</CardTitle>
            </CardHeader>
            <CardContent className="p-5 grid grid-cols-5 gap-2">
              {shuffledQuestions.map((q: any, i: number) => (
                <button
                  key={i}
                  onClick={() => setCurrentIdx(i)}
                  className={`h-9 rounded-lg text-[10px] font-bold border-2 transition-all ${
                    i === currentIdx 
                      ? 'bg-primary border-primary text-white shadow-md' 
                      : answers[q.id] !== undefined 
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-700' 
                        : 'bg-white border-slate-200 text-slate-400'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
            </CardContent>
          </Card>
          
          <div className="bg-amber-50/60 border border-amber-200 p-6 rounded-2xl space-y-2">
             <div className="flex items-center gap-2 text-amber-700">
               <ShieldAlert className="h-4 w-4" />
               <p className="text-[10px] font-bold uppercase tracking-widest">Academic Integrity</p>
             </div>
             <p className="text-[10px] text-amber-800 leading-relaxed font-medium">
               This session is monitored. Switching tabs or browser focus may invalidate your results.
             </p>
          </div>
        </div>
      </div>
    </div>
  );
}
