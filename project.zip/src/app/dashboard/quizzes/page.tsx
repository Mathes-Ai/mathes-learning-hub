"use client";

import { useMemo } from "react";
import { useLanguage } from "@/context/LanguageContext";
import { useFirestore, useCollection, useMemoFirebase, useUser } from "@/firebase";
import { collection, query, orderBy, where, limit } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ClipboardList, Timer, HelpCircle, CheckCircle2, Trophy, Loader2, Sparkles, TrendingUp, Search } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import Link from "next/link";

export default function QuizCenter() {
  const { t, language } = useLanguage();
  const { user } = useUser();
  const db = useFirestore();

  const testsRef = useMemoFirebase(() => collection(db, "tests"), [db]);
  const testsQuery = useMemoFirebase(() => query(testsRef, orderBy("createdAt", "desc")), [testsRef]);
  
  const attemptsQuery = useMemoFirebase(() => 
    user ? query(collection(db, "test_attempts"), where("studentId", "==", user.uid), orderBy("completedAt", "desc"), limit(5)) : null,
    [db, user]
  );

  const { data: tests, loading } = useCollection(testsQuery);
  const { data: recentResults, loading: loadingResults } = useCollection(attemptsQuery);

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-4xl font-headline font-bold text-primary flex items-center gap-3">
            <ClipboardList className="h-10 w-10 text-accent" />
            Interactive Quiz Hub
          </h1>
          <p className="text-muted-foreground text-lg">Test your knowledge with real-time proctored mock assessments.</p>
        </div>
        <div className="flex items-center gap-2 bg-primary/5 p-4 rounded-2xl border border-primary/10">
          <Trophy className="h-6 w-6 text-yellow-500" />
          <div>
            <p className="text-[10px] font-bold uppercase text-muted-foreground">Total Quizzes</p>
            <p className="text-lg font-bold">{tests.length}</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-headline font-bold flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-accent" />
              Active Assessments
            </h2>
          </div>
          
          <div className="grid gap-4">
            {tests.map((test) => (
              <Link key={test.id} href={`/dashboard/quizzes/${test.id}`} className="block group no-underline">
                <Card className="group hover:shadow-xl transition-all duration-300 border-none ring-1 ring-border bg-card overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
                      <div className="flex items-center gap-5">
                        <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                          <HelpCircle className="h-7 w-7" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                             <h3 className="font-bold text-xl group-hover:text-primary transition-colors">{test.title}</h3>
                             <Badge variant="secondary" className="text-[8px] h-4 uppercase">{test.difficulty}</Badge>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground font-medium">
                            <span className="flex items-center gap-1.5"><Timer className="h-3.5 w-3.5" /> {test.duration} mins</span>
                            <span className="flex items-center gap-1.5"><ClipboardList className="h-3.5 w-3.5" /> {test.questions?.length || 0} Questions</span>
                          </div>
                        </div>
                      </div>
                      {/* Styled div instead of button to avoid nested interactive elements and fix mobile double-tap */}
                      <div className="h-11 px-8 flex items-center justify-center bg-primary text-white text-sm font-bold rounded-full shadow-lg shadow-primary/20 transition-transform group-active:scale-95">
                         Begin Quiz
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
            
            {!loading && tests.length === 0 && (
              <div className="py-24 text-center text-muted-foreground border-2 border-dashed rounded-3xl bg-muted/20 space-y-4">
                <p className="text-xl font-bold">No assessments available</p>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <h2 className="text-xl font-headline font-bold flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Recent Results
          </h2>
          <div className="space-y-4">
            {recentResults.map((result) => {
              const score = Math.round((result.finalScore / result.totalQuestions) * 100);
              return (
                <Card key={result.id} className="border-none shadow-sm ring-1 ring-border">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="min-w-0">
                        <h4 className="font-bold text-sm truncate">{result.testTitle}</h4>
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">{new Date(result.completedAt).toLocaleDateString()}</p>
                      </div>
                      <Badge className={score >= 70 ? "bg-emerald-500" : "bg-primary"}>{score}%</Badge>
                    </div>
                    <div className="space-y-1.5">
                      <Progress value={score} className="h-1.5" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
