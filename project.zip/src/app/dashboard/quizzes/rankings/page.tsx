
"use client";

import { useMemo, useState } from "react";
import { useFirestore, useCollection } from "@/firebase";
import { collection, query, orderBy, limit, where } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Star, Target, Search, Calendar, Filter, Zap, TrendingUp } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";

export default function RankList() {
  const db = useFirestore();
  const [testFilter, setTestFilter] = useState("all");
  const [timeFilter, setTimeFilter] = useState("all");
  const [search, setSearch] = useState("");

  const testsQuery = useMemo(() => collection(db, "tests"), [db]);
  const attemptsQuery = useMemo(() => 
    query(collection(db, "test_attempts"), orderBy("finalScore", "desc")), 
    [db]
  );

  const { data: tests } = useCollection(testsQuery);
  const { data: attempts } = useCollection(attemptsQuery);

  const filteredRankings = useMemo(() => {
    const now = new Date();
    return attempts.filter(a => {
      const matchesTest = testFilter === "all" || a.testId === testFilter;
      const matchesSearch = a.studentName?.toLowerCase().includes(search.toLowerCase());
      
      let matchesTime = true;
      const completedDate = new Date(a.completedAt);
      if (timeFilter === "weekly") {
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        matchesTime = completedDate >= weekAgo;
      } else if (timeFilter === "monthly") {
        const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        matchesTime = completedDate >= monthAgo;
      }

      return matchesTest && matchesSearch && matchesTime;
    });
  }, [attempts, testFilter, timeFilter, search]);

  // Points Aggregation (Global Leaderboard)
  const globalLeaderboard = useMemo(() => {
    const studentStats: Record<string, { id: string, name: string, points: number, tests: number }> = {};
    
    attempts.forEach(a => {
      if (!studentStats[a.studentId]) {
        studentStats[a.studentId] = { id: a.studentId, name: a.studentName, points: 0, tests: 0 };
      }
      studentStats[a.studentId].points += Math.max(0, a.finalScore);
      studentStats[a.studentId].tests += 1;
    });

    return Object.values(studentStats).sort((a, b) => b.points - a.points).slice(0, 50);
  }, [attempts]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-3 rounded-xl">
            <Trophy className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold text-primary">Hall of Fame</h1>
            <p className="text-muted-foreground">Recognizing excellence across the Mathes Learning Hub.</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-4">
          <Card className="border-none shadow-md ring-1 ring-border">
            <CardHeader>
              <CardTitle className="text-sm">Leaderboard Filters</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase text-muted-foreground">Time Horizon</label>
                <Select value={timeFilter} onValueChange={setTimeFilter}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Time</SelectItem>
                    <SelectItem value="weekly">This Week</SelectItem>
                    <SelectItem value="monthly">This Month</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase text-muted-foreground">By Assessment</label>
                <Select value={testFilter} onValueChange={setTestFilter}>
                  <SelectTrigger><SelectValue placeholder="All Tests" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Tests</SelectItem>
                    {tests.map(t => <SelectItem key={t.id} value={t.id}>{t.title}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase text-muted-foreground">Search Student</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    className="pl-9 h-9 text-xs" 
                    placeholder="Filter by name..." 
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-primary text-primary-foreground border-none shadow-lg">
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                <h3 className="font-bold">Points System</h3>
              </div>
              <p className="text-[11px] text-primary-foreground/70 leading-relaxed">
                Earn points for every correct answer. Top 10% receive the "Elite Scholar" badge.
              </p>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-[10px] font-bold bg-white/10 p-2 rounded">
                  <Star className="h-3 w-3 text-yellow-400" /> Elite Scholar
                </div>
                <div className="flex items-center gap-2 text-[10px] font-bold bg-white/10 p-2 rounded">
                  <TrendingUp className="h-3 w-3 text-emerald-400" /> Rising Star
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3 space-y-6">
          <Tabs defaultValue="attempts">
            <TabsList className="grid w-full grid-cols-2 mb-6 h-12">
              <TabsTrigger value="attempts" className="text-sm font-bold">Recent Test Rankings</TabsTrigger>
              <TabsTrigger value="global" className="text-sm font-bold">Global Points Table</TabsTrigger>
            </TabsList>
            
            <TabsContent value="attempts">
              <Card className="shadow-xl border-none ring-1 ring-border">
                <CardHeader>
                  <CardTitle>Recent Standings</CardTitle>
                  <CardDescription>Displaying {filteredRankings.length} qualifying results</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[80px]">Rank</TableHead>
                        <TableHead>Student</TableHead>
                        <TableHead>Assessment</TableHead>
                        <TableHead className="text-right">Score</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredRankings.slice(0, 50).map((a, index) => (
                        <TableRow key={a.id} className={index < 3 ? 'bg-primary/5 font-medium' : ''}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {index === 0 && <Medal className="h-4 w-4 text-amber-500" />}
                              {index === 1 && <Medal className="h-4 w-4 text-slate-400" />}
                              {index === 2 && <Medal className="h-4 w-4 text-orange-400" />}
                              <span className={index <= 2 ? 'font-bold' : 'text-muted-foreground ml-6'}>#{index + 1}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="font-bold text-sm">{a.studentName}</div>
                            <div className="text-[10px] text-muted-foreground uppercase">{new Date(a.completedAt).toLocaleDateString()}</div>
                          </TableCell>
                          <TableCell className="text-xs">{a.testTitle}</TableCell>
                          <TableCell className="text-right font-mono font-bold text-primary">
                            {a.finalScore.toFixed(2)}
                          </TableCell>
                        </TableRow>
                      ))}
                      {filteredRankings.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center py-20 text-muted-foreground">
                            No rankings found for selected criteria.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="global">
              <Card className="shadow-xl border-none ring-1 ring-border">
                <CardHeader>
                  <CardTitle>Global Mastery Table</CardTitle>
                  <CardDescription>Aggregate points from all attempted tests.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[80px]">Rank</TableHead>
                        <TableHead>Student</TableHead>
                        <TableHead className="text-center">Tests Taken</TableHead>
                        <TableHead className="text-right">Total Hub Points</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {globalLeaderboard.map((s, index) => (
                        <TableRow key={s.id} className={index < 3 ? 'bg-emerald-50/30' : ''}>
                          <TableCell className="font-bold">#{index + 1}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm">{s.name}</span>
                              {index < 5 && <Badge className="bg-yellow-100 text-yellow-700 hover:bg-yellow-100 text-[8px] h-4">Elite</Badge>}
                              {s.tests > 10 && <Badge variant="outline" className="text-[8px] h-4">Consistent</Badge>}
                            </div>
                          </TableCell>
                          <TableCell className="text-center text-sm">{s.tests}</TableCell>
                          <TableCell className="text-right">
                             <div className="flex flex-col items-end">
                               <span className="font-bold text-emerald-600 text-lg">{Math.round(s.points)}</span>
                               <span className="text-[10px] text-muted-foreground uppercase font-bold">Points</span>
                             </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
