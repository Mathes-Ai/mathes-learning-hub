"use client";

import { useState, useEffect, useMemo } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { explainConcept } from '@/ai/flows/explain-concept-flow';
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Sparkles, Loader2, BrainCircuit, Lightbulb, MessageSquare, ShieldCheck, ShieldAlert, CheckCircle2, Key, Terminal, Info } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { checkAiConfig } from '@/app/actions/ai-check';
import { useUser, useFirestore, useDoc } from '@/firebase';
import { doc } from 'firebase/firestore';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

export default function AiTutorPage() {
  const { t, language } = useLanguage();
  const { user } = useUser();
  const db = useFirestore();
  const [question, setQuestion] = useState('');
  const [explanation, setExplanation] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  
  // Role check for diagnostics
  const profileRef = useMemo(() => user ? doc(db, "users", user.uid) : null, [db, user]);
  const { data: profile } = useDoc(profileRef);
  const isAdmin = profile?.role === 'admin';

  // Diagnostic state
  const [aiStatus, setAiStatus] = useState<{ success: boolean; message?: string; error?: string; maskedKey?: string } | null>(null);
  const [checkingStatus, setCheckingStatus] = useState(false);

  const handleExplain = async () => {
    if (!question.trim()) return;
    setLoading(true);
    setExplanation(null);
    try {
      const result = await explainConcept({ 
        question, 
        language: language === 'Tamil' ? 'Tamil' : 'English' 
      });
      setExplanation(result.explanation);
    } catch (error: any) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const runDiagnostics = async () => {
    setCheckingStatus(true);
    try {
      const result = await checkAiConfig();
      setAiStatus(result);
    } catch (error: any) {
      setAiStatus({ success: false, error: error.message || 'Unknown diagnostic error' });
    } finally {
      setCheckingStatus(false);
    }
  };

  useEffect(() => {
    runDiagnostics();
  }, []);

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      <header className="text-center space-y-4">
        <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 mb-2">
          <BrainCircuit className="h-8 w-8 text-primary" />
        </div>
        <h1 className="text-4xl font-headline font-bold tracking-tight text-primary">
          AI Concept Tutor
        </h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          {language === 'English'
            ? 'Struggling with a complex math or science concept? Ask our AI tutor for a step-by-step breakdown in your preferred language.'
            : 'சிக்கலான கணிதம் அல்லது அறிவியல் கருத்தை புரிந்துகொள்வதில் சிரமப்படுகிறீர்களா? எங்களின் AI பயிற்றுவிப்பாளரிடம் உங்கள் விருப்பமான மொழியில் விளக்குமாறு கேளுங்கள்.'}
        </p>
      </header>

      <Card className="border-2 border-primary/20 shadow-lg overflow-hidden">
        <CardHeader className="bg-primary/5 border-b">
          <CardTitle className="flex items-center gap-2 text-primary">
            <MessageSquare className="h-5 w-5" />
            {language === 'English' ? 'Your Question' : 'உங்கள் கேள்வி'}
          </CardTitle>
          <CardDescription>
            {language === 'English' 
              ? 'Enter the topic or specific problem you need help with.' 
              : 'உங்களுக்கு உதவி தேவைப்படும் தலைப்பு அல்லது குறிப்பிட்ட சிக்கலை உள்ளிடவும்.'}
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <Textarea 
            placeholder={language === 'English' 
              ? "Example: Explain the Pythagorean Theorem and give some real-world examples." 
              : "உதாரணம்: பித்தகோரஸ் தேற்றத்தை விளக்கி, சில நிஜ உலக உதாரணங்களைத் தரவும்."}
            className="min-h-[120px] text-lg resize-none border-none focus-visible:ring-0 p-0"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
        </CardContent>
        <CardFooter className="bg-muted/30 p-4 border-t flex justify-between items-center">
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => setQuestion("Derivatives in Calculus")}>
              Calculus
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setQuestion("Laws of Thermodynamics")}>
              Thermodynamics
            </Button>
          </div>
          <Button 
            onClick={handleExplain} 
            disabled={loading || !question.trim() || (aiStatus !== null && !aiStatus.success)}
            className="rounded-full px-8 h-11"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Thinking...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                {t('askAi')}
              </>
            )}
          </Button>
        </CardFooter>
      </Card>

      {explanation && (
        <Card className="animate-in slide-in-from-bottom-4 duration-500 shadow-xl border-accent/20">
          <CardHeader className="bg-accent/5 flex flex-row items-center justify-between">
            <div className="flex items-center gap-2">
              <Lightbulb className="h-6 w-6 text-accent" />
              <CardTitle className="text-xl">Explanation</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-8">
            <ScrollArea className="h-full">
              <div className="prose prose-slate max-w-none dark:prose-invert">
                <div className="whitespace-pre-wrap leading-relaxed text-lg text-foreground/90">
                  {explanation}
                </div>
              </div>
            </ScrollArea>
          </CardContent>
          <CardFooter className="bg-accent/5 p-4 border-t flex justify-center">
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Sparkles className="h-3 w-3" /> AI-generated content can occasionally be inaccurate.
            </p>
          </CardFooter>
        </Card>
      )}

      {/* Admin Debug Panel */}
      {isAdmin && (
        <div className="mt-12 border-t pt-8">
          <Collapsible>
            <CollapsibleTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2 text-[10px] uppercase font-bold tracking-widest">
                <Terminal className="h-3 w-3" /> System Diagnostics (Admin Only)
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-4 space-y-4">
              <Card className="bg-slate-950 text-slate-50 border-none font-mono text-[11px] p-4 overflow-x-auto">
                <div className="space-y-1">
                  <p className="text-blue-400"># AI_CONFIG_CHECK</p>
                  <p>STATUS: {checkingStatus ? 'VERIFYING...' : aiStatus?.success ? 'SUCCESS' : 'FAILED'}</p>
                  {aiStatus?.maskedKey && <p>KEY_HASH: {aiStatus.maskedKey}</p>}
                  {aiStatus?.error && <p className="text-red-400">ERROR: {aiStatus.error}</p>}
                  {aiStatus?.message && <p className="text-emerald-400">RESP: {aiStatus.message}</p>}
                </div>
              </Card>
              <Button size="sm" variant="secondary" onClick={runDiagnostics} disabled={checkingStatus}>
                {checkingStatus ? <Loader2 className="h-3 w-3 animate-spin mr-2" /> : <RefreshCw className="h-3 w-3 mr-2" />}
                Force Resync
              </Button>
            </CollapsibleContent>
          </Collapsible>
        </div>
      )}

      {/* Persistent Status Indicator */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50">
        <div className="bg-background/80 backdrop-blur-md border shadow-2xl rounded-full px-4 py-2 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2">
           {checkingStatus ? (
             <>
               <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />
               <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-tighter">Connecting to Hub Intelligence...</span>
             </>
           ) : aiStatus?.success ? (
             <>
               <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
               <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-tighter">AI Concept Tutor Online</span>
             </>
           ) : (
             <>
               <div className="h-2 w-2 rounded-full bg-destructive" />
               <span className="text-[10px] font-bold text-destructive uppercase tracking-tighter">AI Tutor is currently unavailable.</span>
               {isAdmin && <Info className="h-3 w-3 text-muted-foreground ml-1" title="Check admin debug panel for details" />}
             </>
           )}
        </div>
      </div>
    </div>
  );
}

function RefreshCw(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
      <path d="M21 3v5h-5" />
      <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
      <path d="M3 21v-5h5" />
    </svg>
  )
}
