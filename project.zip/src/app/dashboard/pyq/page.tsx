"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { History, ExternalLink, Search, FileText, Globe, Download, Calendar, Filter, Loader2, Clock, CheckCircle2, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";

const CATEGORIES = ["All", "UPSC", "TNPSC", "SSC", "Banking", "RRB", "UGC NET", "TET"];

export default function PYQLibrary() {
  const db = useFirestore();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const pyqsRef = useMemoFirebase(() => collection(db, "pyqs"), [db]);
  const pyqsQuery = useMemoFirebase(() => query(pyqsRef, orderBy("year", "desc")), [pyqsRef]);
  
  const { data: pyqs, loading } = useCollection(pyqsQuery);

  const filteredPyqs = useMemo(() => {
    return pyqs.filter(p => {
      const matchesSearch = 
        p.title.toLowerCase().includes(search.toLowerCase()) ||
        p.description?.toLowerCase().includes(search.toLowerCase()) ||
        p.year.includes(search);
      const matchesCategory = activeCategory === "All" || p.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [pyqs, search, activeCategory]);

  const handleDownload = (p: any) => {
    if (p.status !== 'available' || p.url === '#') {
      toast({
        title: "Coming Soon",
        description: "This paper is currently being digitized by our faculty team.",
        variant: "default"
      });
      return;
    }
    window.open(p.url, '_blank');
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-4xl font-headline font-bold text-primary flex items-center gap-3">
            <History className="h-10 w-10 text-accent" />
            PYQ Library
          </h1>
          <p className="text-muted-foreground text-lg">Official previous year question papers and validated answer keys.</p>
        </div>
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input 
            placeholder="Search by year, exam or topic..." 
            className="pl-10 h-12 shadow-sm rounded-full" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-card p-2 rounded-2xl border shadow-sm">
        <ScrollArea className="w-full">
          <div className="flex gap-2 p-1">
            {CATEGORIES.map((cat) => (
              <Button 
                key={cat} 
                variant={cat === activeCategory ? 'default' : 'ghost'}
                size="sm"
                className="rounded-full whitespace-nowrap px-6 font-bold"
                onClick={() => setActiveCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredPyqs.map((p) => (
          <Card key={p.id} className="group hover:shadow-2xl transition-all duration-300 border-none ring-1 ring-border bg-card flex flex-col overflow-hidden">
            <CardHeader className="p-6 pb-2">
              <div className="flex items-center justify-between mb-4">
                <Badge variant="secondary" className="text-[10px] uppercase font-bold px-2 py-0.5 bg-primary/10 text-primary border-none">
                  {p.category}
                </Badge>
                <div className="flex items-center gap-1 text-[10px] font-bold text-muted-foreground">
                  <Calendar className="h-3 w-3" /> {p.year}
                </div>
              </div>
              <CardTitle className="text-lg font-headline group-hover:text-primary transition-colors leading-tight line-clamp-2 min-h-[3.5rem]">
                {p.title}
              </CardTitle>
            </CardHeader>
            
            <CardContent className="p-6 pt-2 flex-1 space-y-4">
              <p className="text-xs text-muted-foreground line-clamp-3 leading-relaxed italic">
                {p.description || `Official examination records for ${p.category} ${p.year}.`}
              </p>
              <div className="flex items-center gap-2">
                <Badge variant={p.type === 'Answer Key' ? 'outline' : 'default'} className="text-[9px] uppercase">
                  {p.type}
                </Badge>
                {p.status === 'available' ? (
                  <span className="text-[9px] text-emerald-600 font-bold flex items-center gap-1 uppercase">
                    <CheckCircle2 className="h-2.5 w-2.5" /> Ready
                  </span>
                ) : (
                  <span className="text-[9px] text-amber-600 font-bold flex items-center gap-1 uppercase">
                    <Clock className="h-2.5 w-2.5" /> Coming Soon
                  </span>
                )}
              </div>
            </CardContent>

            <CardFooter className="p-6 pt-0 mt-auto border-t bg-muted/5 flex items-center justify-between">
              <div className="text-[9px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                <FileText className="h-3 w-3" /> {p.type === 'Answer Key' ? 'Keys' : 'Paper'}
              </div>
              <Button 
                size="sm" 
                variant={p.status === 'available' ? 'default' : 'ghost'} 
                className="rounded-full gap-2 font-bold transition-all"
                onClick={() => handleDownload(p)}
              >
                {p.status === 'available' ? (
                  <>View PDF <ExternalLink className="h-3 w-3" /></>
                ) : (
                  <>Notify Me <Clock className="h-3 w-3" /></>
                )}
              </Button>
            </CardFooter>
          </Card>
        ))}
        
        {!loading && filteredPyqs.length === 0 && (
          <div className="col-span-full py-32 text-center flex flex-col items-center gap-4 border-2 border-dashed rounded-3xl bg-muted/20">
            {pyqs.length === 0 ? (
              <>
                <History className="h-16 w-16 text-muted-foreground/30" />
                <div>
                  <p className="text-xl font-bold">The Archive is Empty</p>
                  <p className="text-muted-foreground max-w-md mx-auto">No previous year papers have been registered for this section yet. Admin is currently uploading official requested archives.</p>
                  <Button asChild variant="outline" className="mt-6 rounded-full px-8">
                    <Link href="/dashboard/admin/pyq">Enter Admin Manager</Link>
                  </Button>
                </div>
              </>
            ) : (
              <>
                 <Search className="h-16 w-16 text-muted-foreground/30" />
                 <div>
                   <p className="text-xl font-bold">No papers found for "{search}"</p>
                   <p className="text-muted-foreground">Try a different category or search term.</p>
                   <Button variant="outline" className="mt-4 rounded-full" onClick={() => { setSearch(""); setActiveCategory("All"); }}>
                     Reset Archive Filters
                   </Button>
                 </div>
              </>
            )}
          </div>
        )}

        {loading && Array.from({length: 4}).map((_, i) => (
          <Card key={i} className="animate-pulse h-64 bg-muted/50 rounded-2xl border-none" />
        ))}
      </div>

      <div className="bg-primary/5 border border-primary/20 p-6 rounded-2xl flex gap-4 items-start shadow-sm mt-12">
        <AlertCircle className="h-6 w-6 text-primary shrink-0" />
        <div className="space-y-1">
          <h3 className="font-bold text-primary">Academic Accuracy</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            All papers are official scans provided by the respective examination boards. For "Coming Soon" records, our experts are currently validating the answer keys to ensure the highest accuracy for your preparation.
          </p>
        </div>
      </div>
    </div>
  );
}