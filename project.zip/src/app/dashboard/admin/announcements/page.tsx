
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useUser, useMemoFirebase } from "@/firebase";
import { collection, addDoc, deleteDoc, doc, serverTimestamp, query, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { BellRing, Trash2, Send, Loader2, Target, Globe } from "lucide-react";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function ManageAnnouncements() {
  const db = useFirestore();
  const { user } = useUser();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const announcementsRef = useMemo(() => collection(db, "announcements"), [db]);
  const coursesRef = useMemo(() => collection(db, "courses"), [db]);
  
  const announcementsQuery = useMemoFirebase(() => 
    query(announcementsRef, orderBy("createdAt", "desc")), 
    [announcementsRef]
  );
  
  const { data: announcements } = useCollection(announcementsQuery);
  const { data: courses } = useCollection(coursesRef);

  const [formData, setFormData] = useState({
    title: "",
    content: "",
    type: "info",
    courseId: "global"
  });

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const announcement = {
      ...formData,
      authorId: user?.uid || 'admin',
      authorName: user?.displayName || 'Administrator',
      createdAt: new Date().toISOString(),
      readBy: [] // Tracks UIDs of users who dismissed/read
    };

    addDoc(announcementsRef, announcement)
      .then(() => {
        setFormData({ title: "", content: "", type: "info", courseId: "global" });
        setLoading(false);
        toast({ title: "Announcement Published", description: "The update is now live for all targeted students." });
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: announcementsRef.path,
          operation: 'create',
          requestResourceData: announcement,
        }));
      });
  };

  const handleDelete = (id: string) => {
    const docRef = doc(db, "announcements", id);
    deleteDoc(docRef).catch(async (err) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: docRef.path,
        operation: 'delete',
      }));
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-orange-100 p-3 rounded-xl text-orange-600">
          <BellRing className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-3xl font-headline font-bold">Communications Center</h1>
          <p className="text-muted-foreground">Broadcast updates or target specific course students.</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="shadow-md h-fit">
          <CardHeader>
            <CardTitle>Create Broadcast</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePost} className="space-y-4">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input 
                  required 
                  value={formData.title} 
                  onChange={e => setFormData({...formData, title: e.target.value})}
                  placeholder="e.g. Exam Portal Maintenance"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Target Audience</Label>
                  <Select value={formData.courseId} onValueChange={v => setFormData({...formData, courseId: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="global">All Students (Global)</SelectItem>
                      {courses.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.title}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Alert Level</Label>
                  <Select value={formData.type} onValueChange={v => setFormData({...formData, type: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="info">Info (Blue)</SelectItem>
                      <SelectItem value="warning">Critical (Amber)</SelectItem>
                      <SelectItem value="success">Update (Emerald)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Message Body</Label>
                <Textarea 
                  required
                  value={formData.content} 
                  onChange={e => setFormData({...formData, content: e.target.value})}
                  placeholder="Write the detailed announcement here..."
                  className="min-h-[150px]"
                />
              </div>
              <Button type="submit" className="w-full h-11" disabled={loading}>
                {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Send className="h-4 w-4 mr-2" />}
                Publish Announcement
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <h2 className="text-xl font-headline font-bold">Broadcast History</h2>
          <div className="grid gap-4">
            {announcements.map((a) => (
              <Card key={a.id} className="border-l-4 overflow-hidden relative group" style={{ borderLeftColor: 
                a.type === 'info' ? '#3b82f6' : a.type === 'warning' ? '#f59e0b' : '#10b981'
              }}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="text-[9px] uppercase font-bold">
                          {a.courseId === 'global' ? <Globe className="h-3 w-3 mr-1" /> : <Target className="h-3 w-3 mr-1" />}
                          {a.courseId === 'global' ? 'Global' : 'Targeted'}
                        </Badge>
                        <Badge variant="outline" className="text-[9px] uppercase font-bold">{a.type}</Badge>
                      </div>
                      <h3 className="text-lg font-bold">{a.title}</h3>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-destructive opacity-0 group-hover:opacity-100 transition-opacity" 
                      onClick={() => handleDelete(a.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-muted-foreground text-sm whitespace-pre-wrap line-clamp-3">{a.content}</p>
                  <div className="flex justify-between items-center mt-4">
                    <span className="text-[10px] text-muted-foreground font-bold uppercase">
                      By {a.authorName} • {new Date(a.createdAt).toLocaleString()}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
            {announcements.length === 0 && (
              <div className="py-20 text-center text-muted-foreground border-2 border-dashed rounded-xl">
                No communications have been recorded yet.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
