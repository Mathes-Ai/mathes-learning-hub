
"use client";

import { useMemo } from "react";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, where, orderBy, limit } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { 
  Users, 
  BookOpen, 
  GraduationCap, 
  ClipboardList, 
  TrendingUp, 
  Activity, 
  Globe, 
  ArrowRight,
  ShieldCheck,
  Zap,
  BarChart3,
  Calendar,
  UserCheck,
  Loader2
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  Cell,
  PieChart,
  Pie
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function AdminControlCenter() {
  const db = useFirestore();

  // Stable Queries
  const usersQuery = useMemoFirebase(() => collection(db, "users"), [db]);
  const coursesQuery = useMemoFirebase(() => collection(db, "courses"), [db]);
  const testsQuery = useMemoFirebase(() => collection(db, "tests"), [db]);
  const enrollmentsQuery = useMemoFirebase(() => collection(db, "enrollments"), [db]);
  const attendanceQuery = useMemoFirebase(() => collection(db, "attendance"), [db]);
  const announcementsQuery = useMemoFirebase(() => 
    query(collection(db, "announcements"), orderBy("createdAt", "desc"), limit(5)), 
    [db]
  );

  // Data Fetching
  const { data: allUsers, loading: loadingUsers } = useCollection(usersQuery);
  const { data: courses } = useCollection(coursesQuery);
  const { data: tests } = useCollection(testsQuery);
  const { data: enrollments } = useCollection(enrollmentsQuery);
  const { data: announcements } = useCollection(announcementsQuery);
  const { data: attendance } = useCollection(attendanceQuery);

  // Derived Analytics
  const stats = useMemo(() => {
    const students = allUsers.filter(u => u.role === 'student').length;
    const teachers = allUsers.filter(u => u.role === 'teacher').length;
    const totalEnrollments = enrollments.length;
    const platformTests = tests.length;
    
    const presentRecords = attendance.filter(a => a.status === 'present').length;
    const totalRecords = attendance.length;
    const globalAttendance = totalRecords > 0 ? Math.round((presentRecords / totalRecords) * 100) : 0;

    return { students, teachers, totalEnrollments, platformTests, globalAttendance };
  }, [allUsers, enrollments, tests, attendance]);

  // Enrollment Growth Chart Data
  const enrollmentGrowth = useMemo(() => {
    const dates: Record<string, number> = {};
    enrollments.forEach(e => {
      if (!e.enrolledAt) return;
      const date = new Date(e.enrolledAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      dates[date] = (dates[date] || 0) + 1;
    });
    return Object.entries(dates).map(([name, value]) => ({ name, value })).slice(-7);
  }, [enrollments]);

  // Course Category Distribution
  const categoryData = useMemo(() => {
    const cats: Record<string, number> = {};
    courses.forEach(c => {
      cats[c.category] = (cats[c.category] || 0) + 1;
    });
    return Object.entries(cats).map(([name, value]) => ({ name, value })).sort((a,b) => b.value - a.value).slice(0, 5);
  }, [courses]);

  const COLORS = ['#2E4CAD', '#0F5E8A', '#10b981', '#f59e0b', '#ef4444'];

  const adminActions = [
    { title: "Course Library", icon: BookOpen, link: "/dashboard/admin/courses", count: courses.length },
    { title: "Manage Roster", icon: GraduationCap, link: "/dashboard/admin/enrollments", count: enrollments.length },
    { title: "Assessments", icon: ClipboardList, link: "/dashboard/admin/tests", count: tests.length },
    { title: "Notifications", icon: Zap, link: "/dashboard/admin/announcements", count: announcements.length },
  ];

  if (loadingUsers) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center space-y-4">
        <Loader2 className="h-10 w-10 text-primary animate-spin" />
        <p className="text-muted-foreground font-bold uppercase tracking-widest text-[10px]">Synchronizing Hub Systems...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-12">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-4xl font-headline font-bold text-primary flex items-center gap-3">
            <Activity className="h-10 w-10 text-accent" />
            Mathes Learning Hub Control Center
          </h1>
          <p className="text-muted-foreground text-lg">Real-time overview of Mathes Learning Hub performance.</p>
        </div>
        <div className="flex items-center gap-2 bg-card p-1 rounded-full border shadow-sm px-4">
          <Globe className="h-4 w-4 text-emerald-500" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Global Operations Live</span>
        </div>
      </header>

      {/* Main Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Students', value: stats.students, icon: Users, bg: 'bg-blue-100', color: 'text-blue-600' },
          { label: 'Verified Faculty', value: stats.teachers, icon: ShieldCheck, bg: 'bg-emerald-100', color: 'text-emerald-600' },
          { label: 'Avg. Attendance', value: `${stats.globalAttendance}%`, icon: UserCheck, bg: 'bg-indigo-100', color: 'text-indigo-600' },
          { label: 'Active Mock Tests', value: stats.platformTests, icon: BarChart3, bg: 'bg-orange-100', color: 'text-orange-600' },
        ].map((stat, i) => (
          <Card key={i} className="border-none shadow-md ring-1 ring-border group hover:shadow-xl transition-all">
            <CardContent className="p-8 flex items-center gap-6">
              <div className={`${stat.bg} ${stat.color} p-4 rounded-2xl group-hover:scale-110 transition-transform`}>
                <stat.icon className="h-8 w-8" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest mb-1">{stat.label}</p>
                <h3 className="text-4xl font-bold">{stat.value}</h3>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Growth Chart */}
        <Card className="lg:col-span-2 shadow-xl border-none ring-1 ring-border overflow-hidden">
          <CardHeader className="bg-muted/30 border-b">
            <CardTitle>Enrollment Growth</CardTitle>
            <CardDescription>Daily new student registrations across the platform.</CardDescription>
          </CardHeader>
          <CardContent className="h-[350px] p-8">
            {enrollmentGrowth.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={enrollmentGrowth}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                  <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
                  <YAxis fontSize={10} axisLine={false} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="value" fill="#2E4CAD" radius={[6, 6, 0, 0]} barSize={32} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground text-sm italic opacity-30">
                Awaiting enrollment data to populate charts.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Action Center */}
        <Card className="shadow-xl border-none ring-1 ring-border flex flex-col">
          <CardHeader>
            <CardTitle>Administrative Shortcuts</CardTitle>
            <CardDescription>Manage core Mathes Learning Hub modules.</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
             {adminActions.map((action) => (
               <Button 
                key={action.title} 
                asChild 
                variant="outline" 
                className="w-full h-16 justify-between px-6 rounded-2xl hover:bg-primary/5 hover:border-primary/50 group"
              >
                 <Link href={action.link} className="flex items-center justify-between w-full">
                   <div className="flex items-center gap-4">
                     <div className="h-10 w-10 rounded-xl bg-muted group-hover:bg-primary/10 group-hover:text-primary flex items-center justify-center transition-colors">
                       <action.icon className="h-5 w-5" />
                     </div>
                     <div className="text-left">
                       <p className="font-bold">{action.title}</p>
                       <p className="text-[10px] text-muted-foreground uppercase">{action.count} Items Registered</p>
                     </div>
                   </div>
                   <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                 </Link>
               </Button>
             ))}
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Category Breakdown */}
        <Card className="border-none shadow-xl ring-1 ring-border">
          <CardHeader>
            <CardTitle>Curriculum Distribution</CardTitle>
            <CardDescription>Breakdown of active courses by exam category.</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground text-sm italic opacity-30">
                Create courses to see curriculum map.
              </div>
            )}
            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {categoryData.map((d, i) => (
                <div key={d.name} className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                  <span className="text-[10px] font-bold text-muted-foreground uppercase">{d.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Global Broadcast Logs */}
        <Card className="border-none shadow-xl ring-1 ring-border overflow-hidden">
          <CardHeader className="bg-card flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Communications</CardTitle>
              <CardDescription>Latest global and targeted announcements.</CardDescription>
            </div>
            <Button asChild variant="ghost" size="sm" className="text-xs text-primary">
              <Link href="/dashboard/admin/announcements">View Center</Link>
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {announcements.map((a) => (
                <div key={a.id} className="p-6 flex items-start gap-4 hover:bg-muted/30 transition-colors">
                  <div className={`h-10 w-10 rounded-full flex items-center justify-center shrink-0 ${
                    a.type === 'warning' ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'
                  }`}>
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-bold text-sm truncate">{a.title}</h4>
                    <p className="text-xs text-muted-foreground line-clamp-1">{a.content}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <span className="text-[9px] font-bold text-muted-foreground uppercase">
                        {new Date(a.createdAt).toLocaleDateString()}
                      </span>
                      <Badge variant="secondary" className="text-[8px] h-4 uppercase">{a.courseId === 'global' ? 'Global' : 'Targeted'}</Badge>
                    </div>
                  </div>
                </div>
              ))}
              {announcements.length === 0 && (
                <div className="p-12 text-center text-muted-foreground text-sm italic">
                  No recent broadcast logs found.
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
