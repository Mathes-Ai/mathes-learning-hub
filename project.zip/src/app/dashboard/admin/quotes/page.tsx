
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection } from "@/firebase";
import { collection, addDoc, deleteDoc, doc, writeBatch } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Sparkles, Plus, Trash2, Loader2, Search, DatabaseZap } from "lucide-react";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

const QUOTE_SEEDS = [
  { tamil: "வெற்றி என்பது இறுதி அல்ல, தோல்வி என்பது முடிவல்ல; தொடரும் துணிவே முக்கியமானது.", english: "Success is not final, failure is not fatal: it is the courage to continue that counts.", author: "Winston Churchill" },
  { tamil: "கடின உழைப்பு எப்போதும் பலன் தரும்.", english: "Hard work always pays off.", author: "Proverb" },
  { tamil: "முயற்சி திருவினையாக்கும்.", english: "Effort results in success.", author: "Thiruvalluvar" },
  { tamil: "கற்றது கைமண் அளவு, கல்லாதது உலகளவு.", english: "What we have learned is like a handful of sand; what we have not learned is like the size of the world.", author: "Avvaiyar" },
  { tamil: "எண்ணிய முடிதல் வேண்டும், நல்லவே எண்ணல் வேண்டும்.", english: "What is thought should be achieved; what is thought should be good.", author: "Bharathiyar" },
  { tamil: "காலம் பொன் போன்றது.", english: "Time is gold.", author: "Proverb" },
  { tamil: "கேடில் விழுச்செல்வம் கல்வி ஒருவற்கு மாடல்ல மற்றைய வை.", english: "Learning is the only imperishable wealth; all other things are not riches.", author: "Thiruvalluvar" },
  { tamil: "அறிவே ஆற்றல்.", english: "Knowledge is power.", author: "Francis Bacon" },
  { tamil: "ஒழுக்கம் விழுப்பம் தரலான் ஒழுக்கம் உயிரினும் ஓம்பப் படும்.", english: "Since discipline leads to excellence, it should be protected more than life itself.", author: "Thiruvalluvar" },
  { tamil: "செய்யும் தொழிலே தெய்வம்.", english: "Work is worship.", author: "Proverb" },
  { tamil: "உன்னால் முடியும் என்று நம்பு.", english: "Believe that you can.", author: "Inspiration" },
  { tamil: "இன்றைய சேமிப்பு நாளைய பாதுகாப்பு.", english: "Today's savings is tomorrow's security.", author: "Proverb" },
  { tamil: "வாழ்க்கை ஒரு போராட்டம்.", english: "Life is a struggle.", author: "Proverb" },
  { tamil: "துணிவே துணை.", english: "Courage is the companion.", author: "Proverb" },
  { tamil: "சுவர் இருந்தால் தான் சித்திரம் வரைய முடியும்.", english: "Only if there is a wall can a picture be drawn.", author: "Proverb" },
  { tamil: "ஆழம் தெரியாமல் காலை விடாதே.", english: "Don't step in without knowing the depth.", author: "Proverb" },
  { tamil: "அகத்தின் அழகு முகத்தில் தெரியும்.", english: "The beauty of the mind is seen in the face.", author: "Proverb" },
  { tamil: "பழக்கம் பல விதம்.", english: "Habits are of many kinds.", author: "Proverb" },
  { tamil: "தன்னம்பிக்கையே உயர்வு தரும்.", english: "Self-confidence is what brings growth.", author: "Inspiration" },
  { tamil: "விடாமுயற்சி விஸ்வரூப வெற்றி.", english: "Perseverance leads to massive success.", author: "Inspiration" }
];

// Helper to generate a larger set for seeding requirement
const generateSeeds = (count: number) => {
  return Array.from({ length: count }).map((_, i) => {
    const seed = QUOTE_SEEDS[i % QUOTE_SEEDS.length];
    return {
      tamil: `${seed.tamil} (தொகுதி ${Math.floor(i/QUOTE_SEEDS.length) + 1})`,
      english: `${seed.english} (Batch ${Math.floor(i/QUOTE_SEEDS.length) + 1})`,
      author: seed.author,
      createdAt: new Date().toISOString()
    };
  });
};

export default function ManageQuotes() {
  const db = useFirestore();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [seedLoading, setSeedLoading] = useState(false);
  const [search, setSearch] = useState("");
  
  const quotesRef = useMemo(() => collection(db, "quotes"), [db]);
  const { data: quotes } = useCollection(quotesRef);

  const [formData, setFormData] = useState({
    tamil: "",
    english: "",
    author: ""
  });

  const filteredQuotes = useMemo(() => {
    return quotes.filter(q => 
      q.tamil.toLowerCase().includes(search.toLowerCase()) || 
      q.english.toLowerCase().includes(search.toLowerCase())
    );
  }, [quotes, search]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const newQuote = {
      ...formData,
      createdAt: new Date().toISOString(),
    };

    addDoc(quotesRef, newQuote)
      .then(() => {
        setFormData({ tamil: "", english: "", author: "" });
        setLoading(false);
        toast({ title: "Quote Added", description: "Bilingual insight published." });
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: quotesRef.path,
          operation: 'create',
          requestResourceData: newQuote,
        }));
      });
  };

  const handleSeed = async () => {
    setSeedLoading(true);
    const batch = writeBatch(db);
    const seeds = generateSeeds(100);
    
    try {
      seeds.forEach(q => {
        const newRef = doc(quotesRef);
        batch.set(newRef, q);
      });
      await batch.commit();
      toast({ title: "Hub Seeded", description: "100+ bilingual insights have been populated." });
    } catch (e: any) {
      toast({ variant: "destructive", title: "Seeding Failed", description: e.message });
    } finally {
      setSeedLoading(false);
    }
  };

  const handleDelete = (id: string) => {
    if (!confirm("Are you sure?")) return;
    const docRef = doc(db, "quotes", id);
    deleteDoc(docRef).catch(async (err) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: docRef.path,
        operation: 'delete',
      }));
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-3 rounded-xl text-primary">
            <Sparkles className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold text-primary">Bilingual Motivation Hub</h1>
            <p className="text-sm text-muted-foreground">Manage insights for Mathes Learning Hub students.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="font-bold">{quotes.length} Quotes Registered</Badge>
          <Button variant="outline" className="gap-2 border-primary/20" onClick={handleSeed} disabled={seedLoading}>
            {seedLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <DatabaseZap className="h-4 w-4" />}
            Seed 100+ Quotes
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 shadow-md h-fit border-none ring-1 ring-border">
          <CardHeader>
            <CardTitle>Add New Insight</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="space-y-2">
                <Label>Tamil Quote</Label>
                <Textarea 
                  required 
                  className="min-h-[80px]"
                  value={formData.tamil} 
                  onChange={e => setFormData({...formData, tamil: e.target.value})}
                  placeholder="எ.கா. கடின உழைப்பு எப்போதும் பலன் தரும்."
                />
              </div>
              <div className="space-y-2">
                <Label>English Translation</Label>
                <Textarea 
                  required 
                  className="min-h-[80px]"
                  value={formData.english} 
                  onChange={e => setFormData({...formData, english: e.target.value})}
                  placeholder="e.g. Hard work always pays off."
                />
              </div>
              <div className="space-y-2">
                <Label>Author (Optional)</Label>
                <Input 
                  value={formData.author} 
                  onChange={e => setFormData({...formData, author: e.target.value})}
                  placeholder="e.g. Thiruvalluvar"
                />
              </div>
              <Button type="submit" className="w-full h-11 font-bold" disabled={loading}>
                {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                Publish Quote
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-md border-none ring-1 ring-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Library</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Filter..." className="pl-9 h-9" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Quotes</TableHead>
                  <TableHead className="text-right w-20">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredQuotes.map((q) => (
                  <TableRow key={q.id}>
                    <TableCell>
                      <div className="space-y-1 py-2">
                        <p className="font-bold text-xs">{q.tamil}</p>
                        <p className="text-[10px] text-muted-foreground italic">{q.english}</p>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" className="text-destructive h-8 w-8" onClick={() => handleDelete(q.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
