
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection } from "@/firebase";
import { collection, addDoc, deleteDoc, doc, serverTimestamp, updateDoc, increment } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Trash2, Plus, Loader2, Link as LinkIcon, Video, Download, Search, Filter } from "lucide-react";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function ManageMaterials() {
  const db = useFirestore();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("All");
  
  const coursesRef = useMemo(() => collection(db, "courses"), [db]);
  const materialsRef = useMemo(() => collection(db, "materials"), [db]);
  
  const { data: courses } = useCollection(coursesRef);
  const { data: materials } = useCollection(materialsRef);

  const [formData, setFormData] = useState({
    title: "",
    courseId: "",
    type: "PDF",
    url: "",
    description: ""
  });

  const filteredMaterials = useMemo(() => {
    return materials.filter(m => {
      const matchesSearch = m.title.toLowerCase().includes(search.toLowerCase());
      const matchesType = filterType === "All" || m.type === filterType;
      return matchesSearch && matchesType;
    });
  }, [materials, search, filterType]);

  const handleAddMaterial = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const newMaterial = {
      ...formData,
      downloadCount: 0,
      createdAt: new Date().toISOString(),
    };

    addDoc(materialsRef, newMaterial)
      .then(() => {
        setFormData({ title: "", courseId: "", type: "PDF", url: "", description: "" });
        setLoading(false);
        toast({ title: "Resource Linked", description: `${newMaterial.title} is now available.` });
      })
      .catch(async (err) => {
        setLoading(false);
        const permissionError = new FirestorePermissionError({
          path: materialsRef.path,
          operation: 'create',
          requestResourceData: newMaterial,
        });
        errorEmitter.emit('permission-error', permissionError);
      });
  };

  const handleDelete = (id: string) => {
    if (!confirm("Are you sure you want to delete this resource?")) return;
    const docRef = doc(db, "materials", id);
    deleteDoc(docRef).catch(async (err) => {
      const permissionError = new FirestorePermissionError({
        path: docRef.path,
        operation: 'delete',
      });
      errorEmitter.emit('permission-error', permissionError);
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-3 rounded-xl text-primary">
            <FileText className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold">Study Resources</h1>
            <p className="text-sm text-muted-foreground">Manage PDFs, Videos, and study guides for all courses.</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 shadow-md border-none ring-1 ring-border h-fit sticky top-8">
          <CardHeader>
            <CardTitle>Link New Resource</CardTitle>
            <CardDescription>Add a link from Google Drive, YouTube, or Storage.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddMaterial} className="space-y-4">
              <div className="space-y-2">
                <Label>Material Title</Label>
                <Input 
                  required 
                  value={formData.title} 
                  onChange={e => setFormData({...formData, title: e.target.value})}
                  placeholder="e.g. UPSC Geography Module 1"
                />
              </div>
              <div className="space-y-2">
                <Label>Associated Course</Label>
                <Select value={formData.courseId} onValueChange={v => setFormData({...formData, courseId: v})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a course" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.title}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Resource Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({...formData, type: v})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PDF">PDF Document</SelectItem>
                    <SelectItem value="Video">Video Lesson (YouTube/Drive)</SelectItem>
                    <SelectItem value="DOCX">Word Document</SelectItem>
                    <SelectItem value="Link">External Website Link</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Resource URL</Label>
                <div className="relative">
                  <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    required
                    className="pl-9"
                    value={formData.url} 
                    onChange={e => setFormData({...formData, url: e.target.value})}
                    placeholder="https://drive.google.com/..."
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Short Description</Label>
                <Input 
                  value={formData.description} 
                  onChange={e => setFormData({...formData, description: e.target.value})}
                  placeholder="Key topics covered..."
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading || !formData.courseId}>
                {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                Add to Library
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-md border-none ring-1 ring-border">
          <CardHeader>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <CardTitle>Resource Registry</CardTitle>
                <CardDescription>Currently housing {materials.length} resources.</CardDescription>
              </div>
              <div className="flex gap-2">
                <div className="relative w-48">
                  <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Search..." 
                    className="pl-8 h-8 text-xs" 
                    value={search} 
                    onChange={e => setSearch(e.target.value)} 
                  />
                </div>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="h-8 w-32 text-xs">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Types</SelectItem>
                    <SelectItem value="PDF">PDF</SelectItem>
                    <SelectItem value="Video">Video</SelectItem>
                    <SelectItem value="DOCX">DOCX</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Resource</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>Engagement</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMaterials.sort((a,b) => b.createdAt.localeCompare(a.createdAt)).map((material) => {
                  const course = courses.find(c => c.id === material.courseId);
                  return (
                    <TableRow key={material.id} className="group">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${
                            material.type === 'Video' ? 'bg-red-50 text-red-600' : 
                            material.type === 'PDF' ? 'bg-blue-50 text-blue-600' : 'bg-muted text-muted-foreground'
                          }`}>
                            {material.type === 'Video' ? <Video className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                          </div>
                          <div>
                            <div className="font-bold text-sm">{material.title}</div>
                            <div className="text-[10px] text-muted-foreground uppercase flex items-center gap-1">
                              <Badge variant="outline" className="px-1 py-0 text-[8px]">{material.type}</Badge>
                              <span>Added {new Date(material.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs max-w-[150px] truncate">
                        {course?.title || 'Unknown'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Download className="h-3 w-3" />
                          {material.downloadCount || 0}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
                            <a href={material.url} target="_blank" rel="noopener noreferrer">
                              <LinkIcon className="h-4 w-4" />
                            </a>
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive h-8 w-8" onClick={() => handleDelete(material.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {filteredMaterials.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-20 text-muted-foreground">
                      No study materials found. Start by linking a resource!
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
