
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, addDoc, deleteDoc, doc, writeBatch, query, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Newspaper, Plus, Trash2, Loader2, DatabaseZap, Search, Globe, Calendar } from "lucide-react";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

const CATEGORIES = ["National", "International", "Economy", "Science & Technology", "Sports"];

export default function ManageCurrentAffairs() {
  const db = useFirestore();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [seedLoading, setSeedLoading] = useState(false);
  const [search, setSearch] = useState("");
  
  const newsRef = useMemoFirebase(() => collection(db, "current_affairs"), [db]);
  const newsQuery = useMemoFirebase(() => query(newsRef, orderBy("date", "desc")), [newsRef]);
  const { data: newsItems, loading: fetching } = useCollection(newsQuery);

  const [formData, setFormData] = useState({
    title: "",
    category: CATEGORIES[0],
    content: "",
    date: new Date().toISOString().split('T')[0],
    imageUrl: "",
    source: ""
  });

  const filteredNews = useMemo(() => {
    return newsItems.filter(n => 
      n.title.toLowerCase().includes(search.toLowerCase()) || 
      n.category.toLowerCase().includes(search.toLowerCase())
    );
  }, [newsItems, search]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const newItem = {
      ...formData,
      createdAt: new Date().toISOString(),
    };

    addDoc(newsRef, newItem)
      .then(() => {
        setFormData({ 
          title: "", 
          category: CATEGORIES[0], 
          content: "", 
          date: new Date().toISOString().split('T')[0],
          imageUrl: "",
          source: ""
        });
        setLoading(false);
        toast({ title: "News Published", description: "Current affairs update is now live." });
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: newsRef.path,
          operation: 'create',
          requestResourceData: newItem,
        }));
      });
  };

  const handleSeed = async () => {
    setSeedLoading(true);
    const batch = writeBatch(db);
    
    const sampleNews = [
      { title: "India's GDP Growth Projections Revised Upwards", category: "Economy", content: "Major international agencies have revised India's growth projection to 7.2% for the current fiscal year citing robust domestic demand.", date: new Date().toISOString().split('T')[0], source: "Financial Times" },
      { title: "ISRO Successfully Launches New Meteorological Satellite", category: "Science & Technology", content: "The Indian Space Research Organisation has successfully placed INSAT-3DS into orbit, enhancing weather monitoring capabilities.", date: new Date().toISOString().split('T')[0], source: "ISRO Official" },
      { title: "G20 Summit: Global Leaders Align on Climate Action", category: "International", content: "Leaders at the G20 summit have agreed on a unified framework to accelerate renewable energy transitions by 2030.", date: new Date().toISOString().split('T')[0], source: "Reuters" },
      { title: "National Education Policy Update 2025", category: "National", content: "The Ministry of Education announced new digital initiatives to provide free higher education resources in regional languages.", date: new Date().toISOString().split('T')[0], source: "PIB India" },
      { title: "Indian Athlete Wins Gold at Asian Games", category: "Sports", content: "Breaking a decade-old record, India secured gold in the javelin throw event during the Asian athletics championships.", date: new Date().toISOString().split('T')[0], source: "The Hindu Sports" }
    ];

    try {
      for (const item of sampleNews) {
        const newDocRef = doc(newsRef);
        batch.set(newDocRef, { ...item, createdAt: new Date().toISOString() });
      }
      await batch.commit();
      toast({ title: "Hub Synchronized", description: "Fresh current affairs have been seeded." });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Seeding Failed", description: err.message });
    } finally {
      setSeedLoading(false);
    }
  };

  const handleDelete = (id: string) => {
    if (!confirm("Are you sure?")) return;
    const docRef = doc(db, "current_affairs", id);
    deleteDoc(docRef).catch(async (err) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: docRef.path,
        operation: 'delete',
      }));
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-blue-100 p-3 rounded-xl text-blue-600">
            <Newspaper className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold text-primary">Current Affairs Manager</h1>
            <p className="text-sm text-muted-foreground">Publish daily news updates for competitive exam aspirants.</p>
          </div>
        </div>
        <Button 
          variant="outline" 
          onClick={handleSeed} 
          disabled={seedLoading}
          className="gap-2 border-blue-200 text-blue-700 bg-blue-50"
        >
          {seedLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <DatabaseZap className="h-4 w-4" />}
          Seed Today's News
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 shadow-md border-none ring-1 ring-border h-fit">
          <CardHeader>
            <CardTitle>Publish Article</CardTitle>
            <CardDescription>Enter news details for students.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="space-y-2">
                <Label>Headline</Label>
                <Input 
                  required 
                  value={formData.title} 
                  onChange={e => setFormData({...formData, title: e.target.value})}
                  placeholder="e.g. Budget 2025 Highlights"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={formData.category} onValueChange={v => setFormData({...formData, category: v})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Report Date</Label>
                  <Input 
                    type="date"
                    required 
                    value={formData.date} 
                    onChange={e => setFormData({...formData, date: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Summary Content</Label>
                <Textarea 
                  required 
                  className="min-h-[150px]"
                  value={formData.content} 
                  onChange={e => setFormData({...formData, content: e.target.value})}
                  placeholder="Explain the significance for exams..."
                />
              </div>
              <div className="space-y-2">
                <Label>Source & Image (Optional)</Label>
                <div className="flex gap-2">
                  <Input 
                    value={formData.source} 
                    onChange={e => setFormData({...formData, source: e.target.value})}
                    placeholder="Source Agency"
                  />
                  <Input 
                    value={formData.imageUrl} 
                    onChange={e => setFormData({...formData, imageUrl: e.target.value})}
                    placeholder="Image URL"
                  />
                </div>
              </div>
              <Button type="submit" className="w-full h-11 font-bold" disabled={loading}>
                {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                Publish Update
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-md border-none ring-1 ring-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>News Log</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search archives..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Headline</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredNews.map((n) => (
                  <TableRow key={n.id}>
                    <TableCell className="max-w-[250px]">
                      <div className="font-bold text-sm truncate">{n.title}</div>
                      <div className="text-[10px] text-muted-foreground truncate">{n.source}</div>
                    </TableCell>
                    <TableCell><Badge variant="outline">{n.category}</Badge></TableCell>
                    <TableCell className="text-xs font-mono">{n.date}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(n.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {filteredNews.length === 0 && !fetching && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-20 text-muted-foreground italic">
                      No news items published yet.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
