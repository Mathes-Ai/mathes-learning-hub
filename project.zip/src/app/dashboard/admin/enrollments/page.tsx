
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection } from "@/firebase";
import { collection, query, where, deleteDoc, doc, updateDoc } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, GraduationCap, Trash2, Filter, Loader2, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";

export default function ManageEnrollments() {
  const db = useFirestore();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [loadingId, setLoadingId] = useState<string | null>(null);

  const enrollmentsRef = useMemo(() => collection(db, "enrollments"), [db]);
  const studentsQuery = useMemo(() => query(collection(db, "users"), where("role", "==", "student")), [db]);
  const coursesQuery = useMemo(() => collection(db, "courses"), [db]);

  const { data: enrollments } = useCollection(enrollmentsRef);
  const { data: students } = useCollection(studentsQuery);
  const { data: courses } = useCollection(coursesQuery);

  const filteredEnrollments = useMemo(() => {
    return enrollments.filter(e => {
      const student = students.find(s => s.id === e.studentId);
      const course = courses.find(c => c.id === e.courseId);
      const searchStr = `${student?.displayName || student?.email} ${course?.title}`.toLowerCase();
      return searchStr.includes(search.toLowerCase());
    });
  }, [enrollments, students, courses, search]);

  const handleDelete = (id: string) => {
    if (!confirm("Are you sure you want to remove this enrollment?")) return;
    const dRef = doc(db, "enrollments", id);
    deleteDoc(dRef).catch(err => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({ path: dRef.path, operation: 'delete' }));
    });
  };

  const handleStatusChange = (id: string, newStatus: string) => {
    setLoadingId(id);
    const dRef = doc(db, "enrollments", id);
    updateDoc(dRef, { status: newStatus })
      .then(() => {
        setLoadingId(null);
        toast({ title: "Updated", description: "Enrollment status updated." });
      })
      .catch(err => {
        setLoadingId(null);
        errorEmitter.emit('permission-error', new FirestorePermissionError({ path: dRef.path, operation: 'update' }));
      });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-3 rounded-xl">
          <GraduationCap className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="text-3xl font-headline font-bold">Enrollment Management</h1>
          <p className="text-muted-foreground">Monitor and manage all active student course enrollments.</p>
        </div>
      </div>

      <Card className="border-none shadow-md ring-1 ring-border">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Master Roster</CardTitle>
          <div className="relative w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search students or courses..." 
              className="pl-9"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Course</TableHead>
                <TableHead>Enrolled At</TableHead>
                <TableHead>Progress</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEnrollments.map((e) => {
                const student = students.find(s => s.id === e.studentId);
                const course = courses.find(c => c.id === e.courseId);
                return (
                  <TableRow key={e.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 bg-muted rounded-full flex items-center justify-center">
                          <User className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div>
                          <div className="font-bold text-sm">{student?.displayName || "Loading..."}</div>
                          <div className="text-[10px] text-muted-foreground">{student?.email}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium text-sm">{course?.title || "Unknown Course"}</div>
                    </TableCell>
                    <TableCell className="text-xs">
                      {new Date(e.enrolledAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 w-24">
                        <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary" style={{ width: `${e.progress || 0}%` }} />
                        </div>
                        <span className="text-[10px] font-bold">{e.progress || 0}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={e.status === 'active' ? 'default' : 'secondary'} className="capitalize">
                        {e.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-destructive h-8 w-8 p-0" 
                        onClick={() => handleDelete(e.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filteredEnrollments.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-20 text-muted-foreground">
                    No enrollment records match your search.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
