
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection } from "@/firebase";
import { collection, addDoc, query, where, updateDoc, doc } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreditCard, Search, Filter, Loader2, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";

export default function FeeManagement() {
  const db = useFirestore();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);

  const studentsQuery = useMemo(() => query(collection(db, "users"), where("role", "==", "student")), [db]);
  const coursesQuery = useMemo(() => collection(db, "courses"), [db]);
  const paymentsQuery = useMemo(() => collection(db, "payments"), [db]);

  const { data: students } = useCollection(studentsQuery);
  const { data: courses } = useCollection(coursesQuery);
  const { data: payments } = useCollection(paymentsQuery);

  const [formData, setFormData] = useState({
    studentId: "",
    courseId: "",
    amount: "",
    status: "pending"
  });

  const handleAddPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const newPayment = {
      ...formData,
      amount: Number(formData.amount),
      createdAt: new Date().toISOString(),
      paidAt: formData.status === 'paid' ? new Date().toISOString() : null
    };

    addDoc(collection(db, "payments"), newPayment)
      .then(() => {
        setFormData({ studentId: "", courseId: "", amount: "", status: "pending" });
        setLoading(false);
        toast({ title: "Success", description: "Fee record added" });
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit("permission-error", new FirestorePermissionError({
          path: "payments",
          operation: "create",
          requestResourceData: newPayment
        }));
      });
  };

  const handleUpdateStatus = (paymentId: string, newStatus: string) => {
    const pRef = doc(db, "payments", paymentId);
    updateDoc(pRef, { 
      status: newStatus,
      paidAt: newStatus === 'paid' ? new Date().toISOString() : null 
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-emerald-100 p-3 rounded-xl text-emerald-600">
          <CreditCard className="h-6 w-6" />
        </div>
        <h1 className="text-3xl font-headline font-bold">Fee Tracking</h1>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="h-fit shadow-md">
          <CardHeader>
            <CardTitle>Record New Fee</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddPayment} className="space-y-4">
              <div className="space-y-2">
                <Label>Student</Label>
                <Select value={formData.studentId} onValueChange={v => setFormData({...formData, studentId: v})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select student" />
                  </SelectTrigger>
                  <SelectContent>
                    {students.map(s => <SelectItem key={s.id} value={s.id}>{s.displayName || s.email}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Course</Label>
                <Select value={formData.courseId} onValueChange={v => setFormData({...formData, courseId: v})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select course" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map(c => <SelectItem key={c.id} value={c.id}>{c.title}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Amount (₹)</Label>
                <Input 
                  type="number"
                  value={formData.amount}
                  onChange={e => setFormData({...formData, amount: e.target.value})}
                  placeholder="0.00"
                />
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={v => setFormData({...formData, status: v})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="overdue">Overdue</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="w-full" disabled={loading || !formData.studentId}>
                {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : "Record Fee"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-md">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Transactions</CardTitle>
            <div className="relative w-48">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search..." 
                className="pl-9 h-8"
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments.map((p) => {
                  const student = students.find(s => s.id === p.studentId);
                  const course = courses.find(c => c.id === p.courseId);
                  return (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium">{student?.displayName || "Loading..."}</TableCell>
                      <TableCell className="text-xs">{course?.title || "Unknown"}</TableCell>
                      <TableCell>₹{p.amount}</TableCell>
                      <TableCell>
                        <Badge variant={p.status === 'paid' ? 'default' : p.status === 'overdue' ? 'destructive' : 'secondary'}>
                          {p.status.toUpperCase()}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {p.status !== 'paid' && (
                          <Button size="sm" variant="outline" onClick={() => handleUpdateStatus(p.id, 'paid')}>
                            Mark Paid
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
