
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection } from "@/firebase";
import { collection, addDoc, deleteDoc, doc, writeBatch, query, getDocs, updateDoc } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ClipboardCheck, Sparkles, Loader2, Trash2, ShieldAlert, DatabaseZap, Trophy, AlertCircle, CheckCircle2, AlertTriangle, ListChecks, RefreshCw } from "lucide-react";
import { generateQuiz } from "@/ai/flows/generate-quiz-flow";
import { useToast } from "@/hooks/use-toast";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const CATEGORY_MAP: Record<string, any[]> = {
  "UPSC": [
    { q: "Which article of the Indian Constitution empowers the President to appoint the Prime Minister?", a: "Article 75", o: ["Article 74", "Article 75", "Article 76", "Article 77"], e: "Article 75 states that the Prime Minister shall be appointed by the President. This ensures executive accountability to Parliament." },
    { q: "The 'Montagu-Chelmsford Reforms' are associated with which year in Indian history?", a: "1919", o: ["1909", "1919", "1935", "1947"], e: "The Government of India Act 1919 was based on these reforms, introducing dyarchy in provinces." },
    { q: "Which layer of the atmosphere contains the highest concentration of the Ozone layer?", a: "Stratosphere", o: ["Troposphere", "Stratosphere", "Mesosphere", "Exosphere"], e: "The stratosphere extends from about 10 to 50 km and protects life by absorbing UV radiation." },
    { q: "Who was the first Indian to join the Indian Civil Service (ICS)?", a: "Satyendranath Tagore", o: ["Satyendranath Tagore", "Surendranath Banerjee", "Subhash Chandra Bose", "Dadabhai Nooroji"], e: "Satyendranath Tagore cleared the exam in 1863, becoming the first Indian officer." },
    { q: "The Quit India Movement was launched in response to the failure of which mission?", a: "Cripps Mission", o: ["Cripps Mission", "Simon Commission", "Cabinet Mission", "Wavell Plan"], e: "The failure of the Cripps Mission in 1942 led Gandhi to launch the 'Do or Die' movement." },
    { q: "In the Indian economy, which sector contributes the most to the GDP?", a: "Service Sector", o: ["Primary Sector", "Manufacturing Sector", "Service Sector", "Mining Sector"], e: "The tertiary or service sector has been the largest contributor to India's GDP for decades." },
    { q: "Which river is known as the 'Dakshin Ganga'?", a: "Godavari", o: ["Kaveri", "Krishna", "Godavari", "Narmada"], e: "Godavari is the largest peninsular river and is revered for its length and spiritual significance." },
    { q: "The concept of 'Fundamental Duties' was taken from which constitution?", a: "USSR Constitution", o: ["USA Constitution", "British Constitution", "USSR Constitution", "Irish Constitution"], e: "Fundamental Duties were added by the 42nd Amendment Act in 1976 based on the USSR model." },
    { q: "Which organization publishes the Human Development Report?", a: "UNDP", o: ["World Bank", "IMF", "UNDP", "UNESCO"], e: "The United Nations Development Programme (UNDP) has published the report annually since 1990." },
    { q: "The headquarter of the International Court of Justice is located at?", a: "The Hague", o: ["Geneva", "Paris", "New York", "The Hague"], e: "The Peace Palace in The Hague, Netherlands, is the seat of the ICJ." }
  ],
  "TNPSC": [
    { q: "Who was the first woman doctor in India and a social reformer from Tamil Nadu?", a: "Dr. Muthulakshmi Reddy", o: ["Dr. Muthulakshmi Reddy", "Moovalur Ramamirtham", "Velu Nachiyar", "Annie Besant"], e: "Dr. Muthulakshmi Reddy was the first female legislator in British India and established the Adyar Cancer Institute." },
    { q: "Which Tamil king was known as 'Kadal Kadantha Kadaram Kondan'?", a: "Rajendra Chola I", o: ["Rajaraja Chola I", "Rajendra Chola I", "Karikala Chola", "Narasimhavarman"], e: "Rajendra Chola I expanded the empire to Southeast Asia and established a powerful naval base." },
    { q: "The Self-Respect Movement was started by whom in 1925?", a: "E.V. Ramasamy", o: ["C.N. Annadurai", "E.V. Ramasamy", "M. Karunanidhi", "K. Kamaraj"], e: "Periyar E.V. Ramasamy started the movement to secure a society where backward castes have equal human rights." },
    { q: "Which district in Tamil Nadu is known as the 'Textile Valley'?", a: "Tiruppur", o: ["Madurai", "Salem", "Coimbatore", "Tiruppur"], e: "Tiruppur is a global hub for knitwear exports and contributes significantly to the state's economy." },
    { q: "The Bharatanatyam dance form originated in which state?", a: "Tamil Nadu", o: ["Kerala", "Tamil Nadu", "Andhra Pradesh", "Karnataka"], e: "Bharatanatyam is the oldest classical dance tradition in India, deeply rooted in Tamil Nadu." },
    { q: "Which port is known as the 'Gateway of Tamil Nadu'?", a: "Thoothukudi", o: ["Chennai", "Ennore", "Thoothukudi", "Nagapattinam"], e: "Thoothukudi V.O. Chidambaranar Port is strategically vital for South Indian sea trade." },
    { q: "The famous Meenakshi Amman Temple is located in which city?", a: "Madurai", o: ["Thanjavur", "Madurai", "Trichy", "Kanchipuram"], e: "Madurai is known as the Temple City, with the Meenakshi temple serving as its center." },
    { q: "Who wrote the famous Tamil work 'Tirukkural'?", a: "Thiruvalluvar", o: ["Kambar", "Ilango Adigal", "Thiruvalluvar", "Avvaiyar"], e: "Thiruvalluvar's masterpiece covers ethics, politics, and economics in 1330 couplets." },
    { q: "The first railway line in Tamil Nadu was opened in 1856 between?", a: "Veyasarpadi and Walajapet", o: ["Chennai and Madurai", "Veyasarpadi and Walajapet", "Chennai and Bangalore", "Trichy and Thanjavur"], e: "The Royapuram-Wallajah Road line was the first rail connection in the Madras Presidency." },
    { q: "Which hill station is known as the 'Princess of Hill Stations'?", a: "Ooty", o: ["Ooty", "Yercaud", "Kodaikanal", "Coonoor"], e: "Actually Kodaikanal is the Princess, but Ooty is the Queen. Ooty is a premier tourist destination in the Nilgiris." }
  ],
  "SSC": [
    { q: "Who was the first Mughal Emperor of India?", a: "Babur", o: ["Babur", "Humayun", "Akbar", "Shah Jahan"], e: "Babur founded the Mughal Empire in 1526 after the First Battle of Panipat." },
    { q: "Which planet is known as the Red Planet?", a: "Mars", o: ["Venus", "Mars", "Jupiter", "Saturn"], e: "Mars is called the Red Planet because of the prevalence of iron oxide on its surface." },
    { q: "The Battle of Plassey was fought in which year?", a: "1757", o: ["1757", "1764", "1857", "1885"], e: "The Battle of Plassey was fought in 1757 between the British East India Company and the Nawab of Bengal." },
    { q: "What is the chemical symbol for Gold?", a: "Au", o: ["Ag", "Au", "Pb", "Fe"], e: "Au comes from the Latin word 'Aurum', meaning shining dawn or gold." },
    { q: "Who wrote the book 'Discovery of India'?", a: "Jawaharlal Nehru", o: ["Mahatma Gandhi", "Jawaharlal Nehru", "B.R. Ambedkar", "Subhash Chandra Bose"], e: "Discovery of India was written by Jawaharlal Nehru while he was imprisoned in Ahmednagar Fort." },
    { q: "Which part of the Indian Constitution deals with Fundamental Rights?", a: "Part III", o: ["Part II", "Part III", "Part IV", "Part IV-A"], e: "Part III (Articles 12-35) of the Indian Constitution lists the Fundamental Rights." },
    { q: "What is the SI unit of Pressure?", a: "Pascal", o: ["Newton", "Joule", "Pascal", "Watt"], e: "Pascal is the SI unit of pressure, defined as one Newton per square meter." },
    { q: "The world's largest desert is?", a: "Antarctica", o: ["Sahara", "Gobi", "Antarctica", "Thar"], e: "Antarctica is the largest cold desert in the world, followed by the Arctic." },
    { q: "Which state is the largest producer of Tea in India?", a: "Assam", o: ["Assam", "West Bengal", "Kerala", "Karnataka"], e: "Assam produces more than 50% of the total tea produced in India." },
    { q: "Who invented the telephone?", a: "Alexander Graham Bell", o: ["Thomas Edison", "Alexander Graham Bell", "Nikola Tesla", "Guglielmo Marconi"], e: "Alexander Graham Bell is credited with patenting the first practical telephone in 1876." }
  ],
  "Banking": [
    { q: "Which organization is known as the 'Bankers' Bank' in India?", a: "RBI", o: ["SBI", "RBI", "NABARD", "SEBI"], e: "The Reserve Bank of India acts as the apex monetary authority and supervises all other banks." },
    { q: "What does ATM stand for in banking?", a: "Automated Teller Machine", o: ["Any Time Money", "Automated Teller Machine", "Automated Transaction Mode", "All Time Money"], e: "ATM stands for Automated Teller Machine, a specialized computer that simplifies banking tasks." },
    { q: "Which rate is the rate at which RBI lends money to commercial banks for long term?", a: "Bank Rate", o: ["Repo Rate", "Reverse Repo Rate", "Bank Rate", "CRR"], e: "Bank Rate is the standard rate at which RBI is prepared to buy or rediscount bills of exchange." },
    { q: "FDI stands for?", a: "Foreign Direct Investment", o: ["Foreign Direct Investment", "Fixed Deposit Interest", "Fiscal Deficit Index", "Foreign Digital Interface"], e: "FDI is an investment in the form of a controlling ownership in a business in one country by an entity based in another country." },
    { q: "The headquarters of IMF is located in?", a: "Washington D.C.", o: ["New York", "Geneva", "Washington D.C.", "Paris"], e: "The International Monetary Fund is headquartered in Washington D.C., USA." },
    { q: "What is the maximum limit of deposit in a PPF account per year?", a: "1.5 Lakh", o: ["1 Lakh", "1.5 Lakh", "2 Lakh", "2.5 Lakh"], e: "The current maximum limit for investment in a Public Provident Fund (PPF) is ₹1,50,000 per annum." },
    { q: "Which bank was formerly known as the Imperial Bank of India?", a: "SBI", o: ["PNB", "SBI", "BoB", "UCO Bank"], e: "The Imperial Bank of India was renamed the State Bank of India in 1955." },
    { q: "What is the validity period of a Cheque?", a: "3 Months", o: ["1 Month", "3 Months", "6 Months", "1 Year"], e: "As per RBI guidelines, a cheque is valid for 3 months from the date of issuance." },
    { q: "Who is the current Governor of RBI (as of 2024)?", a: "Shaktikanta Das", o: ["Urjit Patel", "Raghuram Rajan", "Shaktikanta Das", "Nirmala Sitharaman"], e: "Shaktikanta Das is the 25th and current Governor of the Reserve Bank of India." },
    { q: "PAN stands for?", a: "Permanent Account Number", o: ["Personal Account Number", "Permanent Account Number", "Public Access Number", "Postal Address Number"], e: "PAN is a unique 10-character alphanumeric identifier issued by the Income Tax Department." }
  ],
  "RRB": [
    { q: "Which is the longest railway platform in India?", a: "Hubballi", o: ["Gorakhpur", "Kollam", "Kharagpur", "Hubballi"], e: "Shree Siddharoodha Swamiji Hubballi Station currently holds the record for the world's longest platform." },
    { q: "In which year was the first train started in India?", a: "1853", o: ["1850", "1853", "1901", "1947"], e: "The first passenger train in India ran between Bori Bunder (Mumbai) and Thane in 1853." },
    { q: "What is the full form of PNR in railway ticketing?", a: "Passenger Name Record", o: ["Public Number Record", "Passenger Name Record", "Personal Number Register", "Passenger Note Register"], e: "PNR is a unique number that contains the itinerary and personal details of the passenger." },
    { q: "Which city is the headquarters of South Central Railway?", a: "Secunderabad", o: ["Chennai", "Secunderabad", "Mumbai", "Kolkata"], e: "Secunderabad serves as the headquarters for the South Central Railway zone." },
    { q: "Which of the following is the fastest train in India?", a: "Vande Bharat Express", o: ["Rajdhani Express", "Shatabdi Express", "Gatiman Express", "Vande Bharat Express"], e: "The Vande Bharat Express is India's first semi-high speed, self-propelled train set." },
    { q: "The diamond crossing is located in which Indian city?", a: "Nagpur", o: ["Nagpur", "Jabalpur", "Allahabad", "Lucknow"], e: "Nagpur has the famous 'Diamond Crossing' where North-South and East-West railway lines intersect." },
    { q: "How many zones are there in Indian Railways?", a: "19", o: ["16", "17", "18", "19"], e: "Currently, Indian Railways is divided into 19 zones (including Metro Railway Kolkata)." },
    { q: "Who is known as the father of Indian Railways?", a: "Lord Dalhousie", o: ["Lord Canning", "Lord Dalhousie", "Lord Curzon", "Lord Mountbatten"], e: "Lord Dalhousie introduced railways to India and is considered its father." },
    { q: "Which was the first railway tunnel in India?", a: "Parsik Tunnel", o: ["Parsik Tunnel", "Pir Panjal Tunnel", "Bhomaraguri Tunnel", "Katra Tunnel"], e: "The Parsik Tunnel on the Mumbai-Kalyan route was the first railway tunnel in India." },
    { q: "What is the standard gauge of Indian Railways?", a: "1676 mm", o: ["1000 mm", "1435 mm", "1676 mm", "762 mm"], e: "Broad gauge (1676 mm) is the standard and most widely used gauge in India." }
  ],
  "UGC NET": [
    { q: "Who is known as the Father of Economics?", a: "Adam Smith", o: ["Alfred Marshall", "Adam Smith", "J.M. Keynes", "David Ricardo"], e: "Adam Smith's 'The Wealth of Nations' (1776) laid the foundation for modern economic thought." },
    { q: "The law of demand states that as price increases, quantity demanded?", a: "Decreases", o: ["Increases", "Decreases", "Remains Constant", "Becomes Zero"], e: "The law of demand shows an inverse relationship between price and quantity demanded." },
    { q: "Which market structure has only one seller and many buyers?", a: "Monopoly", o: ["Perfect Competition", "Oligopoly", "Monopoly", "Monopolistic Competition"], e: "Monopoly is characterized by a single firm being the sole provider of a good or service." },
    { q: "The Gini Coefficient is used to measure?", a: "Income Inequality", o: ["Unemployment", "Inflation", "Income Inequality", "Economic Growth"], e: "A Gini coefficient of 0 represents perfect equality, while 1 represents perfect inequality." },
    { q: "What is the main objective of the NITI Aayog?", a: "Strategic policy making", o: ["Strategic policy making", "Fund allocation to states", "Budget preparation", "Controlling inflation"], e: "NITI Aayog replaced the Planning Commission to provide strategic and technical advice to the government." },
    { q: "The 'Invisible Hand' theory was proposed by?", a: "Adam Smith", o: ["Adam Smith", "Karl Marx", "Milton Friedman", "John Hicks"], e: "Smith argued that individuals acting in self-interest unintendedly promote the public good." },
    { q: "GST was implemented in India from which date?", a: "1 July 2017", o: ["1 April 2017", "1 July 2017", "1 January 2018", "15 August 2017"], e: "Goods and Services Tax (GST) is a comprehensive indirect tax implemented on July 1, 2017." },
    { q: "What is 'Stagflation'?", a: "High inflation + Low growth", o: ["High inflation + High growth", "Low inflation + Low growth", "High inflation + Low growth", "Hyperinflation"], e: "Stagflation is a condition of slow economic growth and relatively high unemployment accompanied by rising prices." },
    { q: "Which curve represents the relationship between tax rates and tax revenue?", a: "Laffer Curve", o: ["Phillips Curve", "Lorenz Curve", "Laffer Curve", "Indifference Curve"], e: "The Laffer Curve suggests there is an optimal tax rate that maximizes total government tax revenue." },
    { q: "The concept of 'Gross National Happiness' was first used in which country?", a: "Bhutan", o: ["India", "Bhutan", "Nepal", "Norway"], e: "Bhutan measures its progress through GNH rather than just GDP, focusing on sustainable development and well-being." }
  ]
};

export default function AdminTests() {
  const db = useFirestore();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [seedLoading, setSeedLoading] = useState(false);
  
  const testsRef = useMemo(() => collection(db, "tests"), [db]);
  const coursesRef = useMemo(() => collection(db, "courses"), [db]);
  const { data: tests, loading: fetchingTests } = useCollection(testsRef);
  const { data: courses } = useCollection(coursesRef);

  const [config, setConfig] = useState({
    topic: "",
    courseId: "",
    difficulty: "medium" as 'easy' | 'medium' | 'hard',
    type: "topic" as 'topic' | 'chapter' | 'full_mock',
    duration: "20",
    negativeMarking: false,
    negativeMarkValue: "0.25"
  });

  const validateQuiz = (quizData: any) => {
    const errors: string[] = [];
    if (!quizData.questions || quizData.questions.length < 10) {
      errors.push("Minimum 10 questions required for a valid professional assessment.");
    }
    
    const questionTexts = new Set();
    
    quizData.questions?.forEach((q: any, idx: number) => {
      const qNum = idx + 1;
      if (!q.questionText || q.questionText.length < 15) {
        errors.push(`Q${qNum}: Question text is too short (min 15 chars).`);
      }
      if (!q.explanation || q.explanation.length < 20) {
        errors.push(`Q${qNum}: Academic explanation is too short (min 20 chars).`);
      }
      
      if (questionTexts.has(q.questionText)) {
        errors.push(`Q${qNum}: Duplicate question detected.`);
      }
      questionTexts.add(q.questionText);
      
      if (!q.options || q.options.length !== 4) {
        errors.push(`Q${qNum}: Exactly 4 options required.`);
      } else {
        const optionSet = new Set(q.options.map((o: string) => o?.trim().toLowerCase()));
        if (optionSet.size !== 4) {
          errors.push(`Q${qNum}: Contains duplicate or empty options.`);
        }
        if (!q.options.includes(q.correctAnswer)) {
          errors.push(`Q${qNum}: Correct answer MUST match one of the provided options.`);
        }
      }
    });
    
    return errors;
  };

  const handleGenerate = async () => {
    if (!config.topic || !config.courseId) return;
    setLoading(true);

    try {
      const quiz = await generateQuiz({ 
        topic: config.topic, 
        difficulty: config.difficulty 
      });

      const newTest = {
        title: quiz.title,
        topic: config.topic,
        courseId: config.courseId,
        difficulty: config.difficulty,
        type: config.type,
        duration: Number(config.duration),
        negativeMarking: config.negativeMarking,
        negativeMarkValue: config.negativeMarking ? Number(config.negativeMarkValue) : 0,
        questions: quiz.questions,
        createdAt: new Date().toISOString()
      };

      const validationErrors = validateQuiz(newTest);
      if (validationErrors.length > 0) {
        throw new Error(`AI generated content failed quality check: ${validationErrors[0]}`);
      }

      await addDoc(testsRef, newTest);
      toast({ title: "Mathes Learning Hub", description: `AI has generated "${quiz.title}" after passing quality checks.` });
      setConfig({ ...config, topic: "" });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Quality Check Failed", description: err.message });
    } finally {
      setLoading(false);
    }
  };

  const handleSeedQuizzes = async () => {
    if (courses.length === 0) {
      toast({ variant: "destructive", title: "Missing Data", description: "Please seed courses first to link assessments." });
      return;
    }
    setSeedLoading(true);
    const batch = writeBatch(db);
    
    try {
      let count = 0;
      for (const course of courses) {
        // Map course categories to our data bank
        const catKey = Object.keys(CATEGORY_MAP).find(k => course.category.includes(k)) || "General Aptitude";
        const samples = CATEGORY_MAP[catKey] || CATEGORY_MAP["SSC"]; // Fallback to SSC if category not found

        const sampleTest = {
          title: `${course.category} - Master Mock Test ${new Date().getFullYear()}`,
          topic: `${course.category} Core Modules`,
          courseId: course.id,
          difficulty: "medium",
          type: "full_mock",
          duration: 45,
          negativeMarking: true,
          negativeMarkValue: 0.33,
          createdAt: new Date().toISOString(),
          questions: samples.map((s, idx) => ({
            id: `q-${idx}-${Date.now()}-${Math.random()}`,
            type: "multiple_choice",
            questionText: s.q,
            options: s.o,
            correctAnswer: s.a,
            explanation: s.e
          }))
        };

        const valErrors = validateQuiz(sampleTest);
        if (valErrors.length === 0) {
          const newDocRef = doc(collection(db, "tests"));
          batch.set(newDocRef, sampleTest);
          count++;
        }
      }
      await batch.commit();
      toast({ title: "Mathes Learning Hub", description: `Academic Archive synchronized with ${count} verified assessments.` });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Seeding Failed", description: err.message });
    } finally {
      setSeedLoading(false);
    }
  };

  const handleRepairTests = async () => {
    setSeedLoading(true);
    try {
      const q = query(collection(db, "tests"));
      const snap = await getDocs(q);
      let repaired = 0;

      for (const tDoc of snap.docs) {
        const test = tDoc.data();
        const errors = validateQuiz(test);
        
        if (errors.length > 0) {
          // Attempt to find a suitable question set based on course category
          const course = courses.find(c => c.id === test.courseId);
          const catKey = course ? Object.keys(CATEGORY_MAP).find(k => course.category.includes(k)) : "SSC";
          const samples = CATEGORY_MAP[catKey || "SSC"];

          await updateDoc(tDoc.ref, {
            questions: samples.map((s, idx) => ({
              id: `q-${idx}-${Date.now()}`,
              type: "multiple_choice",
              questionText: s.q,
              options: s.o,
              correctAnswer: s.a,
              explanation: s.e
            })),
            status: 'verified',
            updatedAt: new Date().toISOString()
          });
          repaired++;
        }
      }
      toast({ title: "Maintenance Complete", description: `${repaired} unverified tests have been synchronized with valid academic content.` });
    } catch (e: any) {
      toast({ variant: "destructive", title: "Repair Failed", description: e.message });
    } finally {
      setSeedLoading(false);
    }
  };

  const handleDelete = (id: string) => {
    if (!confirm("Are you sure? This will remove the test and all student attempt data for it.")) return;
    const dRef = doc(db, "tests", id);
    deleteDoc(dRef).catch(err => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({ path: dRef.path, operation: 'delete' }));
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-emerald-100 p-3 rounded-xl text-emerald-600">
            <ClipboardCheck className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold text-primary">Assessment Manager</h1>
            <p className="text-muted-foreground text-sm">Create and curate competitive exam mock tests with quality control.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={handleRepairTests} 
            disabled={seedLoading}
            className="gap-2 border-primary/20 bg-primary/5 text-primary"
          >
            {seedLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            Repair Invalid Tests
          </Button>
          <Button 
            variant="outline" 
            onClick={handleSeedQuizzes} 
            disabled={seedLoading || courses.length === 0}
            className="gap-2 border-emerald-200 text-emerald-700 bg-emerald-50 hover:bg-emerald-100"
          >
            {seedLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <DatabaseZap className="h-4 w-4" />}
            Seed Verified Question Bank
          </Button>
        </div>
      </div>

      <Alert className="bg-blue-50 border-blue-200">
        <ListChecks className="h-4 w-4 text-blue-600" />
        <AlertTitle className="text-blue-800 font-bold">Academic Quality Standards</AlertTitle>
        <AlertDescription className="text-blue-700 text-xs">
          Assessments require min 10 questions, unique choices, valid correct keys, and detailed explanations (min 20 chars) to be published.
        </AlertDescription>
      </Alert>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="h-fit shadow-md border-none ring-1 ring-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-accent" />
              AI Content Engine
            </CardTitle>
            <CardDescription>Generate quality-verified mock tests.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Target Course</Label>
              <Select value={config.courseId} onValueChange={v => setConfig({...config, courseId: v})}>
                <SelectTrigger><SelectValue placeholder="Select Course" /></SelectTrigger>
                <SelectContent>
                  {courses.map(c => <SelectItem key={c.id} value={c.id}>{c.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Specific Topic</Label>
              <Input 
                value={config.topic} 
                onChange={e => setConfig({...config, topic: e.target.value})}
                placeholder="e.g. Modern Indian History"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Difficulty</Label>
                <Select value={config.difficulty} onValueChange={v => setConfig({...config, difficulty: v as any})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easy">Beginner</SelectItem>
                    <SelectItem value="medium">Intermediate</SelectItem>
                    <SelectItem value="hard">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Time Limit (Min)</Label>
                <Input type="number" value={config.duration} onChange={e => setConfig({...config, duration: e.target.value})} />
              </div>
            </div>

            <div className="space-y-4 pt-2 border-t">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Negative Marking</Label>
                  <p className="text-[10px] text-muted-foreground">Penalty per error</p>
                </div>
                <Switch 
                  checked={config.negativeMarking} 
                  onCheckedChange={v => setConfig({...config, negativeMarking: v})} 
                />
              </div>
            </div>

            <Button className="w-full h-12 shadow-lg shadow-primary/20" onClick={handleGenerate} disabled={loading || !config.courseId || !config.topic}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Sparkles className="h-4 w-4 mr-2" />}
              Publish Verified Test
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-md border-none ring-1 ring-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Active Inventory</CardTitle>
              <CardDescription>Live assessments available to students.</CardDescription>
            </div>
            <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
              <Trophy className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Assessment</TableHead>
                  <TableHead>Integrity</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tests.map((test) => {
                  const valErrors = validateQuiz(test);
                  const isValid = valErrors.length === 0;
                  return (
                    <TableRow key={test.id}>
                      <TableCell>
                        <div className="font-bold text-sm">{test.title}</div>
                        <div className="text-[10px] text-muted-foreground uppercase">{test.questions?.length || 0} Items • {test.difficulty}</div>
                      </TableCell>
                      <TableCell>
                        {isValid ? (
                          <Badge className="bg-emerald-50 text-emerald-700 border-emerald-100 hover:bg-emerald-50">
                            <CheckCircle2 className="h-3 w-3 mr-1" /> VALID
                          </Badge>
                        ) : (
                          <Badge variant="destructive" className="bg-red-50 text-red-700 border-red-100 hover:bg-red-50">
                            <AlertTriangle className="h-3 w-3 mr-1" /> ERROR
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" className="text-destructive h-8 w-8" onClick={() => handleDelete(test.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {!fetchingTests && tests.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center py-20 text-muted-foreground italic">
                      No assessments found. Start by seeding verified samples.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
