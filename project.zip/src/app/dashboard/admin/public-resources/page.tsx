
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, addDoc, deleteDoc, doc, writeBatch } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Library, Plus, Trash2, Loader2, DatabaseZap, Search, ExternalLink, Globe } from "lucide-react";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

const CATEGORIES = ["UPSC", "TNPSC", "SSC", "Banking", "RRB", "UGC NET", "TET"];
const TYPES = ["Syllabus", "Notification", "Pattern", "Official Website"];

export default function ManagePublicResources() {
  const db = useFirestore();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [seedLoading, setSeedLoading] = useState(false);
  const [search, setSearch] = useState("");
  
  const resourcesRef = useMemoFirebase(() => collection(db, "public_resources"), [db]);
  const { data: resources } = useCollection(resourcesRef);

  const [formData, setFormData] = useState({
    title: "",
    category: CATEGORIES[0],
    type: TYPES[0],
    description: "",
    url: ""
  });

  const filteredResources = useMemo(() => {
    return resources.filter(res => 
      res.title.toLowerCase().includes(search.toLowerCase()) || 
      res.category.toLowerCase().includes(search.toLowerCase())
    );
  }, [resources, search]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const newResource = {
      ...formData,
      createdAt: new Date().toISOString(),
    };

    addDoc(resourcesRef, newResource)
      .then(() => {
        setFormData({ title: "", category: CATEGORIES[0], type: TYPES[0], description: "", url: "" });
        setLoading(false);
        toast({ title: "Resource Added", description: `${newResource.title} linked successfully.` });
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: resourcesRef.path,
          operation: 'create',
          requestResourceData: newResource,
        }));
      });
  };

  const handleSeed = async () => {
    setSeedLoading(true);
    const batch = writeBatch(db);
    
    const sampleData = [
      {
        title: "UPSC Civil Services Official Syllabus 2025",
        category: "UPSC",
        type: "Syllabus",
        description: "Official comprehensive syllabus for Prelims and Mains (IAS, IPS, etc.) provided by UPSC.",
        url: "https://upsc.gov.in/sites/default/files/Exam-Noti-CSE-2024-Engl-140224.pdf"
      },
      {
        title: "TNPSC Group 4 Official Syllabus & Scheme",
        category: "TNPSC",
        type: "Syllabus",
        description: "Latest updated syllabus for TNPSC Group 4 examinations in Tamil and English.",
        url: "https://www.tnpsc.gov.in/static_pdf/syllabus/scheme_syllabi_G4.pdf"
      },
      {
        title: "SSC CGL 2025 Official Exam Pattern",
        category: "SSC",
        type: "Pattern",
        description: "Official scheme of examination and tier-wise pattern for SSC Combined Graduate Level.",
        url: "https://ssc.gov.in/"
      },
      {
        title: "TRB Tamil Nadu TET Official Notification",
        category: "TET",
        type: "Notification",
        description: "Official portal for Tamil Nadu Teachers Eligibility Test (TET) notifications.",
        url: "https://trb.tn.gov.in/"
      }
    ];

    try {
      for (const res of sampleData) {
        const newDocRef = doc(collection(db, "public_resources"));
        batch.set(newDocRef, { ...res, createdAt: new Date().toISOString() });
      }
      await batch.commit();
      toast({ title: "Hub Seeded", description: "Official documents have been populated." });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Seeding Failed", description: err.message });
    } finally {
      setSeedLoading(false);
    }
  };

  const handleDelete = (id: string) => {
    if (!confirm("Are you sure you want to remove this public link?")) return;
    const docRef = doc(db, "public_resources", id);
    deleteDoc(docRef).catch(async (err) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: docRef.path,
        operation: 'delete',
      }));
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-3 rounded-xl">
            <Library className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold text-primary">Public Resources Manager</h1>
            <p className="text-sm text-muted-foreground">Curate official government syllabi and notifications.</p>
          </div>
        </div>
        <Button 
          variant="outline" 
          onClick={handleSeed} 
          disabled={seedLoading}
          className="gap-2"
        >
          {seedLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <DatabaseZap className="h-4 w-4" />}
          Seed Official Docs
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 shadow-md border-none ring-1 ring-border h-fit">
          <CardHeader>
            <CardTitle>Register Official Document</CardTitle>
            <CardDescription>Enter details of government-published PDFs or portals.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="space-y-2">
                <Label>Document Title</Label>
                <Input 
                  required 
                  value={formData.title} 
                  onChange={e => setFormData({...formData, title: e.target.value})}
                  placeholder="e.g. UPSC CSE Syllabus 2025"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={formData.category} onValueChange={v => setFormData({...formData, category: v})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Doc Type</Label>
                  <Select value={formData.type} onValueChange={v => setFormData({...formData, type: v})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Official URL</Label>
                <div className="relative">
                  <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    required 
                    className="pl-9"
                    value={formData.url} 
                    onChange={e => setFormData({...formData, url: e.target.value})}
                    placeholder="https://gov-portal.in/..."
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Short Description</Label>
                <Textarea 
                  value={formData.description} 
                  onChange={e => setFormData({...formData, description: e.target.value})}
                  placeholder="Brief overview of the document..."
                />
              </div>
              <Button type="submit" className="w-full h-11" disabled={loading}>
                {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                Add to Hub
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-md border-none ring-1 ring-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Linked Documents</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search records..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Resource</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredResources.map((res) => (
                  <TableRow key={res.id}>
                    <TableCell className="max-w-[200px]">
                      <div className="font-bold text-sm truncate">{res.title}</div>
                      <div className="text-[10px] text-muted-foreground truncate">{res.url}</div>
                    </TableCell>
                    <TableCell><Badge variant="outline">{res.category}</Badge></TableCell>
                    <TableCell className="text-xs">{res.type}</TableCell>
                    <TableCell className="text-right flex justify-end gap-2">
                      <Button variant="ghost" size="icon" asChild title="Open Link">
                        <a href={res.url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(res.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {filteredResources.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-12 text-muted-foreground text-sm italic">
                      No documents registered.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
