"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, addDoc, deleteDoc, doc, writeBatch, query, orderBy } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { FileSearch, Plus, Trash2, Loader2, DatabaseZap, Search, ExternalLink, History, CheckCircle2, Clock } from "lucide-react";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

const CATEGORIES = ["UPSC", "TNPSC", "SSC", "Banking", "RRB", "UGC NET", "TET"];
const TYPES = ["Question Paper", "Answer Key"];

export default function ManagePYQs() {
  const db = useFirestore();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [seedLoading, setSeedLoading] = useState(false);
  const [search, setSearch] = useState("");
  
  const pyqsRef = useMemoFirebase(() => collection(db, "pyqs"), [db]);
  const pyqsQuery = useMemoFirebase(() => query(pyqsRef, orderBy("createdAt", "desc")), [pyqsRef]);
  const { data: pyqs, loading: fetching } = useCollection(pyqsQuery);

  const [formData, setFormData] = useState({
    title: "",
    category: CATEGORIES[0],
    year: new Date().getFullYear().toString(),
    type: TYPES[0],
    url: "",
    description: "",
    status: "available"
  });

  const filteredPyqs = useMemo(() => {
    return pyqs.filter(p => 
      p.title.toLowerCase().includes(search.toLowerCase()) || 
      p.category.toLowerCase().includes(search.toLowerCase()) ||
      p.year.includes(search)
    );
  }, [pyqs, search]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const newPyq = {
      ...formData,
      createdAt: new Date().toISOString(),
    };

    addDoc(pyqsRef, newPyq)
      .then(() => {
        setFormData({ 
          title: "", 
          category: CATEGORIES[0], 
          year: new Date().getFullYear().toString(), 
          type: TYPES[0], 
          url: "",
          description: "",
          status: "available"
        });
        setLoading(false);
        toast({ title: "PYQ Registered", description: `${newPyq.title} added to the library.` });
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: pyqsRef.path,
          operation: 'create',
          requestResourceData: newPyq,
        }));
      });
  };

  const handleSeed = async () => {
    setSeedLoading(true);
    const batch = writeBatch(db);
    
    const sampleExams = [
      { category: "UPSC", title: "UPSC Civil Services Prelims GS Paper 1", year: "2024", desc: "Official Prelims 2024 General Studies Paper 1." },
      { category: "UPSC", title: "UPSC Civil Services Prelims CSAT", year: "2023", desc: "Official Prelims 2023 CSAT Aptitude Paper." },
      { category: "TNPSC", title: "TNPSC Group 4 General Studies & Tamil", year: "2024", desc: "Latest official Group 4 combined paper." },
      { category: "TNPSC", title: "TNPSC Group 2 Prelims", year: "2022", desc: "Official Group 2/2A Preliminary Examination paper." },
      { category: "SSC", title: "SSC CGL Tier 1 Quantitative Aptitude", year: "2023", desc: "CGL Tier 1 memory-based and official shifts." },
      { category: "SSC", title: "SSC CHSL Tier 1 General Awareness", year: "2024", desc: "Complete set of GA questions from CHSL 2024." },
      { category: "Banking", title: "SBI Clerk Prelims Memory Based", year: "2024", desc: "Full shift analysis and question paper for SBI Junior Associate." },
      { category: "Banking", title: "IBPS PO Mains Reasoning & Computer", year: "2023", desc: "Official mains level reasoning and computer awareness paper." },
      { category: "RRB", title: "RRB NTPC CBT-1 All Shifts", year: "2021", desc: "Consolidated PDF of all NTPC CBT-1 examination shifts." },
      { category: "RRB", title: "RRB Group D Science & Math", year: "2022", desc: "Focus paper for RRB Group D technical sections." },
      { category: "UGC NET", title: "UGC NET Economics Paper 2", year: "2023", desc: "Official June 2023 session Economics subject paper." },
      { category: "UGC NET", title: "UGC NET Commerce Paper 2", year: "2023", desc: "Official Commerce subject paper with answer keys." },
      { category: "TET", title: "Tamil Nadu TET Paper 1", year: "2023", desc: "Latest official TNTET Paper 1 for elementary teachers." }
    ];

    try {
      for (const exam of sampleExams) {
        // Add Question Paper
        const qpRef = doc(collection(db, "pyqs"));
        batch.set(qpRef, {
          title: exam.title,
          category: exam.category,
          year: exam.year,
          type: "Question Paper",
          url: "https://upsc.gov.in/sites/default/files/Exam-Noti-CSE-2024-Engl-140224.pdf",
          description: exam.desc,
          status: "available",
          createdAt: new Date().toISOString()
        });

        // Add Answer Key (as coming soon for some)
        const akRef = doc(collection(db, "pyqs"));
        batch.set(akRef, {
          title: `${exam.title} - Answer Key`,
          category: exam.category,
          year: exam.year,
          type: "Answer Key",
          url: "#",
          description: `Official answer key and detailed solutions for ${exam.title}.`,
          status: Math.random() > 0.5 ? "available" : "coming_soon",
          createdAt: new Date().toISOString()
        });
      }
      await batch.commit();
      toast({ title: "Archive Seeded", description: "The PYQ library has been populated with official requested exam records." });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Seeding Failed", description: err.message });
    } finally {
      setSeedLoading(false);
    }
  };

  const handleDelete = (id: string) => {
    if (!confirm("Are you sure you want to remove this record?")) return;
    const docRef = doc(db, "pyqs", id);
    deleteDoc(docRef).catch(async (err) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: docRef.path,
        operation: 'delete',
      }));
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-100 p-3 rounded-xl text-indigo-600">
            <History className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold text-primary">PYQ Archive Manager</h1>
            <p className="text-sm text-muted-foreground">Curate and manage previous year academic records.</p>
          </div>
        </div>
        <Button 
          variant="outline" 
          onClick={handleSeed} 
          disabled={seedLoading}
          className="gap-2 border-indigo-200 text-indigo-700 bg-indigo-50"
        >
          {seedLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <DatabaseZap className="h-4 w-4" />}
          Seed Official Archive
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 shadow-md border-none ring-1 ring-border h-fit">
          <CardHeader>
            <CardTitle>Register Paper/Key</CardTitle>
            <CardDescription>Enter details of publicly available PDF archives.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="space-y-2">
                <Label>Exam Name / Title</Label>
                <Input 
                  required 
                  value={formData.title} 
                  onChange={e => setFormData({...formData, title: e.target.value})}
                  placeholder="e.g. UPSC CSE Prelims 2024 GS"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={formData.category} onValueChange={v => setFormData({...formData, category: v as any})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Year</Label>
                  <Input 
                    required 
                    value={formData.year} 
                    onChange={e => setFormData({...formData, year: e.target.value})}
                    placeholder="2024"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Select value={formData.type} onValueChange={v => setFormData({...formData, type: v as any})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select value={formData.status} onValueChange={v => setFormData({...formData, status: v})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">Available</SelectItem>
                      <SelectItem value="coming_soon">Coming Soon</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Public File URL</Label>
                <Input 
                  required 
                  value={formData.url} 
                  onChange={e => setFormData({...formData, url: e.target.value})}
                  placeholder="https://.../paper.pdf"
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea 
                  value={formData.description} 
                  onChange={e => setFormData({...formData, description: e.target.value})}
                  placeholder="Briefly describe the contents..."
                />
              </div>
              <Button type="submit" className="w-full h-11" disabled={loading}>
                {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                Add to Archive
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-md border-none ring-1 ring-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Archive Registry</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search archives..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Archive Item</TableHead>
                  <TableHead>Category/Year</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPyqs.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell className="max-w-[250px]">
                      <div className="font-bold text-sm truncate">{p.title}</div>
                      <div className="text-[10px] text-muted-foreground uppercase flex items-center gap-1">
                        <Badge variant="outline" className="text-[8px] h-3 px-1">{p.type}</Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <Badge variant="secondary" className="w-fit text-[10px]">{p.category}</Badge>
                        <span className="text-[10px] font-bold text-muted-foreground">{p.year}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {p.status === 'available' ? (
                        <Badge className="bg-emerald-50 text-emerald-700 hover:bg-emerald-50 border-emerald-100 flex items-center gap-1 w-fit">
                          <CheckCircle2 className="h-3 w-3" /> Available
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="flex items-center gap-1 w-fit">
                          <Clock className="h-3 w-3" /> Coming Soon
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right flex justify-end gap-2">
                      <Button variant="ghost" size="icon" asChild title="Preview Link">
                        <a href={p.url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(p.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {!fetching && filteredPyqs.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-12 text-muted-foreground text-sm italic">
                      No matching records found.
                    </TableCell>
                  </TableRow>
                )}
                {fetching && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-12">
                      <Loader2 className="h-6 w-6 animate-spin mx-auto text-muted-foreground" />
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}