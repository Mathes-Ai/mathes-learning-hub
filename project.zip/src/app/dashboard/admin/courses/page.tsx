"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection } from "@/firebase";
import { collection, addDoc, deleteDoc, doc, updateDoc, writeBatch, getDocs, query, where } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, BookOpen, Loader2, DatabaseZap, Search, Edit2, Save, Gift, FileText, Globe } from "lucide-react";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

const CATEGORIES = [
  "UPSC (Prelims & Mains)", "TNPSC (Group 1, 2, 2A, 4)", "SSC (CGL, CHSL, MTS, GD, CPO)",
  "Banking (IBPS, SBI, RRB)", "Railways (NTPC, Group D, ALP)", "UGC NET", "TET, TRB",
  "Police Exams", "Defence (NDA, CDS, AFCAT)", "Insurance (LIC, NIACL)", "State PSC Exams",
  "CUET", "NEET Foundation", "JEE Foundation", "General Aptitude", "Current Affairs",
  "Reasoning", "Quantitative Aptitude", "English", "Tamil"
];

export default function ManageCourses() {
  const db = useFirestore();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [seedLoading, setSeedLoading] = useState(false);
  const [materialLoading, setMaterialLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [editCourse, setEditCourse] = useState<any>(null);
  
  const coursesRef = useMemo(() => collection(db, "courses"), [db]);
  const { data: courses } = useCollection(coursesRef);

  const [formData, setFormData] = useState({
    title: "",
    category: CATEGORIES[0],
    level: "Beginner",
    description: "",
    imageUrl: "",
    duration: "6 Months",
    fee: 0
  });

  const filteredCourses = useMemo(() => {
    return courses.filter(c => 
      c.title.toLowerCase().includes(search.toLowerCase()) || 
      c.category.toLowerCase().includes(search.toLowerCase())
    );
  }, [courses, search]);

  const handleAddCourse = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const newCourse = {
      ...formData,
      teacherId: "admin",
      createdAt: new Date().toISOString(),
    };

    addDoc(coursesRef, newCourse)
      .then(async (docRef) => {
        // Automatically seed materials for the new course
        await seedMaterialsForCourse(docRef.id, newCourse.category);
        setFormData({ 
          title: "", category: CATEGORIES[0], level: "Beginner", 
          description: "", imageUrl: "", duration: "6 Months", fee: 0 
        });
        setLoading(false);
        toast({ title: "Course Created", description: `${newCourse.title} added with official resources.` });
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: coursesRef.path,
          operation: 'create',
          requestResourceData: newCourse,
        }));
      });
  };

  const seedMaterialsForCourse = async (courseId: string, category: string) => {
    const batch = writeBatch(db);
    const materialsRef = collection(db, "materials");
    
    const samples = [
      { title: "Official Examination Syllabus (Full PDF)", type: "PDF", desc: `Detailed breakdown of the current ${category} curriculum provided by official sources.` },
      { title: "Exam Pattern & Marking Scheme", type: "PDF", desc: "Official structure of the paper, including tier details and negative marking rules." },
      { title: "Essential Concept Notes - Module 1", type: "PDF", desc: "Expert-curated notes covering foundational topics of the course." },
      { title: "Last 5 Years PYQ Trend Analysis", type: "PDF", desc: "Statistical breakdown of question frequencies over the last 5 examination cycles." },
      { title: "Official Notification & Eligibility Guide", type: "Link", desc: "Direct portal link for examination registration and eligibility criteria." }
    ];

    for (const sample of samples) {
      const newDocRef = doc(materialsRef);
      batch.set(newDocRef, {
        title: sample.title,
        courseId: courseId,
        type: sample.type,
        url: "#", 
        description: sample.desc,
        downloadCount: 0,
        createdAt: new Date().toISOString(),
        isPlaceholder: true,
        isOfficial: true
      });
    }
    await batch.commit();
  };

  const handleUpdateCourse = () => {
    if (!editCourse) return;
    setLoading(true);

    const docRef = doc(db, "courses", editCourse.id);
    const updateData = { ...editCourse };
    delete updateData.id;

    updateDoc(docRef, updateData)
      .then(() => {
        setEditCourse(null);
        setLoading(false);
        toast({ title: "Course Updated", description: "Changes saved successfully." });
      })
      .catch(async (err) => {
        setLoading(false);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: docRef.path,
          operation: 'update',
          requestResourceData: updateData,
        }));
      });
  };

  const handleSeedCatalog = async () => {
    setSeedLoading(true);
    const batch = writeBatch(db);
    
    const sampleCourses = CATEGORIES.slice(0, 10).map((cat, index) => ({
      title: `${cat} - Complete Mastery Batch ${new Date().getFullYear()}`,
      category: cat,
      level: index % 3 === 0 ? "Advanced" : index % 2 === 0 ? "Intermediate" : "Beginner",
      description: `Premium module for ${cat} preparation. Includes PDF resources, expert video lectures, and real-time assessments. This comprehensive module covers the entire official syllabus.`,
      imageUrl: `https://picsum.photos/seed/${cat.replace(/\s/g, '')}/600/400`,
      duration: "1 Year",
      fee: 0,
      teacherId: "admin",
      createdAt: new Date().toISOString(),
    }));

    try {
      const newIds: string[] = [];
      for (const course of sampleCourses) {
        const newDocRef = doc(collection(db, "courses"));
        batch.set(newDocRef, course);
        newIds.push(newDocRef.id);
      }
      await batch.commit();
      
      // Seed materials for each new course in a separate batch
      for (let i = 0; i < newIds.length; i++) {
        await seedMaterialsForCourse(newIds[i], sampleCourses[i].category);
      }

      toast({ title: "Catalog Seeded", description: `${sampleCourses.length} free courses with materials have been populated.` });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Seeding Failed", description: err.message });
    } finally {
      setSeedLoading(false);
    }
  };

  const handleSeedMaterials = async () => {
    if (courses.length === 0) {
      toast({ variant: "destructive", title: "No Courses", description: "Create or seed courses first." });
      return;
    }
    
    setMaterialLoading(true);
    let totalAdded = 0;

    try {
      for (const course of courses) {
        // Check if materials already exist to avoid duplicates
        const q = query(collection(db, "materials"), where("courseId", "==", course.id));
        const snap = await getDocs(q);
        
        if (snap.empty) {
          await seedMaterialsForCourse(course.id, course.category);
          totalAdded += 5;
        }
      }
      
      toast({ title: "Academic Resources Seeded", description: `Successfully linked ${totalAdded} official documents across your courses.` });
    } catch (err: any) {
      toast({ variant: "destructive", title: "Seeding Failed", description: err.message });
    } finally {
      setMaterialLoading(false);
    }
  };

  const handleDelete = (id: string) => {
    if (!confirm("Are you sure? This will remove all materials linked to this course.")) return;
    const docRef = doc(db, "courses", id);
    deleteDoc(docRef).catch(async (err) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: docRef.path,
        operation: 'delete',
      }));
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-3 rounded-xl">
            <BookOpen className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold">Course Management</h1>
            <p className="text-sm text-muted-foreground">Administer the free learning modules for the Hub.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={handleSeedMaterials} 
            disabled={materialLoading || courses.length === 0}
            className="gap-2 border-emerald-200 text-emerald-700 bg-emerald-50 hover:bg-emerald-100"
          >
            {materialLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Globe className="h-4 w-4" />}
            Refresh Study Materials
          </Button>
          <Button 
            variant="outline" 
            onClick={handleSeedCatalog} 
            disabled={seedLoading}
            className="gap-2 border-primary/20 bg-primary/5 text-primary"
          >
            {seedLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <DatabaseZap className="h-4 w-4" />}
            Seed Full Catalog
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 shadow-md border-none ring-1 ring-border h-fit">
          <CardHeader>
            <CardTitle>Create New Module</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddCourse} className="space-y-4">
              <div className="space-y-2">
                <Label>Course Name</Label>
                <input 
                  required 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={formData.title} 
                  onChange={e => setFormData({...formData, title: e.target.value})}
                  placeholder="e.g. UPSC Prelims 2025"
                />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={formData.category} onValueChange={v => setFormData({...formData, category: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Duration</Label>
                  <Input value={formData.duration} onChange={e => setFormData({...formData, duration: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Access Mode</Label>
                  <div className="h-10 border rounded-md flex items-center px-3 bg-muted/50 text-xs font-bold text-emerald-600 uppercase">
                    <Gift className="h-3 w-3 mr-2" /> Always Free
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Thumbnail URL</Label>
                <Input value={formData.imageUrl} onChange={e => setFormData({...formData, imageUrl: e.target.value})} placeholder="https://..." />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
              </div>
              <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold" disabled={loading}>
                {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                Add Free Course
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-md border-none ring-1 ring-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Course Registry</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Filter..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Course</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCourses.map((course) => (
                  <TableRow key={course.id}>
                    <TableCell className="font-medium">{course.title}</TableCell>
                    <TableCell><Badge variant="outline">{course.category}</Badge></TableCell>
                    <TableCell>
                      <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 uppercase text-[10px]">FREE</Badge>
                    </TableCell>
                    <TableCell className="text-right flex justify-end gap-2">
                      <Button variant="ghost" size="icon" onClick={() => setEditCourse(course)}>
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(course.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {filteredCourses.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-12 text-muted-foreground">
                      No courses found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editCourse} onOpenChange={() => setEditCourse(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Course</DialogTitle>
            <DialogDescription>Modify the details for {editCourse?.title}.</DialogDescription>
          </DialogHeader>
          {editCourse && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Course Name</Label>
                <Input 
                  value={editCourse.title} 
                  onChange={e => setEditCourse({...editCourse, title: e.target.value})} 
                />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={editCourse.category} onValueChange={v => setEditCourse({...editCourse, category: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Duration</Label>
                  <Input value={editCourse.duration} onChange={e => setEditCourse({...editCourse, duration: e.target.value})} />
                </div>
                <div className="space-y-2">
                   <Label>Access Status</Label>
                   <Badge className="w-full h-10 bg-emerald-50 text-emerald-700">COMPLIMENTARY</Badge>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea value={editCourse.description} onChange={e => setEditCourse({...editCourse, description: e.target.value})} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditCourse(null)}>Cancel</Button>
            <Button onClick={handleUpdateCourse} disabled={loading} className="font-bold">
              {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Save className="h-4 w-4 mr-2" />}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
