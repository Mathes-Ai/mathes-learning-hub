
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useUser } from "@/firebase";
import { collection, query, where, addDoc, doc, updateDoc, deleteDoc } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Award, CheckCircle2, Search, Loader2, Trash2, ShieldCheck, User } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";

export default function AdminCertificates() {
  const db = useFirestore();
  const { user: adminUser } = useUser();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [issuingId, setIssuingId] = useState<string | null>(null);

  // Queries
  const enrollmentsQuery = useMemo(() => query(collection(db, "enrollments"), where("progress", "==", 100)), [db]);
  const certsQuery = useMemo(() => collection(db, "certificates"), [db]);
  const studentsQuery = useMemo(() => query(collection(db, "users"), where("role", "==", "student")), [db]);
  const coursesQuery = useMemo(() => collection(db, "courses"), [db]);

  const { data: enrollments } = useCollection(enrollmentsQuery);
  const { data: certificates } = useCollection(certsQuery);
  const { data: students } = useCollection(studentsQuery);
  const { data: courses } = useCollection(coursesQuery);

  const pendingIssuance = useMemo(() => {
    return enrollments.filter(e => !certificates.some(c => c.studentId === e.studentId && c.courseId === e.courseId));
  }, [enrollments, certificates]);

  const filteredCerts = useMemo(() => {
    return certificates.filter(c => 
      c.studentName?.toLowerCase().includes(search.toLowerCase()) || 
      c.courseTitle?.toLowerCase().includes(search.toLowerCase()) ||
      c.certificateId?.toLowerCase().includes(search.toLowerCase())
    );
  }, [certificates, search]);

  const issueCertificate = (enrollment: any) => {
    setIssuingId(enrollment.id);
    const student = students.find(s => s.id === enrollment.studentId);
    const course = courses.find(c => c.id === enrollment.courseId);

    const certId = `MH-${Math.random().toString(36).substring(2, 8).toUpperCase()}-${Date.now().toString().slice(-4)}`;
    
    const certData = {
      studentId: enrollment.studentId,
      studentName: student?.displayName || student?.email || "Student",
      courseId: enrollment.courseId,
      courseTitle: course?.title || "Course",
      issuedAt: new Date().toISOString(),
      certificateId: certId,
      status: "approved",
      approverId: adminUser?.uid || "admin"
    };

    addDoc(collection(db, "certificates"), certData)
      .then(() => {
        setIssuingId(null);
        toast({ title: "Certificate Issued", description: `Credential ${certId} generated for ${certData.studentName}` });
      })
      .catch(async (err) => {
        setIssuingId(null);
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: "certificates",
          operation: "create",
          requestResourceData: certData
        }));
      });
  };

  const revokeCertificate = (id: string) => {
    if (!confirm("Are you sure you want to revoke this certificate?")) return;
    const dRef = doc(db, "certificates", id);
    deleteDoc(dRef).catch(err => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({ path: dRef.path, operation: 'delete' }));
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-3 rounded-xl text-primary">
          <Award className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-3xl font-headline font-bold">Credential Manager</h1>
          <p className="text-muted-foreground text-sm">Issue and verify course completion certificates.</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 shadow-md border-none ring-1 ring-border h-fit">
          <CardHeader>
            <CardTitle className="text-lg">Ready for Issuance</CardTitle>
            <CardDescription>Students who reached 100% progress.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {pendingIssuance.map((e) => {
              const student = students.find(s => s.id === e.studentId);
              const course = courses.find(c => c.id === e.courseId);
              return (
                <div key={e.id} className="p-4 border rounded-xl flex items-center justify-between gap-4 hover:bg-muted/30 transition-colors">
                  <div className="min-w-0">
                    <p className="font-bold text-sm truncate">{student?.displayName || "Loading..."}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{course?.title}</p>
                  </div>
                  <Button 
                    size="sm" 
                    className="h-8 rounded-full" 
                    onClick={() => issueCertificate(e)}
                    disabled={issuingId === e.id}
                  >
                    {issuingId === e.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <CheckCircle2 className="h-3 w-3 mr-1" />}
                    Issue
                  </Button>
                </div>
              );
            })}
            {pendingIssuance.length === 0 && (
              <div className="py-8 text-center text-xs text-muted-foreground border-2 border-dashed rounded-xl">
                No new students qualify for issuance.
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-md border-none ring-1 ring-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Certificate Registry</CardTitle>
              <CardDescription>Verified hub credentials.</CardDescription>
            </div>
            <div className="relative w-48">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search certs..." 
                className="pl-9 h-8 text-xs" 
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Recipient</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>ID</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCerts.map((cert) => (
                  <TableRow key={cert.id}>
                    <TableCell>
                      <div className="font-bold text-sm">{cert.studentName}</div>
                      <div className="text-[10px] text-muted-foreground uppercase">{new Date(cert.issuedAt).toLocaleDateString()}</div>
                    </TableCell>
                    <TableCell className="text-xs">{cert.courseTitle}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="font-mono text-[9px]">{cert.certificateId}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" className="text-destructive h-8 w-8" onClick={() => revokeCertificate(cert.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {filteredCerts.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-12 text-muted-foreground">
                      No matching certificate records.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
