
"use client";

import { useState, useMemo } from "react";
import { useFirestore, useCollection, useUser, useMemoFirebase } from "@/firebase";
import { collection, query, orderBy, doc, setDoc, deleteDoc } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Newspaper, Search, Globe, Calendar, Bookmark, BookmarkCheck, Share2, Filter, Loader2, Info } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";

const CATEGORIES = ["All", "National", "International", "Economy", "Science & Technology", "Sports"];

export default function CurrentAffairsPortal() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const newsRef = useMemoFirebase(() => collection(db, "current_affairs"), [db]);
  const newsQuery = useMemoFirebase(() => query(newsRef, orderBy("date", "desc")), [newsRef]);
  const { data: newsItems, loading } = useCollection(newsQuery);

  const bookmarksQuery = useMemoFirebase(() => 
    user ? collection(db, "users", user.uid, "ca_bookmarks") : null,
    [db, user?.uid]
  );
  const { data: bookmarks } = useCollection(bookmarksQuery);

  const filteredNews = useMemo(() => {
    return newsItems.filter(n => {
      const matchesSearch = n.title.toLowerCase().includes(search.toLowerCase()) || 
                           n.content.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = activeCategory === "All" || n.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [newsItems, search, activeCategory]);

  const toggleBookmark = (news: any) => {
    if (!user) return;
    const isBookmarked = bookmarks.some(b => b.id === news.id);
    const bRef = doc(db, "users", user.uid, "ca_bookmarks", news.id);

    if (isBookmarked) {
      deleteDoc(bRef).then(() => toast({ title: "Removed from Revision" }));
    } else {
      setDoc(bRef, { ...news, bookmarkedAt: new Date().toISOString() })
        .then(() => toast({ title: "Insight Saved", description: "Added to your monthly review list." }));
    }
  };

  const handleShare = (news: any) => {
    if (navigator.share) {
      navigator.share({ title: news.title, text: news.content, url: window.location.href }).catch(() => {});
    } else {
      navigator.clipboard.writeText(`${news.title}\n\n${news.content}`);
      toast({ title: "Link Copied" });
    }
  };

  return (
    <div className="space-y-8 pb-32">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-3xl md:text-4xl font-headline font-bold text-primary flex items-center gap-3">
            <Newspaper className="h-8 w-8 md:h-10 md:w-10 text-accent" />
            Current Affairs
          </h1>
          <p className="text-muted-foreground text-sm md:text-lg">Daily intelligence briefings for competitive excellence.</p>
        </div>
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search news..." 
            className="pl-10 h-11 md:h-12 shadow-sm rounded-full bg-card" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </header>

      <div className="bg-card p-2 rounded-2xl border shadow-sm flex items-center gap-3">
        <ScrollArea className="w-full">
          <div className="flex gap-2 p-1">
            {CATEGORIES.map((cat) => (
              <Button 
                key={cat} 
                variant={cat === activeCategory ? 'default' : 'ghost'}
                size="sm"
                className="rounded-full whitespace-nowrap px-6 font-bold text-[10px] md:text-xs"
                onClick={() => setActiveCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>

      <div className="grid lg:grid-cols-3 gap-8 md:gap-10">
        <div className="lg:col-span-2 space-y-6 md:space-y-8">
           {filteredNews.map((news) => {
             const isBookmarked = bookmarks.some(b => b.id === news.id);
             return (
               <Card key={news.id} className="border-none shadow-lg ring-1 ring-border group overflow-hidden rounded-[1.5rem] md:rounded-[2rem] bg-white">
                 <CardHeader className="bg-slate-50/50 p-6 border-b">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="bg-accent/10 text-accent border-none uppercase text-[8px] font-bold px-2 py-0.5">
                          {news.category}
                        </Badge>
                        <span className="text-[8px] text-muted-foreground font-bold uppercase tracking-widest flex items-center gap-1">
                          <Calendar className="h-3 w-3" /> {new Date(news.date).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                         <Button variant="ghost" size="icon" className="rounded-full h-8 w-8" onClick={() => toggleBookmark(news)}>
                           {isBookmarked ? <BookmarkCheck className="h-4 w-4 text-accent fill-accent" /> : <Bookmark className="h-4 w-4 text-muted-foreground" />}
                         </Button>
                         <Button variant="ghost" size="icon" className="rounded-full h-8 w-8" onClick={() => handleShare(news)}>
                           <Share2 className="h-4 w-4 text-muted-foreground" />
                         </Button>
                      </div>
                    </div>
                    <CardTitle className="text-xl md:text-2xl font-headline font-bold leading-tight group-hover:text-primary transition-colors">
                      {news.title}
                    </CardTitle>
                 </CardHeader>
                 
                 <CardContent className="p-6 md:p-10">
                    {news.imageUrl && (
                      <div className="mb-6 rounded-2xl overflow-hidden shadow-md border max-h-64">
                         <img src={news.imageUrl} alt="News" className="w-full h-full object-cover" />
                      </div>
                    )}
                    <p className="text-base md:text-lg leading-relaxed text-slate-700 whitespace-pre-wrap">
                      {news.content}
                    </p>
                 </CardContent>
                 
                 <CardFooter className="bg-slate-50/30 p-5 px-6 border-t flex justify-between items-center">
                    <div className="flex items-center gap-2 text-primary">
                       <Info className="h-3.5 w-3.5" />
                       <span className="text-[8px] font-bold uppercase tracking-[0.1em]">Verified Source</span>
                    </div>
                    {news.source && <span className="text-[9px] font-bold text-muted-foreground uppercase">{news.source}</span>}
                 </CardFooter>
               </Card>
             );
           })}

           {filteredNews.length === 0 && !loading && (
             <div className="py-32 text-center border-2 border-dashed rounded-[2rem] bg-muted/10">
                <Newspaper className="h-12 w-12 mx-auto text-muted-foreground opacity-20 mb-4" />
                <p className="text-lg font-bold">No results found.</p>
             </div>
           )}

           {loading && (
             <div className="flex flex-col items-center justify-center py-20 gap-4">
                <Loader2 className="h-8 w-8 text-primary animate-spin" />
                <p className="text-[10px] font-bold uppercase text-muted-foreground">Syncing Intelligence...</p>
             </div>
           )}
        </div>

        <div className="space-y-6 md:space-y-8">
           <Card className="border-none shadow-xl ring-1 ring-border rounded-[2rem] bg-primary text-primary-foreground overflow-hidden">
             <CardContent className="p-8 space-y-6">
                <div className="bg-white/20 p-3 rounded-2xl w-fit">
                   <Globe className="h-6 w-6 text-white" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold font-headline">Monthly Digest</h3>
                  <p className="text-xs text-primary-foreground/70 leading-relaxed">
                    Download expert-curated PDF summaries of critical events for quick revision.
                  </p>
                </div>
                <Button className="w-full bg-white text-primary hover:bg-white/90 rounded-xl h-12 font-bold">
                  DOWNLOAD PDF
                </Button>
             </CardContent>
           </Card>

           <div className="bg-emerald-50 p-6 rounded-[2rem] border border-emerald-100 space-y-4">
              <h4 className="font-bold text-emerald-800 uppercase tracking-widest text-[10px]">Aspirant Tip</h4>
              <p className="text-xs text-emerald-900/70 leading-relaxed font-medium italic">
                "Dedicate 15 minutes each morning to current affairs. Understanding the 'why' is more important than memorizing the 'what'."
              </p>
           </div>
        </div>
      </div>
    </div>
  );
}
