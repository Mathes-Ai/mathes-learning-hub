'use server';

import { ai } from '@/ai/genkit';

/**
 * Server action to verify AI configuration and test connectivity.
 * Checks for the presence of the Gemini API key and performs a simple generation.
 * Now returns a masked version of the key for user verification.
 */
export async function checkAiConfig() {
  const key = process.env.GEMINI_API_KEY || process.env.GOOGLE_GENAI_API_KEY;
  
  if (!key) {
    return { 
      success: false, 
      error: 'API Key Missing: Please ensure GEMINI_API_KEY or GOOGLE_GENAI_API_KEY is set in your .env file.' 
    };
  }

  // Mask the key: Show first 10 characters, then asterisks
  const maskedKey = key.length > 10 
    ? `${key.substring(0, 10)}****************` 
    : 'Key found but too short to display safely';

  try {
    // Perform a lightweight generation to verify the key is valid and working
    const response = await ai.generate('Confirm connection. Reply exactly with "Connected Successfully"');
    
    if (!response || !response.text) {
      return { 
        success: false, 
        maskedKey,
        error: 'Incomplete Response: The AI returned an empty response. Check your billing or usage limits.' 
      };
    }

    return { 
      success: true, 
      maskedKey,
      message: response.text 
    };
  } catch (error: any) {
    console.error('AI Diagnostic Error:', error);
    
    let errorMessage = error.message || 'An unknown error occurred during AI initialization.';
    if (errorMessage.includes('401') || errorMessage.includes('invalid') || errorMessage.includes('API key')) {
      errorMessage = 'Invalid API Key: The provided key is not authorized. Please check your Google AI Studio credentials.';
    } else if (errorMessage.includes('quota') || errorMessage.includes('429')) {
      errorMessage = 'Quota Exceeded: You have reached the rate limit for your Gemini API key.';
    }

    return { 
      success: false, 
      maskedKey,
      error: errorMessage 
    };
  }
}
