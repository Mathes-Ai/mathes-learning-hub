"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ShieldCheck, Search, ChevronRight, GraduationCap } from "lucide-react";
import Link from "next/link";

export default function VerifySearch() {
  const [certId, setCertId] = useState("");
  const router = useRouter();

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (certId.trim()) {
      router.push(`/verify/${certId.trim().toUpperCase()}`);
    }
  };

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col">
      <header className="p-6 border-b bg-card flex justify-between items-center">
        <Link href="/" className="flex items-center gap-2">
          <div className="bg-primary p-2 rounded-lg">
            <GraduationCap className="text-white h-5 w-5" />
          </div>
          <span className="font-headline font-bold text-xl text-primary">Mathes Learning Hub</span>
        </Link>
      </header>

      <main className="flex-1 flex items-center justify-center p-6">
        <Card className="max-w-md w-full shadow-2xl border-none ring-1 ring-border">
          <CardHeader className="text-center space-y-2">
            <div className="bg-primary/10 h-16 w-16 rounded-2xl mx-auto flex items-center justify-center mb-2">
              <ShieldCheck className="text-primary h-8 w-8" />
            </div>
            <CardTitle className="text-2xl font-headline">Credential Verification</CardTitle>
            <CardDescription>
              Enter a Certificate ID to verify its authenticity within Mathes Learning Hub.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleVerify} className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input 
                  placeholder="e.g. MH-XY1234-99" 
                  className="h-14 pl-10 text-lg uppercase font-mono tracking-widest"
                  value={certId}
                  onChange={e => setCertId(e.target.value)}
                />
              </div>
              <Button type="submit" className="w-full h-14 text-lg font-bold group rounded-xl">
                Verify Credential
                <ChevronRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </form>
          </CardContent>
          <CardFooter className="bg-muted/30 p-6 text-center">
            <p className="text-xs text-muted-foreground">
              Mathes Learning Hub issues verified credentials for professional competitive exam preparation.
            </p>
          </CardFooter>
        </Card>
      </main>
    </div>
  );
}
