"use client";

import { useMemo } from "react";
import { useParams } from "next/navigation";
import { useFirestore, useCollection } from "@/firebase";
import { collection, query, where } from "firebase/firestore";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { ShieldCheck, Award, Calendar, User, GraduationCap, XCircle, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function PublicVerification() {
  const params = useParams();
  const certId = params.certId as string;
  const db = useFirestore();

  const verifyQuery = useMemo(() => 
    query(collection(db, "certificates"), where("certificateId", "==", certId)),
    [db, certId]
  );

  const { data: certResults, loading } = useCollection(verifyQuery);
  const cert = certResults[0];

  return (
    <div className="min-h-screen bg-muted/30 flex items-center justify-center p-6">
      <div className="max-w-xl w-full">
        <div className="text-center mb-8 space-y-2">
          <div className="bg-primary h-12 w-12 rounded-xl mx-auto flex items-center justify-center mb-4">
            <ShieldCheck className="text-white h-7 w-7" />
          </div>
          <h1 className="text-3xl font-headline font-bold text-primary">Credential Verification</h1>
          <p className="text-muted-foreground">Official authenticity check for Mathes Learning Hub honors.</p>
        </div>

        {loading ? (
          <Card className="p-20 text-center animate-pulse">
            <p className="text-muted-foreground">Verifying Mathes Learning Hub records...</p>
          </Card>
        ) : cert ? (
          <Card className="shadow-2xl border-none ring-1 ring-border overflow-hidden">
            <div className="bg-emerald-500 p-6 text-white text-center flex flex-col items-center gap-2">
               <CheckCircle2 className="h-10 w-10" />
               <h2 className="text-2xl font-bold">Verified Credential</h2>
               <p className="text-emerald-100 text-sm font-mono">{cert.certificateId}</p>
            </div>
            <CardContent className="p-8 space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                    <User className="h-3 w-3" /> Recipient Name
                  </p>
                  <p className="font-bold text-lg">{cert.studentName}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                    <Calendar className="h-3 w-3" /> Issue Date
                  </p>
                  <p className="font-bold text-lg">{new Date(cert.issuedAt).toLocaleDateString()}</p>
                </div>
                <div className="col-span-2 space-y-1">
                  <p className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                    <GraduationCap className="h-3 w-3" /> Academic Subject
                  </p>
                  <p className="font-bold text-lg text-primary">{cert.courseTitle}</p>
                </div>
              </div>

              <div className="pt-6 border-t flex flex-col items-center gap-4">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <ShieldCheck className="h-4 w-4 text-emerald-600" />
                  This certificate is officially verified by Mathes Learning Hub.
                </div>
                <Button asChild variant="outline" className="rounded-full px-8">
                  <Link href="/">Back to Hub</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="shadow-lg border-none text-center p-12 space-y-6">
            <div className="bg-red-50 h-20 w-20 rounded-full flex items-center justify-center mx-auto">
              <XCircle className="h-10 w-10 text-red-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-red-600">Verification Failed</h2>
              <p className="text-muted-foreground mt-2">The certificate ID "{certId}" was not found in the Mathes Learning Hub registry.</p>
            </div>
            <Button asChild className="rounded-full px-8">
              <Link href="/verify">Try Different ID</Link>
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
