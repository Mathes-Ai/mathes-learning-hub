
'use client';

import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore, enableIndexedDbPersistence } from 'firebase/firestore';
import { firebaseConfig } from './config';
import { useMemo, DependencyList } from 'react';

// Singleton instances to ensure one-time initialization
let firebaseApp: FirebaseApp | undefined;
let firestoreInstance: Firestore | undefined;
let authInstance: Auth | undefined;
let persistenceAttempted = false;

/**
 * Initializes Firebase App and services.
 * Ensures that initialization only happens once and persistence is handled correctly.
 */
export function initializeFirebase() {
  if (!firebaseApp) {
    firebaseApp = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
  }
  
  if (!authInstance) {
    authInstance = getAuth(firebaseApp);
  }
  
  if (!firestoreInstance) {
    firestoreInstance = getFirestore(firebaseApp);
  }

  // Enable local persistence for seamless offline operation
  // This must be called only once and before any other Firestore operations
  if (typeof window !== 'undefined' && !persistenceAttempted) {
    persistenceAttempted = true;
    enableIndexedDbPersistence(firestoreInstance).catch((err) => {
      if (err.code === 'failed-precondition') {
        // Multiple tabs open, persistence can only be enabled in one tab at a time.
        console.warn('Firestore persistence failed: Multiple tabs open');
      } else if (err.code === 'unimplemented') {
        // The current browser does not support all of the features required to enable persistence
        console.warn('Firestore persistence failed: Browser not supported');
      } else {
        // Handle other persistence errors silently or with a warning
        console.warn('Firestore persistence could not be enabled:', err.message);
      }
    });
  }

  return { app: firebaseApp, auth: authInstance, firestore: firestoreInstance };
}

/**
 * A hook to stabilize Firebase references and queries.
 * Ensuring that the same instance is returned if dependencies haven't changed.
 */
export function useMemoFirebase<T>(factory: () => T, deps: DependencyList): T {
  return useMemo(factory, deps);
}

export * from './provider';
export * from './client-provider';
export * from './auth/use-user';
export * from './firestore/use-collection';
export * from './firestore/use-doc';
