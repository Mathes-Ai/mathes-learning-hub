/**
 * Firebase configuration for the Mathes Learning Hub project.
 * These values are project-specific and safe to expose in client-side code.
 */
export const firebaseConfig = {
  apiKey: "AIzaSyA2_NPFuQ7qBU6Qlg6EtrY7mdYkyQFU-rg",
  authDomain: "studio-6331216925-243be.firebaseapp.com",
  projectId: "studio-6331216925-243be",
  storageBucket: "studio-6331216925-243be.firebasestorage.app",
  messagingSenderId: "202014090844",
  appId: "1:202014090844:web:31d632ee95813076622899"
};
