
'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { type FirebaseApp } from 'firebase/app';
import { type Auth } from 'firebase/auth';
import { type Firestore, onSnapshotsInSync } from 'firebase/firestore';
import { FirebaseErrorListener } from '@/components/FirebaseErrorListener';

export type ConnectionStatus = 'online' | 'offline' | 'reconnecting';

interface FirebaseContextType {
  app: FirebaseApp;
  auth: Auth;
  firestore: Firestore;
  connectionStatus: ConnectionStatus;
}

const FirebaseContext = createContext<FirebaseContextType | undefined>(undefined);

export function FirebaseProvider({
  children,
  app,
  auth,
  firestore,
}: {
  children: React.ReactNode;
  app: FirebaseApp;
  auth: Auth;
  firestore: Firestore;
}) {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('online');

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleOnline = () => setConnectionStatus('reconnecting');
    const handleOffline = () => setConnectionStatus('offline');

    // Initial browser state check
    if (!navigator.onLine) {
      setConnectionStatus('offline');
    }

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Monitor snapshots syncing to detect actual backend connectivity
    const unsubscribeSync = onSnapshotsInSync(firestore, () => {
      if (navigator.onLine) {
        setConnectionStatus('online');
      }
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubscribeSync();
    };
  }, [firestore]);

  return (
    <FirebaseContext.Provider value={{ app, auth, firestore, connectionStatus }}>
      <FirebaseErrorListener />
      {children}
    </FirebaseContext.Provider>
  );
}

export function useFirebase() {
  const context = useContext(FirebaseContext);
  if (!context) {
    throw new Error('useFirebase must be used within a FirebaseProvider');
  }
  return context;
}

export const useFirebaseApp = () => useFirebase().app;
export const useAuth = () => useFirebase().auth;
export const useFirestore = () => useFirebase().firestore;
export const useFirebaseStatus = () => useFirebase().connectionStatus;
